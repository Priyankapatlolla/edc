function getUWDecision(data) {
  let uw_result = {
    uw_notes: [] = [],
    uw_decisions: ""
  }
  let policyholder = data.policyholder.entity.values;
  let third_party_consumer = policyholder.third_party_notification_non_consumer;
  if (third_party_consumer == "No") {
    uw_result.uw_decisions = "reject"
    uw_result.uw_notes.push("Please Agree to the disclosure");
  }
  return uw_result;
}

exports.getUWDecision = getUWDecision;