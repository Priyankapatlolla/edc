﻿namespace SocotraExternalDataCall.Models
{
    public class SocotraUpdatePolicy
    {
        public VeriskAttributes fieldValues;
    }
    public class VeriskAttributes
    {
        public string value_360;
    }
    public class SocotraResponse
    {
        public FieldValues fieldValues;
    }
    public class FieldValues
    {
        public string[] response_360v;
    }
    public class SocotraAuthenticate
    {
        public string hostName;
        public string username;
        public string password;
        public string authorizationToken;
        public string expiresTimestamp;
    }
}
