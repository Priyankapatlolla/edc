﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using SocotraExternalDataCall.Services;
using System;
using System.Xml.Linq;

namespace Socotra.TPI.CoreAPI.Controllers
{
    [Route("api/TPI")]
    [ApiController]
    public class TPIController : ControllerBase
    {
        private readonly ILogger _logger;
        public TPIController(ILogger<TPIController> logger)
        {
            _logger = logger;
        }

        [Route("get360V")]
        [HttpPost]
        public IActionResult Get360V(dynamic policyRequest)
        {
            string response = null;
            try
            {
                //System.Threading.Thread.Sleep(320000);
                string req = policyRequest.ToString();
                var policyData = JObject.Parse(policyRequest.ToString());

                _logger.LogInformation("Incoming Request From Socotra: " + req);

                string policyLocator = policyData.policy.locator.ToString();
                var veriskService = new VService();
                response = veriskService.Get360V(policyRequest, _logger);

                _logger.LogInformation("Policy Number: " + policyLocator + " External Data Call Response: " + response);

                return Content(response, contentType: "application/json");
            }
            catch (Exception ex)
            {
                _logger.LogInformation(" Errored: " + ex.Message + ex.StackTrace);
                return null;
            }
        }
    }
}