"use strict";

let ratingConstants = require("./ratingConstants.js");
let moment = require("../libraries/moment-timezone-with-data.js");

function getTableObject(tableName, tableKey)
{
  let valueFromTable;
  let valuesArray;
  valueFromTable = socotraApi.tableLookup(tableName, tableKey);
  valuesArray = valueFromTable.split(ratingConstants.getTableObjectConstants.pipe);
  let keyValuePairs = [];
  for (let prop of valuesArray)
  {
    let keyValue = prop.split(ratingConstants.getTableObjectConstants.hash);
    keyValuePairs.push(keyValue);
  }
  var obj = Object.assign(...keyValuePairs.map(([key, val]) => (
  {
    [key]: val
  })));
  return obj;
}

function getDecimalFromPercentage(percent)
{
  return parseInt(percent) / 100.0;
}

function getCountOfChargeableClaims(policy_fgv)
{
  return policy_fgv[prior_claims].length;
}

function getRoofOrHomeAge(model_year)
{
  let home_age = moment().diff(moment(model_year, "YYYY"), 'years');
  return home_age;

}

function getInsuredAge(date_of_birth)
{
  let age = moment().diff(moment(date_of_birth, "YYYY-MM-DD"), 'years');
  if (age >= "18" && age <= "22")
  {
    return "18";
  }
  if (age >= "23" && age <= "27")
  {
    return "23";
  }
  if (age >= "28" && age <= "34")
  {
    return "28";
  }
  if (age >= "35" && age <= "44")
  {
    return "35";
  }
  if (age >= "45" && age <= "49")
  {
    return "45";
  }
  if (age >= "50" && age <= "54")
  {
    return "50";
  }
  if (age >= "55" && age <= "59")
  {
    return "55";
  }
  if (age >= "60" && age <= "64")
  {
    return "60";
  }
  if (age >= "65" && age <= "74")
  {
    return "65";
  }
  if (age >= "75" && age <= "84")
  {
    return "75";
  }
  if (age >= "85")
  {
    return "85";
  }
}

function getSchedule(exposures)
{
  let count_of_units = 0;
  for (let exposure of exposures)
  {
    if (exposure.name == ratingConstants.exposureNameConstants.vacant)
    {
      count_of_units++;
    }
  }
  if (count_of_units > ratingConstants.numberConstants.one)
  {
    return ratingConstants.binaryConstants.yes;
  }
  if (count_of_units == ratingConstants.numberConstants.one)
  {
    return ratingConstants.binaryConstants.no;
  }
}

function getDateOfLoss(claim_date)
{
  let today = new Date();
  let claim_date_calc = new Date(claim_date);
  let year_diff = moment(new Date(today)).diff(new Date(claim_date_calc), 'years', true);
  return parseInt(year_diff);
}

function getNumberOfExposures(allExposures)
{
  let count_of_units = 0;
  let exposure;
  for (exposure of allExposures)
  {
    if (exposure.name != ratingConstants.exposureNameConstants.policy_level_coverages)
    {
      count_of_units++;
    }
  }
  return count_of_units;
}

function getNumberOfDaysUninsured(purchase_date, prior_insurance, prior_policy_expiration_date)
{
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.buying_new_home && purchase_date == ratingConstants.numberOfDaysUninsuredConstants.buying_process)
  {
    return ratingConstants.numberConstants.zero;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.buying_new_home && purchase_date == ratingConstants.numberOfDaysUninsuredConstants.one_to_seven_days_ago)
  {
    return ratingConstants.numberConstants.zero;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.buying_new_home && purchase_date == ratingConstants.numberOfDaysUninsuredConstants.eight_to_thirty_days_ago)
  {
    return ratingConstants.numberConstants.eight;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.buying_new_home && purchase_date == ratingConstants.numberOfDaysUninsuredConstants.thirtyone_to_ninty_days_ago)
  {
    return ratingConstants.numberConstants.thirty_one;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.buying_new_home && purchase_date == ratingConstants.numberOfDaysUninsuredConstants.more_than_ninty_days)
  {
    return ratingConstants.numberConstants.ninty_one;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.one_to_seven_days_ago)
  {
    return ratingConstants.numberConstants.zero;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.eight_to_thirty_days_ago)
  {
    return ratingConstants.numberConstants.eight;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.thirtyone_to_ninty_days_ago)
  {
    return ratingConstants.numberConstants.thirty_one;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.more_than_ninty_days || prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.never_insured)
  {
    return ratingConstants.numberConstants.ninty_one;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.switching_carriers)
  {
    return ratingConstants.numberConstants.zero;
  }
  else
  {
    return ratingConstants.numberConstants.zero;
  }

}

function getNumberOfDaysUninsuredForTenant(prior_insurance, prior_policy_expiration_date)
{
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.one_to_seven_days_ago)
  {
    return ratingConstants.numberConstants.zero;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.eight_to_thirty_days_ago)
  {
    return ratingConstants.numberConstants.eight;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.thirtyone_to_ninty_days_ago)
  {
    return ratingConstants.numberConstants.thirty_one;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.no_insurance && prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.more_than_ninty_days || prior_policy_expiration_date == ratingConstants.numberOfDaysUninsuredConstants.never_insured)
  {
    return ratingConstants.numberConstants.ninty_one;
  }
  if (prior_insurance == ratingConstants.numberOfDaysUninsuredConstants.switching_carriers)
  {
    return ratingConstants.numberConstants.zero;
  }
  else
  {
    return ratingConstants.numberConstants.zero;
  }
}

function getPolicyTerm(data)
{
  let policy_start_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;
  let policy_end_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyEndTimestamp;
  var start_time = new Date(+policy_start_timestamp);
  var end_time = new Date(+policy_end_timestamp);
  let years_difference = moment(new Date(end_time)).diff(new Date(start_time), 'years', true);
  return years_difference;
}

function getInsuranceScore(insurance_score)
{
  if (insurance_score >= 1 && insurance_score <= 390)
  {
    return "1";
  }
  if (insurance_score >= 391 && insurance_score <= 430)
  {
    return "391";
  }
  if (insurance_score >= 431 && insurance_score <= 450)
  {
    return "431";
  }
  if (insurance_score >= 451 && insurance_score <= 465)
  {
    return "451";
  }
  if (insurance_score >= 466 && insurance_score <= 480)
  {
    return "466";
  }
  if (insurance_score >= 481 && insurance_score <= 495)
  {
    return "481";
  }
  if (insurance_score >= 496 && insurance_score <= 510)
  {
    return "496";
  }
  if (insurance_score >= 511 && insurance_score <= 520)
  {
    return "511";
  }
  if (insurance_score >= 521 && insurance_score <= 530)
  {
    return "521";
  }
  if (insurance_score >= 531 && insurance_score <= 540)
  {
    return "531";
  }
  if (insurance_score >= 541 && insurance_score <= 550)
  {
    return "541";
  }
  if (insurance_score >= 551 && insurance_score <= 560)
  {
    return "551";
  }
  if (insurance_score >= 561 && insurance_score <= 570)
  {
    return "561";
  }
  if (insurance_score >= 571 && insurance_score <= 580)
  {
    return "571";
  }
  if (insurance_score >= 581 && insurance_score <= 590)
  {
    return "581";
  }
  if (insurance_score >= 591 && insurance_score <= 600)
  {
    return "591";
  }
  if (insurance_score >= 601 && insurance_score <= 610)
  {
    return "601";
  }
  if (insurance_score >= 611 && insurance_score <= 620)
  {
    return "611";
  }
  if (insurance_score >= 621 && insurance_score <= 630)
  {
    return "621";
  }
  if (insurance_score >= 631 && insurance_score <= 640)
  {
    return "631";
  }
  if (insurance_score >= 641 && insurance_score <= 650)
  {
    return "641";
  }
  if (insurance_score >= 651 && insurance_score <= 660)
  {
    return "651";
  }
  if (insurance_score >= 661 && insurance_score <= 670)
  {
    return "661";
  }
  if (insurance_score >= 671 && insurance_score <= 680)
  {
    return "671";
  }
  if (insurance_score >= 681 && insurance_score <= 690)
  {
    return "681";
  }

  if (insurance_score >= 691 && insurance_score <= 700)
  {
    return "691";
  }
  if (insurance_score >= 701 && insurance_score <= 710)
  {
    return "701";
  }
  if (insurance_score >= 711 && insurance_score <= 720)
  {
    return "711";
  }
  if (insurance_score >= 721 && insurance_score <= 730)
  {
    return "721";
  }
  if (insurance_score >= 731 && insurance_score <= 740)
  {
    return "731";
  }
  if (insurance_score >= 741 && insurance_score <= 750)
  {
    return "741";
  }
  if (insurance_score >= 751 && insurance_score <= 765)
  {
    return "751";
  }
  if (insurance_score >= 766 && insurance_score <= 780)
  {
    return "766";
  }
  if (insurance_score >= 781 && insurance_score <= 795)
  {
    return "781";
  }
  if (insurance_score >= 796 && insurance_score <= 810)
  {
    return "796";
  }
  if (insurance_score >= 811 && insurance_score <= 825)
  {
    return "811";
  }
  if (insurance_score >= 826 && insurance_score <= 840)
  {
    return "826";
  }
  if (insurance_score >= 841 && insurance_score <= 860)
  {
    return "841";
  }
  if (insurance_score >= 861 && insurance_score <= 997)
  {
    return "861";
  }
  if (insurance_score == 998)
  {
    return "998";
  }
  if (insurance_score == 999)
  {
    return "999";
  }
}

function getCoverageLimit(manufactured_home_limit)
{
  if (manufactured_home_limit == 0)
  {
    return "0"
  }
  if (manufactured_home_limit >= 1 && manufactured_home_limit <= 999)
  {
    return "1"
  }
  if (manufactured_home_limit >= 1000 && manufactured_home_limit <= 1999)
  {
    return "1000"
  }
  if (manufactured_home_limit >= 2000 && manufactured_home_limit <= 2999)
  {
    return "2000"
  }
  if (manufactured_home_limit >= 3000 && manufactured_home_limit <= 3999)
  {
    return "3000"
  }
  if (manufactured_home_limit >= 4000 && manufactured_home_limit <= 4999)
  {
    return "4000"
  }
  if (manufactured_home_limit >= 5000 && manufactured_home_limit <= 5999)
  {
    return "5000"
  }
  if (manufactured_home_limit >= 6000 && manufactured_home_limit <= 6999)
  {
    return "6000"
  }
  if (manufactured_home_limit >= 7000 && manufactured_home_limit <= 7999)
  {
    return "7000"
  }
  if (manufactured_home_limit >= 8000 && manufactured_home_limit <= 8999)
  {
    return "8000"
  }
  if (manufactured_home_limit >= 9000 && manufactured_home_limit <= 9999)
  {
    return "9000"
  }
  if (manufactured_home_limit >= 10000 && manufactured_home_limit <= 10999)
  {
    return "10000"
  }
  if (manufactured_home_limit >= 11000 && manufactured_home_limit <= 11999)
  {
    return "11000"
  }
  if (manufactured_home_limit >= 12000 && manufactured_home_limit <= 12999)
  {
    return "12000"
  }
  if (manufactured_home_limit >= 13000 && manufactured_home_limit <= 13999)
  {
    return "13000"
  }
  if (manufactured_home_limit >= 14000 && manufactured_home_limit <= 14999)
  {
    return "14000"
  }
  if (manufactured_home_limit >= 15000 && manufactured_home_limit <= 15999)
  {
    return "15000"
  }
  if (manufactured_home_limit >= 16000 && manufactured_home_limit <= 16999)
  {
    return "16000"
  }
  if (manufactured_home_limit >= 17000 && manufactured_home_limit <= 17999)
  {
    return "17000"
  }
  if (manufactured_home_limit >= 18000 && manufactured_home_limit <= 18999)
  {
    return "18000"
  }
  if (manufactured_home_limit >= 19000 && manufactured_home_limit <= 19999)
  {
    return "19000"
  }
  if (manufactured_home_limit >= 20000 && manufactured_home_limit <= 20999)
  {
    return "20000"
  }
  if (manufactured_home_limit >= 21000 && manufactured_home_limit <= 21999)
  {
    return "21000"
  }
  if (manufactured_home_limit >= 22000 && manufactured_home_limit <= 22999)
  {
    return "22000"
  }
  if (manufactured_home_limit >= 23000 && manufactured_home_limit <= 23999)
  {
    return "23000"
  }
  if (manufactured_home_limit >= 24000 && manufactured_home_limit <= 24999)
  {
    return "24000"
  }
  if (manufactured_home_limit >= 25000 && manufactured_home_limit <= 25999)
  {
    return "25000"
  }
  if (manufactured_home_limit >= 26000 && manufactured_home_limit <= 26999)
  {
    return "26000"
  }
  if (manufactured_home_limit >= 27000 && manufactured_home_limit <= 27999)
  {
    return "27000"
  }
  if (manufactured_home_limit >= 28000 && manufactured_home_limit <= 28999)
  {
    return "28000"
  }
  if (manufactured_home_limit >= 29000 && manufactured_home_limit <= 29999)
  {
    return "29000"
  }
  if (manufactured_home_limit >= 30000 && manufactured_home_limit <= 30999)
  {
    return "30000"
  }
  if (manufactured_home_limit >= 31000 && manufactured_home_limit <= 31999)
  {
    return "31000"
  }
  if (manufactured_home_limit >= 32000 && manufactured_home_limit <= 32999)
  {
    return "32000"
  }
  if (manufactured_home_limit >= 33000 && manufactured_home_limit <= 33999)
  {
    return "33000"
  }
  if (manufactured_home_limit >= 34000 && manufactured_home_limit <= 34999)
  {
    return "34000"
  }
  if (manufactured_home_limit >= 35000 && manufactured_home_limit <= 35999)
  {
    return "35000"
  }
  if (manufactured_home_limit >= 36000 && manufactured_home_limit <= 36999)
  {
    return "36000"
  }
  if (manufactured_home_limit >= 37000 && manufactured_home_limit <= 37999)
  {
    return "37000"
  }
  if (manufactured_home_limit >= 38000 && manufactured_home_limit <= 38999)
  {
    return "38000"
  }
  if (manufactured_home_limit >= 39000 && manufactured_home_limit <= 39999)
  {
    return "39000"
  }
  if (manufactured_home_limit >= 40000 && manufactured_home_limit <= 40999)
  {
    return "40000"
  }
  if (manufactured_home_limit >= 41000 && manufactured_home_limit <= 41999)
  {
    return "41000"
  }
  if (manufactured_home_limit >= 42000 && manufactured_home_limit <= 42999)
  {
    return "42000"
  }
  if (manufactured_home_limit >= 43000 && manufactured_home_limit <= 43999)
  {
    return "43000"
  }
  if (manufactured_home_limit >= 44000 && manufactured_home_limit <= 44999)
  {
    return "44000"
  }
  if (manufactured_home_limit >= 45000 && manufactured_home_limit <= 45999)
  {
    return "45000"
  }
  if (manufactured_home_limit >= 46000 && manufactured_home_limit <= 46999)
  {
    return "46000"
  }
  if (manufactured_home_limit >= 47000 && manufactured_home_limit <= 47999)
  {
    return "47000"
  }
  if (manufactured_home_limit >= 48000 && manufactured_home_limit <= 48999)
  {
    return "48000"
  }
  if (manufactured_home_limit >= 49000 && manufactured_home_limit <= 49999)
  {
    return "49000"
  }
  if (manufactured_home_limit >= 50000 && manufactured_home_limit <= 50999)
  {
    return "50000"
  }
  if (manufactured_home_limit >= 51000 && manufactured_home_limit <= 51999)
  {
    return "51000"
  }
  if (manufactured_home_limit >= 52000 && manufactured_home_limit <= 52999)
  {
    return "52000"
  }
  if (manufactured_home_limit >= 53000 && manufactured_home_limit <= 53999)
  {
    return "53000"
  }
  if (manufactured_home_limit >= 54000 && manufactured_home_limit <= 54999)
  {
    return "54000"
  }
  if (manufactured_home_limit >= 55000 && manufactured_home_limit <= 55999)
  {
    return "55000"
  }
  if (manufactured_home_limit >= 56000 && manufactured_home_limit <= 56999)
  {
    return "56000"
  }
  if (manufactured_home_limit >= 57000 && manufactured_home_limit <= 57999)
  {
    return "57000"
  }
  if (manufactured_home_limit >= 58000 && manufactured_home_limit <= 58999)
  {
    return "58000"
  }
  if (manufactured_home_limit >= 59000 && manufactured_home_limit <= 59999)
  {
    return "59000"
  }
  if (manufactured_home_limit >= 60000 && manufactured_home_limit <= 60999)
  {
    return "60000"
  }
  if (manufactured_home_limit >= 61000 && manufactured_home_limit <= 61999)
  {
    return "61000"
  }
  if (manufactured_home_limit >= 62000 && manufactured_home_limit <= 62999)
  {
    return "62000"
  }
  if (manufactured_home_limit >= 63000 && manufactured_home_limit <= 63999)
  {
    return "63000"
  }
  if (manufactured_home_limit >= 64000 && manufactured_home_limit <= 64999)
  {
    return "64000"
  }
  if (manufactured_home_limit >= 65000 && manufactured_home_limit <= 65999)
  {
    return "65000"
  }
  if (manufactured_home_limit >= 66000 && manufactured_home_limit <= 66999)
  {
    return "66000"
  }
  if (manufactured_home_limit >= 67000 && manufactured_home_limit <= 67999)
  {
    return "67000"
  }
  if (manufactured_home_limit >= 68000 && manufactured_home_limit <= 68999)
  {
    return "68000"
  }
  if (manufactured_home_limit >= 69000 && manufactured_home_limit <= 69999)
  {
    return "69000"
  }
  if (manufactured_home_limit >= 70000 && manufactured_home_limit <= 70999)
  {
    return "70000"
  }
  if (manufactured_home_limit >= 71000 && manufactured_home_limit <= 71999)
  {
    return "71000"
  }
  if (manufactured_home_limit >= 72000 && manufactured_home_limit <= 72999)
  {
    return "72000"
  }
  if (manufactured_home_limit >= 73000 && manufactured_home_limit <= 73999)
  {
    return "73000"
  }
  if (manufactured_home_limit >= 74000 && manufactured_home_limit <= 74999)
  {
    return "74000"
  }
  if (manufactured_home_limit >= 75000 && manufactured_home_limit <= 75999)
  {
    return "75000"
  }
  if (manufactured_home_limit >= 76000 && manufactured_home_limit <= 76999)
  {
    return "76000"
  }
  if (manufactured_home_limit >= 77000 && manufactured_home_limit <= 77999)
  {
    return "77000"
  }
  if (manufactured_home_limit >= 78000 && manufactured_home_limit <= 78999)
  {
    return "78000"
  }
  if (manufactured_home_limit >= 79000 && manufactured_home_limit <= 79999)
  {
    return "79000"
  }
  if (manufactured_home_limit >= 80000 && manufactured_home_limit <= 80999)
  {
    return "80000"
  }
  if (manufactured_home_limit >= 81000 && manufactured_home_limit <= 81999)
  {
    return "81000"
  }
  if (manufactured_home_limit >= 82000 && manufactured_home_limit <= 82999)
  {
    return "82000"
  }
  if (manufactured_home_limit >= 83000 && manufactured_home_limit <= 83999)
  {
    return "83000"
  }
  if (manufactured_home_limit >= 84000 && manufactured_home_limit <= 84999)
  {
    return "84000"
  }
  if (manufactured_home_limit >= 85000 && manufactured_home_limit <= 85999)
  {
    return "85000"
  }
  if (manufactured_home_limit >= 86000 && manufactured_home_limit <= 86999)
  {
    return "86000"
  }
  if (manufactured_home_limit >= 87000 && manufactured_home_limit <= 87999)
  {
    return "87000"
  }
  if (manufactured_home_limit >= 88000 && manufactured_home_limit <= 88999)
  {
    return "88000"
  }
  if (manufactured_home_limit >= 89000 && manufactured_home_limit <= 89999)
  {
    return "89000"
  }
  if (manufactured_home_limit >= 90000 && manufactured_home_limit <= 99999)
  {
    return "90000"
  }
  if (manufactured_home_limit >= 100000 && manufactured_home_limit <= 100999)
  {
    return "100000"
  }
  if (manufactured_home_limit >= 101000 && manufactured_home_limit <= 101999)
  {
    return "101000"
  }
  if (manufactured_home_limit >= 102000 && manufactured_home_limit <= 102999)
  {
    return "102000"
  }
  if (manufactured_home_limit >= 103000 && manufactured_home_limit <= 103999)
  {
    return "103000"
  }
  if (manufactured_home_limit >= 104000 && manufactured_home_limit <= 104999)
  {
    return "104000"
  }
  if (manufactured_home_limit >= 105000 && manufactured_home_limit <= 105999)
  {
    return "105000"
  }

  if (manufactured_home_limit >= 106000 && manufactured_home_limit <= 106999)
  {
    return "106000"
  }
  if (manufactured_home_limit >= 107000 && manufactured_home_limit <= 107999)
  {
    return "107000"
  }
  if (manufactured_home_limit >= 108000 && manufactured_home_limit <= 108999)
  {
    return "108000"
  }

  if (manufactured_home_limit >= 109000 && manufactured_home_limit <= 109999)
  {
    return "109000"
  }
  if (manufactured_home_limit >= 110000 && manufactured_home_limit <= 110999)
  {
    return "110000"
  }
  if (manufactured_home_limit >= 111000 && manufactured_home_limit <= 111999)
  {
    return "111000"
  }
  if (manufactured_home_limit >= 112000 && manufactured_home_limit <= 112999)
  {
    return "112000"
  }
  if (manufactured_home_limit >= 113000 && manufactured_home_limit <= 113999)
  {
    return "113000"
  }
  if (manufactured_home_limit >= 114000 && manufactured_home_limit <= 114999)
  {
    return "114000"
  }
  if (manufactured_home_limit >= 115000 && manufactured_home_limit <= 115999)
  {
    return "115000"
  }
  if (manufactured_home_limit >= 116000 && manufactured_home_limit <= 116999)
  {
    return "116000"
  }
  if (manufactured_home_limit >= 117000 && manufactured_home_limit <= 117999)
  {
    return "117000"
  }
  if (manufactured_home_limit >= 118000 && manufactured_home_limit <= 118999)
  {
    return "118000"
  }
  if (manufactured_home_limit >= 119000 && manufactured_home_limit <= 119999)
  {
    return "119000"
  }
  if (manufactured_home_limit >= 120000 && manufactured_home_limit <= 120999)
  {
    return "120000"
  }
  if (manufactured_home_limit >= 121000 && manufactured_home_limit <= 121999)
  {
    return "121000"
  }
  if (manufactured_home_limit >= 122000 && manufactured_home_limit <= 122999)
  {
    return "122000"
  }
  if (manufactured_home_limit >= 123000 && manufactured_home_limit <= 123999)
  {
    return "123000"
  }
  if (manufactured_home_limit >= 124000 && manufactured_home_limit <= 124999)
  {
    return "124000"
  }
  if (manufactured_home_limit >= 125000 && manufactured_home_limit <= 125999)
  {
    return "125000"
  }
  if (manufactured_home_limit >= 126000 && manufactured_home_limit <= 126999)
  {
    return "126000"
  }
  if (manufactured_home_limit >= 127000 && manufactured_home_limit <= 127999)
  {
    return "127000"
  }
  if (manufactured_home_limit >= 128000 && manufactured_home_limit <= 128999)
  {
    return "128000"
  }
  if (manufactured_home_limit >= 129000 && manufactured_home_limit <= 129999)
  {
    return "129000"
  }
  if (manufactured_home_limit >= 130000 && manufactured_home_limit <= 130999)
  {
    return "130000"
  }
  if (manufactured_home_limit >= 131000 && manufactured_home_limit <= 131999)
  {
    return "131000"
  }
  if (manufactured_home_limit >= 132000 && manufactured_home_limit <= 132999)
  {
    return "132000"
  }
  if (manufactured_home_limit >= 133000 && manufactured_home_limit <= 133999)
  {
    return "133000"
  }
  if (manufactured_home_limit >= 134000 && manufactured_home_limit <= 134999)
  {
    return "134000"
  }
  if (manufactured_home_limit >= 135000 && manufactured_home_limit <= 135999)
  {
    return "135000"
  }
  if (manufactured_home_limit >= 136000 && manufactured_home_limit <= 136999)
  {
    return "136000"
  }
  if (manufactured_home_limit >= 137000 && manufactured_home_limit <= 137999)
  {
    return "137000"
  }
  if (manufactured_home_limit >= 138000 && manufactured_home_limit <= 138999)
  {
    return "138000"
  }
  if (manufactured_home_limit >= 139000 && manufactured_home_limit <= 140999)
  {
    return "139000"
  }
  if (manufactured_home_limit >= 141000 && manufactured_home_limit <= 141999)
  {
    return "141000"
  }
  if (manufactured_home_limit >= 142000 && manufactured_home_limit <= 142999)
  {
    return "142000"
  }
  if (manufactured_home_limit >= 143000 && manufactured_home_limit <= 143999)
  {
    return "143000"
  }
  if (manufactured_home_limit >= 144000 && manufactured_home_limit <= 144999)
  {
    return "144000"
  }
  if (manufactured_home_limit >= 145000 && manufactured_home_limit <= 145999)
  {
    return "145000"
  }
  if (manufactured_home_limit >= 146000 && manufactured_home_limit <= 146999)
  {
    return "146000"
  }
  if (manufactured_home_limit >= 147000 && manufactured_home_limit <= 147999)
  {
    return "147000"
  }
  if (manufactured_home_limit >= 148000 && manufactured_home_limit <= 148999)
  {
    return "148000"
  }
  if (manufactured_home_limit >= 149000 && manufactured_home_limit <= 149999)
  {
    return "149000"
  }
  if (manufactured_home_limit >= 150000 && manufactured_home_limit < 5000000)
  {
    return "150000"
  }
  if (manufactured_home_limit >= 5000000)
  {
    return "5000000"
  }
}

function getUnitLocation(unit_location)
{
  if (unit_location == "In a large manufactured home community (equal to or more than 25 units)")
  {
    return ">25 Units";
  }
  if (unit_location == "In a small manufactured home community (less than 25 units)")
  {
    return "<25 Units";
  }
  if (unit_location == "On my own land")
  {
    return "Own Land";
  }
}

function getAOPDeductible(all_other_perils_deductible)
{
  if (all_other_perils_deductible == "$500")
  {
    return 500;
  }
  if (all_other_perils_deductible == "$1,000")
  {
    return 1000;
  }
  if (all_other_perils_deductible == "$2,500")
  {
    return 2500;
  }
  if (all_other_perils_deductible == "$5,000")
  {
    return 5000;
  }
  if (all_other_perils_deductible == "$10,000")
  {
    return 10000;
  }
}

function getWindHailDeductible(wind_hail_deductible)
{
  if (wind_hail_deductible == "$1,000")
  {
    return 1000;
  }
  if (wind_hail_deductible == "$2,500")
  {
    return 2500;
  }
  if (wind_hail_deductible == "$5,000")
  {
    return 5000;
  }
  if (wind_hail_deductible == "$10,000")
  {
    return 10000;
  }
}

function getAgeOfHomeForFactor(model_year)
{
  let home_age = moment().diff(moment(model_year, "YYYY"), 'years');
  if (home_age >= 0 && home_age <= 4)
  {
    return "0";
  }
  else if (home_age >= 5)
  {
    return "5";
  }

}

function getChannel(application_intiation)
{
  if (application_intiation == ratingConstants.applicationInitConstants.d2c)
  {
    return ratingConstants.applicationInitConstants.d2c;
  }
  else
  {
    return ratingConstants.applicationInitConstants.broker;
  }
}

function getRoofMaterial(roof_material)
{
  if (roof_material == ratingConstants.tableKeyConstants.metal_elastomeric_coated)
  {
    return "Metal - Elastomeric Coated";
  }
  else
  {
    return roof_material;
  }

}

function getDebrisRemovalkey(debris_removal_limit)
{
  if (debris_removal_limit == "$5,000")
  {
    return "5000"
  }
  else if (debris_removal_limit == "$10,000")
  {
    return "10000"
  }
}

function getwaterBackupAndSumpOverflowKey(water_backup_and_sump_overflow_limit)
{
  if (water_backup_and_sump_overflow_limit == "$5,000")
  {
    return "5000"
  }
  else if (water_backup_and_sump_overflow_limit == "$10,000")
  {
    return "10000"
  }
  else if (water_backup_and_sump_overflow_limit == "$25,000")
  {
    return "25000"
  }
}

function getLossAssessmentKey(loss_assessment_limit)
{
  if (loss_assessment_limit == "$1,000")
  {
    return "1000"
  }
  else if (loss_assessment_limit == "$5,000")
  {
    return "5000"
  }
}

function getAnimalLiabilityLimitKey(animal_liability_limit)
{
  if (animal_liability_limit == "Excluded")
  {
    return "Excluded"
  }
  else if (animal_liability_limit == "$10,000")
  {
    return "10000"
  }
  else if (animal_liability_limit == "$25,000")
  {
    return "25000"
  }
  else if (animal_liability_limit == "$50,000")
  {
    return "50000"
  }
  else if (animal_liability_limit == "$100,000")
  {
    return "100000"
  }
  else if (animal_liability_limit == "$300,000")
  {
    return "300000"
  }
  else if (animal_liability_limit == "$500,000")
  {
    return "500000"
  }

}

function getMedicalPaymentsLimitKey(medical_payment_to_others_limit_PerPerson)
{
  if (medical_payment_to_others_limit_PerPerson == "$500/$25,000")
  {
    return "500 / 25000"
  }
  else if (medical_payment_to_others_limit_PerPerson == "$1,000/$25,000")
  {
    return "1000 / 25000"
  }
  else if (medical_payment_to_others_limit_PerPerson == "$2,000/$25,000")
  {
    return "2000 / 25000"
  }
  else if (medical_payment_to_others_limit_PerPerson == "$3,000/$25,000")
  {
    return "3000 / 25000"
  }
  else if (medical_payment_to_others_limit_PerPerson == "$4,000/$25,000")
  {
    return "4000 / 25000"
  }
  else if (medical_payment_to_others_limit_PerPerson == "$5,000/$25,000")
  {
    return "5000 / 25000"
  }
}

function getpremisesliabilitylimitKey(premises_liability_limit)
{
  if (premises_liability_limit == "$25,000")
  {
    return "25000"
  }
  else if (premises_liability_limit == "$50,000")
  {
    return "50000"
  }
  else if (premises_liability_limit == "$100,000")
  {
    return "100000"
  }
  else if (premises_liability_limit == "$300,000")
  {
    return "300000"
  }
  else if (premises_liability_limit == "$500,000")
  {
    return "500000"
  }
}

function getpersonalliabilitylimitKey(personal_liability_limit_key)
{
  if (personal_liability_limit_key == "$25,000")
  {
    return "25000"
  }
  else if (personal_liability_limit_key == "$50,000")
  {
    return "50000"
  }
  else if (personal_liability_limit_key == "$100,000")
  {
    return "100000"
  }
  else if (personal_liability_limit_key == "$300,000")
  {
    return "300000"
  }
  else if (personal_liability_limit_key == "$500,000")
  {
    return "500000"
  }
}
exports.getpersonalliabilitylimitKey = getpersonalliabilitylimitKey;
exports.getpremisesliabilitylimitKey = getpremisesliabilitylimitKey;
exports.getMedicalPaymentsLimitKey = getMedicalPaymentsLimitKey;
exports.getAnimalLiabilityLimitKey = getAnimalLiabilityLimitKey;
exports.getLossAssessmentKey = getLossAssessmentKey;
exports.getwaterBackupAndSumpOverflowKey = getwaterBackupAndSumpOverflowKey;
exports.getDebrisRemovalkey = getDebrisRemovalkey;
exports.getRoofMaterial = getRoofMaterial;
exports.getChannel = getChannel;
exports.getAgeOfHomeForFactor = getAgeOfHomeForFactor;
exports.getWindHailDeductible = getWindHailDeductible;
exports.getAOPDeductible = getAOPDeductible;
exports.getUnitLocation = getUnitLocation;
exports.getPolicyTerm = getPolicyTerm;
exports.getInsuranceScore = getInsuranceScore;
exports.getNumberOfExposures = getNumberOfExposures;
exports.getDateOfLoss = getDateOfLoss;
exports.getInsuredAge = getInsuredAge;
exports.getRoofOrHomeAge = getRoofOrHomeAge;
exports.getCoverageLimit = getCoverageLimit;
exports.getCountOfChargeableClaims = getCountOfChargeableClaims;
exports.getTableObject = getTableObject;
exports.getDecimalFromPercentage = getDecimalFromPercentage;
exports.getSchedule = getSchedule;
exports.getNumberOfDaysUninsured = getNumberOfDaysUninsured;
exports.getNumberOfDaysUninsuredForTenant = getNumberOfDaysUninsuredForTenant;