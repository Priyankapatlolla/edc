"use strict";

let ratingConstants = require("../ratingConstants.js");
let ratingHelpers = require("../helpersRating.js");

function getNumberOfClaims(policy_fv, policy_fgv)
{
  let number_of_claims_for_discount = ratingConstants.numberConstants.zero;
  let number_of_claims_for_surcharge = ratingConstants.numberConstants.zero;
  if (policy_fv.prior_claims != undefined)
  {
    for (let each_claim of policy_fv.prior_claims)
    {
      let category = policy_fgv[each_claim].category;
      let claim_date = policy_fgv[each_claim].claim_date;
      let claim_amount = parseInt(policy_fgv[each_claim].claim_amount)

      let applicability = socotraApi.tableLookup(ratingConstants.tableNameConstants.loss_chargeable_matrix, category);

      if (applicability == ratingConstants.binaryConstants.yes && claim_amount > ratingConstants.numberConstants.five_hundred && ratingHelpers.getDateOfLoss(claim_date) <= ratingConstants.numberConstants.three)
      {
        number_of_claims_for_discount = number_of_claims_for_discount + ratingConstants.numberConstants.one;
        number_of_claims_for_surcharge = number_of_claims_for_surcharge + ratingConstants.numberConstants.one;
      }
    }
  }
  return {
    number_of_claims_for_discount,
    number_of_claims_for_surcharge
  }
}

function getTerritoryFactor(territory_code, type_constant, coverage_constant)
{
  let territory_factor;
  if (territory_code != null && type_constant == ratingConstants.valueConstants.all_other_perils)
  {
    let territory_code_aop_key = territory_code + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let territoryCodeAOPTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.territory_factor, territory_code_aop_key);
    territory_factor = parseFloat(territoryCodeAOPTable[type_constant]);
  }
  if (territory_code != null && type_constant == ratingConstants.valueConstants.windstorm_or_hail)
  {
    let territory_code_windhail_key = territory_code + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let territoryCodeWindHailTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.territory_factor, territory_code_windhail_key);
    territory_factor = parseFloat(territoryCodeWindHailTable[type_constant]);
  }
  return territory_factor;
}

function getPriorLapseSurchageFactor(exposure_fgv, exposure_fv, policy_fgv, policy_fv, policy_term, type_constant, coverage_constant)
{
  let prior_lapse_surcharge_factor = ratingConstants.numberConstants.one;
  let number_of_days_uninsured;
  let policy_usage = exposure_fgv[exposure_fv.usage].policy_usage;
  if (policy_usage == ratingConstants.usageConstants.tenant)
  {
    number_of_days_uninsured = ratingHelpers.getNumberOfDaysUninsuredForTenant(exposure_fgv[exposure_fv.unit_details].purchase_date, policy_fgv[policy_fv.prior_insurance_details].prior_insurance, policy_fgv[policy_fv.prior_insurance_details].prior_policy_expiration_date);
  }
  number_of_days_uninsured = ratingHelpers.getNumberOfDaysUninsured(exposure_fgv[exposure_fv.unit_details].purchase_date, policy_fgv[policy_fv.prior_insurance_details].prior_insurance, policy_fgv[policy_fv.prior_insurance_details].prior_policy_expiration_date);

  if (policy_term == ratingConstants.numberConstants.one)
  {
    let prior_lapse_surcharge_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + ratingConstants.numberConstants.one + ratingConstants.tableToObjectConstants.pipe + number_of_days_uninsured + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let priorLapseSurchargeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.prior_lapse_surcharge_factor, prior_lapse_surcharge_factor_key);
    prior_lapse_surcharge_factor = parseFloat(priorLapseSurchargeFactorTable[type_constant]);
  }

  if (policy_term > ratingConstants.numberConstants.one)
  {
    let prior_lapse_surcharge_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + ratingConstants.numberConstants.two + ratingConstants.tableToObjectConstants.pipe + number_of_days_uninsured + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let priorLapseSurchargeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.prior_lapse_surcharge_factor, prior_lapse_surcharge_factor_key);
    prior_lapse_surcharge_factor = parseFloat(priorLapseSurchargeFactorTable[type_constant]);
  }

  return prior_lapse_surcharge_factor;
}

function getAgeOfHomeFactor(exposure_fgv, exposure_fv, policy_usage, type_constant, coverage_constant)
{
  let age_of_home_factor;
  let age_of_home = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].model_year);
  if (policy_usage == ratingConstants.usageConstants.tenant)
  {
    let age_of_home_factor_key = (policy_usage + ratingConstants.tableToObjectConstants.pipe + age_of_home + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.age_of_home_factor, age_of_home_factor_key);
    age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
  }
  else
  {
    let age_of_home_factor_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + age_of_home + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.age_of_home_factor, age_of_home_factor_key);
    age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
  }
  return age_of_home_factor;
}

function getAgeOfInsuredFactor(date_of_birth, type_constant, coverage_constant)
{
  let age_of_insured_factor_key = (ratingHelpers.getInsuredAge(date_of_birth) + ratingConstants.tableToObjectConstants.pipe + coverage_constant)
  let ageOfInsuredFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.age_of_insured_factor, age_of_insured_factor_key);
  let age_of_insured_factor = parseFloat(ageOfInsuredFactorTable[type_constant]);
  return age_of_insured_factor;
}

function getCalendarYearModifier(policy_start_timestamp, type_constant, coverage_constant)
{
  let calendar_year_modifier_factor;
  let calendarYearTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.calendar_year_modifier, coverage_constant);
  let calendar_year_modifier = parseFloat(calendarYearTable[type_constant]);

  let effective_year = new Date(+policy_start_timestamp).getFullYear();

  let variable_a = (calendar_year_modifier ** (effective_year - ratingConstants.numberConstants.twenty_twenty_two));

  if (variable_a > ratingConstants.numberConstants.one && effective_year <= ratingConstants.numberConstants.twenty_twenty_seven)
  {
    calendar_year_modifier_factor = variable_a;
  }
  else
  {
    calendar_year_modifier_factor = ratingConstants.numberConstants.one;
  }
  return calendar_year_modifier_factor;
}

function getAOPorWindDeductibleFactorandOccasionalRenatalFactor(policy_usage, data, perils, coverage_limit, type_constant, coverage_constant)
{
  let occasional_vacation_rental_factor = ratingConstants.numberConstants.one;
  let deductible_factor = ratingConstants.numberConstants.one;

  let variable_b;
  let variable_c;
  if (policy_usage == ratingConstants.usageConstants.tenant)
  {
    let variable_b_key = (policy_usage + ratingConstants.tableToObjectConstants.pipe + ratingConstants.alphabetConstants.b + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    let variable_c_key = (policy_usage + ratingConstants.tableToObjectConstants.pipe + ratingConstants.alphabetConstants.c + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    variable_b = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.aop_variable_factor, variable_b_key));
    variable_c = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.aop_variable_factor, variable_c_key));
  }
  else
  {
    let variable_b_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + ratingConstants.alphabetConstants.b + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    let variable_c_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + ratingConstants.alphabetConstants.c + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    variable_b = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.aop_variable_factor, variable_b_key));
    variable_c = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.aop_variable_factor, variable_c_key));
  }

  let aop_deductible;
  let wind_hail_deductible;
  let unscheduled_personal_property_limit;
  let manufactured_home_limit;

  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;

    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_a)
    {
      manufactured_home_limit = otherPeril_fv.manufactured_home_limit;
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_c)
    {
      unscheduled_personal_property_limit = otherPeril_fv.unscheduled_personal_property_limit;
    }
  }
  if (policy_usage == ratingConstants.usageConstants.tenant)
  {
    coverage_limit = unscheduled_personal_property_limit;
  }
  else
  {
    coverage_limit = manufactured_home_limit;
  }

  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    let otherPeril_fv = otherPeril.characteristics[otherPeril.characteristics.length - 1].fieldValues;

    if (otherPeril.name == ratingConstants.perilNameConstants.deductibles)
    {
      if (type_constant == ratingConstants.valueConstants.all_other_perils)
      {
        aop_deductible = ratingHelpers.getAOPDeductible(otherPeril_fv.all_other_perils_deductible);
        deductible_factor = Math.min(ratingConstants.numberConstants.one_point_five,
          (variable_c * ((aop_deductible / parseFloat(coverage_limit)) ** variable_b)))
      }
      if (type_constant == ratingConstants.valueConstants.windstorm_or_hail)
      {
        if(policy_usage == ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible != null)
        {
        wind_hail_deductible = ratingHelpers.getWindHailDeductible(otherPeril_fv.wind_hail_deductible);
        deductible_factor = Math.min(ratingConstants.numberConstants.one_point_five,
          (variable_c * ((wind_hail_deductible / parseFloat(coverage_limit)) ** variable_b)))
        }
        else if(policy_usage == ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible == null)
        {
          aop_deductible = ratingHelpers.getAOPDeductible(otherPeril_fv.all_other_perils_deductible);
          deductible_factor = Math.min(ratingConstants.numberConstants.one_point_five,
            (variable_c * ((aop_deductible / parseFloat(coverage_limit)) ** variable_b)))
        }
        else if(policy_usage != ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible != null)
        {
          wind_hail_deductible = ratingHelpers.getWindHailDeductible(otherPeril_fv.wind_hail_deductible);
          deductible_factor = Math.min(ratingConstants.numberConstants.one_point_five,
            (variable_c * ((wind_hail_deductible / parseFloat(coverage_limit)) ** variable_b)))
        }
        else if(policy_usage != ratingConstants.usageConstants.tenant && otherPeril_fv.wind_hail_deductible == null)
        {
          aop_deductible = ratingHelpers.getAOPDeductible(otherPeril_fv.all_other_perils_deductible);;
          deductible_factor = Math.min(ratingConstants.numberConstants.one_point_five,
            (variable_c * ((aop_deductible / parseFloat(coverage_limit)) ** variable_b)))
        }
        else
        {
          deductible_factor = ratingConstants.numberConstants.one;
        }
      }
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.vacation_rental_coverage)
    {
      if (otherPeril_fv.occasional_vacation_rental == ratingConstants.binaryConstants.yes)
      {
        let occasional_vacation_rental_key = otherPeril_fv.occasional_vacation_rental + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
        let occasionalVacationRentalTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.occasional_vacation_rental_coverage_factor, occasional_vacation_rental_key);
        occasional_vacation_rental_factor = parseFloat(occasionalVacationRentalTable[type_constant]);
      }
    }
  }
  deductible_factor = deductible_factor.toFixed(4);
  return {
    occasional_vacation_rental_factor,
    deductible_factor
  }

}

function getDistributionChanelFactor(application_intiation, type_constant, coverage_constant)
{
  let distribution_channel_factor = ratingConstants.numberConstants.one;
  let channel = ratingHelpers.getChannel(application_intiation);
  if (channel != null)
  {
    let distribution_channel_factor_key = channel + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let distributionChannelFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.distribution_channel_factor, distribution_channel_factor_key);
    distribution_channel_factor = parseFloat(distributionChannelFactorTable[type_constant]);
  }
  return distribution_channel_factor;
}

function getFormFactor(form, type_constant, coverage_constant)
{
  let form_factor = ratingConstants.numberConstants.one;
  if (form != null)
  {
    let form_factor_key = (form + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    let formFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.form_factor, form_factor_key);
    form_factor = parseFloat(formFactorTable[type_constant]);
  }
  return form_factor;
}

function getInsuranceScoreFactor(insurance_score, type_constant, coverage_constant)
{
  let insurance_score_factor = ratingConstants.numberConstants.one;
  if (insurance_score != null)
  {
    let insurance_score_factor_key = ratingHelpers.getInsuranceScore(insurance_score) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let insuranceScoreFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.insurance_score_factor, insurance_score_factor_key);
    insurance_score_factor = parseFloat(insuranceScoreFactorTable[type_constant]);
  }
  return insurance_score_factor;
}

function getHomeTypeFactor(policy_usage, home_type, type_constant, coverage_constant)
{
  let home_type_factor = ratingConstants.numberConstants.one;
  if (home_type != null)
  {
    let home_type_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + home_type + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let homeTypeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.home_type_factor, home_type_factor_key);
    home_type_factor = parseFloat(homeTypeFactorTable[type_constant]);
  }
  return home_type_factor;
}

function getOccupancyFactor(policy_usage, type_constant, coverage_constant)
{
  let occupancy_factor = ratingConstants.numberConstants.one;
  if (policy_usage != null)
  {
    let occupancy_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let occupancyFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.occupancy_factor, occupancy_factor_key);
    occupancy_factor = parseFloat(occupancyFactorTable[type_constant]);
  }
  return occupancy_factor;
}

function getCommunityStatusFactor(unit_location, type_constant, coverage_constant)
{
  let community_status_factor = ratingConstants.numberConstants.one;
  if (unit_location != null)
  {
    let community_status_factor_key = ratingHelpers.getUnitLocation(unit_location) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let communityStatusFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.community_status_factor, community_status_factor_key);
    community_status_factor = parseFloat(communityStatusFactorTable[type_constant]);
  }
  return community_status_factor;
}

function getRoofConditionFactor(roof_condition, type_constant, coverage_constant)
{
  let roof_condition_factor = ratingConstants.numberConstants.one;
  if (roof_condition != null)
  {
    let roof_condition_factor_key = roof_condition + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let roofConditionFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.roof_conditon_factor_table, roof_condition_factor_key);
    roof_condition_factor = parseFloat(roofConditionFactorTable[type_constant]);
  }
  return roof_condition_factor;
}

function getRoofAgeFactor(age_of_roof, roof_condition, model_year, type_constant, coverage_constant)
{
  let roof_age_factor = ratingConstants.numberConstants.one;
  if (age_of_roof != null && roof_condition != null)
  {
    let roof_age_factor_key = roof_condition + ratingConstants.tableToObjectConstants.pipe + age_of_roof + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getAgeOfHomeForFactor(model_year) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;

    let roofAgeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.roof_age_factor, roof_age_factor_key);

    roof_age_factor = parseFloat(roofAgeFactorTable[type_constant]);
  }
  return roof_age_factor;
}

function getRoofMaterialFactor(roof_material, type_constant, coverage_constant)
{
  let roof_material_factor = ratingConstants.numberConstants.one;
  if (roof_material != null && roof_material != undefined)
  {
    let roof_material_factor_key = ratingHelpers.getRoofMaterial(roof_material) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let roofMaterialFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.roof_material_factor, roof_material_factor_key);
    roof_material_factor = parseFloat(roofMaterialFactorTable[type_constant]);
  }
  return roof_material_factor;
}

function getSettlementOptionFactor(settlement_option, type_constant, coverage_constant)
{
  let settlement_option_factor = ratingConstants.numberConstants.one;
  if (settlement_option != null)
  {
    let settlement_option_factor_key = settlement_option + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let settlementOptionFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.settlement_option_factor, settlement_option_factor_key);
    settlement_option_factor = parseFloat(settlementOptionFactorTable[type_constant]);
  }
  return settlement_option_factor;
}

function getCoverageLimitFactor(policy_usage, coverage_limit, type_constant, coverage_constant)
{
  let coverage_limit_factor;
  let coverage_limit_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getCoverageLimit(coverage_limit) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
  let coverageLimitFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.coverage_limit_factor, coverage_limit_factor_key);
  coverage_limit_factor = parseFloat(coverageLimitFactorTable[type_constant]);
  return coverage_limit_factor;
}

function getAssociationDiscountFactor(association_discount, type_constant, coverage_constant)
{
  let association_discount_factor = ratingConstants.numberConstants.one;
  if (association_discount == ratingConstants.binaryConstants.no)
  {
    let association_discount_factor_key = association_discount + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let associationDiscountFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.association_discount_factor, association_discount_factor_key);
    association_discount_factor = parseFloat(associationDiscountFactorTable[type_constant]);
  }
  if (association_discount == ratingConstants.binaryConstants.yes)
  {
    let association_discount_factor_key = association_discount + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let associationDiscountFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.association_discount_factor, association_discount_factor_key);
    association_discount_factor = parseFloat(associationDiscountFactorTable[type_constant]);
  }
  return association_discount_factor;
}

function getClaimsFreeDiscountFactor(number_of_claims_for_discount, type_constant, coverage_constant)
{
  let claims_free_discount_factor;
  if (number_of_claims_for_discount > 0)
  {
    let claims_free_discount_factor_key = ratingConstants.numberConstants.one + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let claimsFreeDiscountFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.claims_free_discount_factor, claims_free_discount_factor_key);
    claims_free_discount_factor = parseFloat(claimsFreeDiscountFactorTable[type_constant]);
  }
  else if (number_of_claims_for_discount == 0)
  {
    let claims_free_discount_factor_key = ratingConstants.numberConstants.zero + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let claimsFreeDiscountFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.claims_free_discount_factor, claims_free_discount_factor_key);
    claims_free_discount_factor = parseFloat(claimsFreeDiscountFactorTable[type_constant]);
  }
  return claims_free_discount_factor;
}

function getCommunityPolicyDiscountFactor(community_policy_discount, type_constant, coverage_constant)
{
  let community_policy_discount_factor = ratingConstants.numberConstants.one;
  if (community_policy_discount == ratingConstants.binaryConstants.no)
  {
    let community_policy_discount_factor_key = community_policy_discount + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let communityPolicyDiscountTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.community_policy_discount_factor, community_policy_discount_factor_key);
    community_policy_discount_factor = parseFloat(communityPolicyDiscountTable[type_constant]);
  }
  if (community_policy_discount == ratingConstants.binaryConstants.yes)
  {
    let community_policy_discount_factor_key = community_policy_discount + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let communityPolicyDiscountTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.community_policy_discount_factor, community_policy_discount_factor_key);
    community_policy_discount_factor = parseFloat(communityPolicyDiscountTable[type_constant]);
  }
  return community_policy_discount_factor;
}

function getMultiPolicyDiscountFactor(multi_policy_discount, type_constant, coverage_constant)
{
  let multi_policy_discount_factor;
  if (multi_policy_discount == ratingConstants.binaryConstants.no)
  {
    let multi_policy_discount_factor_key = ratingConstants.numberConstants.one + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let multiPolicyDiscountFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.multi_policy_discount_factor, multi_policy_discount_factor_key);
    multi_policy_discount_factor = parseFloat(multiPolicyDiscountFactorTable[type_constant]);
  }
  else if (multi_policy_discount == ratingConstants.binaryConstants.yes)
  {
    let multi_policy_discount_factor_key = ratingConstants.numberConstants.two + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let multiPolicyDiscountFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.multi_policy_discount_factor, multi_policy_discount_factor_key);
    multi_policy_discount_factor = parseFloat(multiPolicyDiscountFactorTable[type_constant]);
  }
  return multi_policy_discount_factor;
}

function getMultiUnitDiscountFactor(num_of_exposures, type_constant, coverage_constant)
{
  let multi_unit_discount_factor;
  if (num_of_exposures == ratingConstants.numberConstants.one)
  {
    let multi_unit_discount_factor_key = ratingConstants.numberConstants.one + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let multiUnitDiscountFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.multi_unit_discount_factor, multi_unit_discount_factor_key);
    multi_unit_discount_factor = parseFloat(multiUnitDiscountFactorTable[type_constant]);
  }
  else if (num_of_exposures > ratingConstants.numberConstants.one)
  {
    let multi_unit_discount_factor_key = num_of_exposures + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let multiUnitDiscountFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.multi_unit_discount_factor, multi_unit_discount_factor_key);
    multi_unit_discount_factor = parseFloat(multiUnitDiscountFactorTable[type_constant]);
  }
  return multi_unit_discount_factor;
}

function getPaidInFullDiscountFactor(payment_schedule, type_constant, coverage_constant)
{
  let paid_in_full_discount_factor = ratingConstants.numberConstants.one;
  if (payment_schedule == ratingConstants.paymentConstants.full_pay)
  {
    let paid_in_full_discount_factor_key = payment_schedule + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let paidInFullDiscountFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.paid_in_full_discount_factor, paid_in_full_discount_factor_key);
    paid_in_full_discount_factor = parseFloat(paidInFullDiscountFactorTable[type_constant]);
  }
  return paid_in_full_discount_factor;
}

function getClaimsSurchargeFactor(number_of_claims_for_surcharge, exposures, exposure, policy_usage, type_constant, coverage_constant)
{
  let claims_surcharge_factor;
  if (number_of_claims_for_surcharge >= ratingConstants.numberConstants.zero)
  {
    let schedule;
    if (exposure.name == ratingConstants.exposureNameConstants.vacant)
    {
      schedule = ratingHelpers.getSchedule(exposures);
    }
    else
    {
      schedule = ratingConstants.alphabetConstants.na;
    }
    let claims_surcharge_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + schedule + ratingConstants.tableToObjectConstants.pipe + number_of_claims_for_surcharge + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let claimsSurchargeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.claims_surcharge_factor, claims_surcharge_factor_key);
    claims_surcharge_factor = parseFloat(claimsSurchargeFactorTable[type_constant]);
  }
  return claims_surcharge_factor;
}

function getShortTermRentalSurchargeFactor(exposure, exposure_fgv, exposure_fv, type_constant, coverage_constant)
{
  let short_term_rental_surcharge_factor;
  let short_term_rental_surcharge = ratingConstants.binaryConstants.no;
  if (exposure.name == ratingConstants.exposureNameConstants.landlord_occupied)
  {
    short_term_rental_surcharge = exposure_fgv[exposure_fv.usage].short_term_rental_surcharge;
  }

  if (short_term_rental_surcharge == ratingConstants.binaryConstants.yes)
  {
    let short_term_rental_surcharge_key = ratingConstants.binaryConstants.yes + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let shortTermRentalSurchargeTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.short_term_rental_surcharge_factor, short_term_rental_surcharge_key);
    short_term_rental_surcharge_factor = parseFloat(shortTermRentalSurchargeTable[type_constant]);
  }
  else
  {
    let short_term_rental_surcharge_key = ratingConstants.binaryConstants.no + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let shortTermRentalSurchargeTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.short_term_rental_surcharge_factor, short_term_rental_surcharge_key);
    short_term_rental_surcharge_factor = parseFloat(shortTermRentalSurchargeTable[type_constant]);
  }
  return short_term_rental_surcharge_factor;
}

function getPaperlessDiscountFactor(paperless_discount, policy_usage, coverage_constant)
{
  let paperless_discount_factor = ratingConstants.numberConstants.zero;
  if (policy_usage != ratingConstants.usageConstants.tenant && coverage_constant != ratingConstants.coverageConstants.coverage_c || policy_usage == ratingConstants.usageConstants.tenant  && coverage_constant == ratingConstants.coverageConstants.coverage_c)
  {
    if (paperless_discount == ratingConstants.binaryConstants.yes)
    {
      let paperless_discount_factor_key = paperless_discount + ratingConstants.tableToObjectConstants.pipe + policy_usage + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      paperless_discount_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.paperless_discount_factor, paperless_discount_factor_key));
    }
    else if (paperless_discount == ratingConstants.binaryConstants.no)
    {
      let paperless_discount_factor_key = paperless_discount + ratingConstants.tableToObjectConstants.pipe + policy_usage + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      paperless_discount_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.paperless_discount_factor, paperless_discount_factor_key));
    }
  }
  return paperless_discount_factor;
}

function getSupplementalHeatingSurchargeFactor(source_of_heat, coverage_constant)
{
  let supplemental_heating_surcharge_factor = ratingConstants.numberConstants.zero;

  if (source_of_heat == ratingConstants.binaryConstants.yes)
  {
    let supplemental_heating_surcharge_factor_key = ratingConstants.binaryConstants.yes + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    supplemental_heating_surcharge_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.supplemental_heating_surcharge_factor, supplemental_heating_surcharge_factor_key));
  }
  else if (source_of_heat == ratingConstants.binaryConstants.no)
  {
    let supplemental_heating_surcharge_factor_key = ratingConstants.binaryConstants.no + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    supplemental_heating_surcharge_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.supplemental_heating_surcharge_factor, supplemental_heating_surcharge_factor_key));
  }
  return supplemental_heating_surcharge_factor;
}

exports.getFormFactor = getFormFactor;
exports.getRoofAgeFactor = getRoofAgeFactor;
exports.getNumberOfClaims = getNumberOfClaims;
exports.getHomeTypeFactor = getHomeTypeFactor;
exports.getAgeOfHomeFactor = getAgeOfHomeFactor;
exports.getOccupancyFactor = getOccupancyFactor;
exports.getTerritoryFactor = getTerritoryFactor;
exports.getAgeOfInsuredFactor = getAgeOfInsuredFactor;
exports.getRoofMaterialFactor = getRoofMaterialFactor;
exports.getRoofConditionFactor = getRoofConditionFactor;
exports.getCoverageLimitFactor = getCoverageLimitFactor;
exports.getCalendarYearModifier = getCalendarYearModifier;
exports.getInsuranceScoreFactor = getInsuranceScoreFactor;
exports.getClaimsSurchargeFactor = getClaimsSurchargeFactor;
exports.getCommunityStatusFactor = getCommunityStatusFactor;
exports.getSettlementOptionFactor = getSettlementOptionFactor;
exports.getPaperlessDiscountFactor = getPaperlessDiscountFactor;
exports.getMultiUnitDiscountFactor = getMultiUnitDiscountFactor;
exports.getDistributionChanelFactor = getDistributionChanelFactor;
exports.getPaidInFullDiscountFactor = getPaidInFullDiscountFactor;
exports.getClaimsFreeDiscountFactor = getClaimsFreeDiscountFactor;
exports.getPriorLapseSurchageFactor = getPriorLapseSurchageFactor;
exports.getMultiPolicyDiscountFactor = getMultiPolicyDiscountFactor;
exports.getAssociationDiscountFactor = getAssociationDiscountFactor;
exports.getCommunityPolicyDiscountFactor = getCommunityPolicyDiscountFactor;
exports.getShortTermRentalSurchargeFactor = getShortTermRentalSurchargeFactor;
exports.getSupplementalHeatingSurchargeFactor = getSupplementalHeatingSurchargeFactor;
exports.getAOPorWindDeductibleFactorandOccasionalRenatalFactor = getAOPorWindDeductibleFactorandOccasionalRenatalFactor;