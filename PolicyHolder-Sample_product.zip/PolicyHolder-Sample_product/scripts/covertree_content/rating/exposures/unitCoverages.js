"use strict";

let ratingConstants = require("../ratingConstants.js");
let ratingHelpers = require("../helpersRating.js");
let coverageC = require("./perils/coverageC.js");

function getPremiumForCoverageEPremisesLiability(peril, data)
{
  let exposures = data.policy.exposures;
  let perils = exposures.flatMap((ex) => ex.perils);
  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let trampoline_liability_extension_factor = ratingConstants.numberConstants.one;
  let diving_board_slide_liability_extension_factor = ratingConstants.numberConstants.one;
  let coverage_e_premises_liability_base_rate = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.premises_liability_table, ratingHelpers.getpremisesliabilitylimitKey(peril_fv.premises_liability_limit)));
  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    if (otherPeril.name == ratingConstants.perilNameConstants.trampoline_liability_extension)
    {
      trampoline_liability_extension_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.trampoline_liability_extension_factor_table, ratingConstants.tableKeyConstants.rate));
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.diving_board_slide_liability_extension)
    {
      diving_board_slide_liability_extension_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.diving_board_slide_liability_extension_table, ratingConstants.tableKeyConstants.rate));
    }
  }
  let coverage_e_premises_liability_premium = coverage_e_premises_liability_base_rate * trampoline_liability_extension_factor * diving_board_slide_liability_extension_factor;
  return Math.round(coverage_e_premises_liability_premium);
}

function getPremiumForCoverageEPersonalLiability(peril, data)
{
  let exposures = data.policy.exposures;
  let exposureLocator = peril.exposureLocator;
  let exposure = exposures.find((e) => e.locator == exposureLocator);
  let perils = exposures.flatMap((ex) => ex.perils);
  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
  let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
  let trampoline_liability_extension_factor = ratingConstants.numberConstants.one;
  let diving_board_slide_liability_extension_factor = ratingConstants.numberConstants.one;
  let personal_liability_base_rate;
  let policy_usage = exposure_fgv[exposure_fv.usage].policy_usage;
  let flag = false;
  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_c)
    {
      flag = true;
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.trampoline_liability_extension)
    {
      trampoline_liability_extension_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.trampoline_liability_extension_factor_table, ratingConstants.tableKeyConstants.rate));
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.diving_board_slide_liability_extension)
    {
      diving_board_slide_liability_extension_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.diving_board_slide_liability_extension_table, ratingConstants.tableKeyConstants.rate));
    }
  }
  if (policy_usage == ratingConstants.usageConstants.tenant && flag == false)
  {
    let personal_liability_key = (ratingConstants.personalLiabilityConstants.liability_only + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getpersonalliabilitylimitKey(peril_fv.personal_liability));
    personal_liability_base_rate = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.personal_liability_table, personal_liability_key));
  }
  else
  {
    let personal_liability_key = (ratingConstants.personalLiabilityConstants.Package + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getpersonalliabilitylimitKey(peril_fv.personal_liability));
    personal_liability_base_rate = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.personal_liability_table, personal_liability_key));
  }
  let coverage_e_personal_liability_premium = personal_liability_base_rate * trampoline_liability_extension_factor * diving_board_slide_liability_extension_factor;
  return Math.round(coverage_e_personal_liability_premium);
}

function getPremiumForCoverageF(peril, data)
{
  let exposures = data.policy.exposures;
  let perils = exposures.flatMap((ex) => ex.perils);
  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let trampoline_liability_extension_factor = ratingConstants.numberConstants.one;
  let diving_board_slide_liability_extension_factor = ratingConstants.numberConstants.one;
  let coverage_f_base_rate = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.coverage_f_base_rates, ratingHelpers.getMedicalPaymentsLimitKey(peril_fv.medical_payment_to_others_limit_PerPerson)));
  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    if (otherPeril.name == ratingConstants.perilNameConstants.trampoline_liability_extension)
    {
      trampoline_liability_extension_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.trampoline_liability_extension_factor_table, ratingConstants.tableKeyConstants.rate));
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.diving_board_slide_liability_extension)
    {
      diving_board_slide_liability_extension_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.diving_board_slide_liability_extension_table, ratingConstants.tableKeyConstants.rate));
    }
  }
  let coverage_f_premium = coverage_f_base_rate * trampoline_liability_extension_factor * diving_board_slide_liability_extension_factor;
  return Math.round(coverage_f_premium);
}

function getPremiumForCoverageD(peril, data)
{
  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let exposures = data.policy.exposures;
  let exposureLocator = peril.exposureLocator;
  let exposure = exposures.find((e) => e.locator == exposureLocator);
  let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
  let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;

  let policy_usage = exposure_fgv[exposure_fv.usage].policy_usage;
  let loss_of_use = ratingHelpers.getDecimalFromPercentage(peril_fv.loss_of_use_percentage);

  let baseRateTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.coverage_base_rates, ratingConstants.coverageConstants.coverage_d);
  let AOP_coverage_d_base_rate = parseFloat(baseRateTable[ratingConstants.valueConstants.all_other_perils]);

  let distribution_channel_factor_key = ratingHelpers.getChannel(policy_fv.application_intiation) + ratingConstants.tableToObjectConstants.pipe + ratingConstants.coverageConstants.coverage_d;
  let distributionChannelFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.distribution_channel_factor, distribution_channel_factor_key);
  let distribution_channel_factor = parseFloat(distributionChannelFactorTable[ratingConstants.valueConstants.all_other_perils]);

  let coverage_limit_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + loss_of_use + ratingConstants.tableToObjectConstants.pipe + ratingConstants.coverageConstants.coverage_d;
  let coverageLimitFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.coverage_limit_factor, coverage_limit_factor_key);
  let coverage_limit_factor = parseFloat(coverageLimitFactorTable[ratingConstants.valueConstants.all_other_perils]);

  let AOP_coverage_d_premium = AOP_coverage_d_base_rate * distribution_channel_factor * coverage_limit_factor;

  let wind_or_hail_coverage_d_base_rate = parseFloat(baseRateTable[ratingConstants.valueConstants.windstorm_or_hail]);

  let windOrHailDistributionChannelFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.distribution_channel_factor, distribution_channel_factor_key);
  let wind_or_hail_distribution_channel_factor = parseFloat(windOrHailDistributionChannelFactorTable[ratingConstants.valueConstants.windstorm_or_hail]);

  let wind_or_hail_coverage_limit_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + loss_of_use + ratingConstants.tableToObjectConstants.pipe + ratingConstants.coverageConstants.coverage_d;
  let windOrHailcoverageLimitFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.coverage_limit_factor, wind_or_hail_coverage_limit_factor_key);
  let wind_or_hail_coverage_limit_factor = parseFloat(windOrHailcoverageLimitFactorTable[ratingConstants.valueConstants.windstorm_or_hail]);

  let wind_or_hail_coverage_d_premium = wind_or_hail_coverage_d_base_rate * wind_or_hail_distribution_channel_factor * wind_or_hail_coverage_limit_factor;

  let coverage_d_premium = wind_or_hail_coverage_d_premium + AOP_coverage_d_premium;
  return Math.round(coverage_d_premium);
}

function getPremiumForTheftLimitation(perils, data)
{
  let cov_c_aop;
  let cov_c_wind;
  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_c)
    {
      let AOP_coverage_c_peril_total = coverageC.getAOPCoverageCPremium(otherPeril, data);
      let windstorm_or_hail_cov_c_peril_total = coverageC.getWindstormOrHailCoverageCPremium(otherPeril, data);
      cov_c_aop = AOP_coverage_c_peril_total.AOP_coverage_c_premium;
      cov_c_wind = windstorm_or_hail_cov_c_peril_total.wind_hail_coverage_c_premium;
    }
  }
  let theft_limitation_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.theft_limitation, ratingConstants.tableKeyConstants.theft_limitation));
  let theft_limitation_coverage_c_premium = Math.round(cov_c_aop * (theft_limitation_factor - 1));
  let wind_or_hail_theft_limitation_coverage_c_premium = Math.round(cov_c_wind * (theft_limitation_factor - 1));
  return Math.round(wind_or_hail_theft_limitation_coverage_c_premium + theft_limitation_coverage_c_premium);
}

exports.getPremiumForCoverageEPersonalLiability = getPremiumForCoverageEPersonalLiability;
exports.getPremiumForCoverageEPremisesLiability = getPremiumForCoverageEPremisesLiability;
exports.getPremiumForCoverageF = getPremiumForCoverageF;
exports.getPremiumForCoverageD = getPremiumForCoverageD;
exports.getPremiumForTheftLimitation = getPremiumForTheftLimitation;