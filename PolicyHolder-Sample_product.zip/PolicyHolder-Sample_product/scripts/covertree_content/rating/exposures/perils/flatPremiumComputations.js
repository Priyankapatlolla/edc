"use strict";

let ratingConstants = require("../../ratingConstants.js");
let ratingHelpers = require("../../helpersRating.js");

function getPremiumForHobbyFarming()
{
  return Math.round(parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.flat_premium, ratingConstants.flatPremiumKeys.hobby_farming)));
}

function getPremiumForRoofExclusion()
{
  return Math.round(parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.flat_premium, ratingConstants.flatPremiumKeys.roof_exclusion)));
}

function getPremiumForEnhancedCoverage()
{
  return Math.round(parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.flat_premium, ratingConstants.flatPremiumKeys.enhanced_coverage)));
}

function getPremiumForSpecificStructureExclusion()
{
  return Math.round(parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.flat_premium, ratingConstants.flatPremiumKeys.specific_structure_exclusion)));
}

function getPremiumForWaterBackupandSumpOverflow(peril)
{
  return Math.round(parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.water_backup_and_sump_overflow, ratingHelpers.getwaterBackupAndSumpOverflowKey(peril.characteristics[peril.characteristics.length - 1].fieldValues.water_backup_and_sump_overflow_limit))));
}

function getPremiumForDebrisRemoval(peril)
{
  return Math.round(parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.debris_removal, ratingHelpers.getDebrisRemovalkey(peril.characteristics[peril.characteristics.length - 1].fieldValues.debris_removal_limit))));
}

function getPremiumForAnimalLiability(peril)
{
  return Math.round(parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.animal_liability, ratingHelpers.getAnimalLiabilityLimitKey(peril.characteristics[peril.characteristics.length - 1].fieldValues.animal_liability_limit))));
}

function getPremiumForGolfCart(peril)
{
  return Math.round(peril.characteristics[peril.characteristics.length - 1].fieldValues.no_of_golf_carts * parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.flat_premium, ratingConstants.flatPremiumKeys.golf_cart)));
}

function getPremiumForLossAssessment(peril)
{
  return Math.round(parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.loss_assessment, ratingHelpers.getLossAssessmentKey(peril.characteristics[peril.characteristics.length - 1].fieldValues.loss_assessment_limit))));
}

function getPremiumForLandlordPersonalInjury(peril, data)
{
  let premises_liability_limit;
  let exposures = data.policy.exposures;
  let perils = exposures.flatMap((ex) => ex.perils);

  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_e_premises_liability)
    {
      premises_liability_limit = otherPeril.characteristics[peril.characteristics.length - 1].fieldValues.premises_liability_limit;
    }
  }
  return Math.round(parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.landlord_personal_injury, ratingHelpers.getpremisesliabilitylimitKey(premises_liability_limit))));
}

function getPremiumForTripCollision(peril, exposures)
{
  let exposureLocator = peril.exposureLocator;
  let exposure = exposures.find((e) => e.locator == exposureLocator);
  let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
  let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
  return Math.round(parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.trip_collison_coverage, exposure_fgv[exposure_fv.unit_construction].home_type)));
}

exports.getPremiumForDebrisRemoval = getPremiumForDebrisRemoval;
exports.getPremiumForAnimalLiability = getPremiumForAnimalLiability;
exports.getPremiumForWaterBackupandSumpOverflow = getPremiumForWaterBackupandSumpOverflow;
exports.getPremiumForEnhancedCoverage = getPremiumForEnhancedCoverage;
exports.getPremiumForSpecificStructureExclusion = getPremiumForSpecificStructureExclusion;
exports.getPremiumForRoofExclusion = getPremiumForRoofExclusion;
exports.getPremiumForHobbyFarming = getPremiumForHobbyFarming;
exports.getPremiumForLossAssessment = getPremiumForLossAssessment;
exports.getPremiumForGolfCart = getPremiumForGolfCart;
exports.getPremiumForLandlordPersonalInjury = getPremiumForLandlordPersonalInjury;
exports.getPremiumForTripCollision = getPremiumForTripCollision;