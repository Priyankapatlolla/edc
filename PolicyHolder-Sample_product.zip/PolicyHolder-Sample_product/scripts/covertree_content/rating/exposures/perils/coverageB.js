"use strict";

let ratingConstants = require("../../ratingConstants.js");
let ratingHelpers = require("../../helpersRating.js");
let coverageSupportFuntions = require("../coverageSupportingFunctions.js");

function getPremiumForCoverageB(peril, data)
{
  let coverage_b_aop_premium = getAOPCoverageBPremium(peril, data);
  let coverage_b_windhail_premium = getWindstormOrHailCoverageBPremium(peril, data);

  let coverage_b_premium = Math.round(coverage_b_aop_premium.AOP_coverage_b_premium) + Math.round(coverage_b_windhail_premium.wind_hail_coverage_b_premium);
  let coverage_b_association_discount_amount = coverage_b_aop_premium.aop_association_discount_amount + coverage_b_windhail_premium.wind_hail_association_discount_amount;
  let coverage_b_multi_policy_discount_amount = coverage_b_aop_premium.aop_multi_policy_discount_amount + coverage_b_windhail_premium.wind_hail_multi_policy_discount_amount;
  let coverage_b_multi_unit_discount_amount = coverage_b_aop_premium.aop_multi_unit_discount_amount + coverage_b_windhail_premium.wind_hail_multi_unit_discount_amount;
  let coverage_b_claims_free_discount_amount = coverage_b_aop_premium.aop_claims_free_discount_amount + coverage_b_windhail_premium.wind_hail_claims_free_discount_amount;
  let coverage_b_paid_in_full_discount_amount = coverage_b_aop_premium.aop_paid_in_full_discount_amount + coverage_b_windhail_premium.wind_hail_paid_in_full_discount_amount;
  let coverage_b_community_discount_amount = coverage_b_aop_premium.aop_community_policy_discount_amount + coverage_b_windhail_premium.wind_hail_community_policy_discount_amount;

  return {
    coverage_b_premium,
    coverage_b_association_discount_amount,
    coverage_b_multi_policy_discount_amount,
    coverage_b_multi_unit_discount_amount,
    coverage_b_claims_free_discount_amount,
    coverage_b_paid_in_full_discount_amount,
    coverage_b_community_discount_amount
  };
}

function getAOPCoverageBPremium(peril, data)
{
  let type_constant = ratingConstants.valueConstants.all_other_perils;
  let coverage_constant = ratingConstants.coverageConstants.coverage_b;
  let exposures = data.policy.exposures;
  let exposureLocator = peril.exposureLocator;
  let perils = exposures.flatMap((ex) => ex.perils);
  let exposure = exposures.find((e) => e.locator == exposureLocator);

  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
  let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;

  let policy_usage = exposure_fgv[exposure_fv.usage].policy_usage;
  let territory_code = exposure_fgv[exposure_fv.territory].territory_code_aop;
  let territory_factor = coverageSupportFuntions.getTerritoryFactor(territory_code, type_constant, coverage_constant);

  let policy_term = ratingHelpers.getPolicyTerm(data);
  let prior_lapse_surcharge_factor = coverageSupportFuntions.getPriorLapseSurchageFactor(exposure_fgv, exposure_fv, policy_fgv, policy_fv, policy_term, type_constant, coverage_constant);

  let baseRateTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.coverage_base_rates, ratingConstants.coverageConstants.coverage_b);
  let AOP_coverage_b_base_rate = parseFloat(baseRateTable[ratingConstants.valueConstants.all_other_perils]);

  let age_of_home_factor = coverageSupportFuntions.getAgeOfHomeFactor(exposure_fgv, exposure_fv, policy_usage, type_constant, coverage_constant);

  let date_of_birth = policy_fgv[policy_fv.policy_basic_info].date_of_birth;
  let age_of_insured_factor = coverageSupportFuntions.getAgeOfInsuredFactor(date_of_birth, type_constant, coverage_constant);

  let policy_start_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;
  let calendar_year_modifier_factor = coverageSupportFuntions.getCalendarYearModifier(policy_start_timestamp, type_constant, coverage_constant);

  let coverage_limit = peril_fv.other_structures_limit;
  let aop_wind_hail_occasional_factors = coverageSupportFuntions.getAOPorWindDeductibleFactorandOccasionalRenatalFactor(policy_usage, data, perils, coverage_limit, type_constant, coverage_constant);
  let occasional_vacation_rental_factor = aop_wind_hail_occasional_factors.occasional_vacation_rental_factor;
  let aop_deductible_factor = aop_wind_hail_occasional_factors.deductible_factor;

  let application_intiation = policy_fv.application_intiation;
  let distribution_channel_factor = coverageSupportFuntions.getDistributionChanelFactor(application_intiation, type_constant, coverage_constant);

  let form = exposure_fgv[exposure_fv.unit_details].form;
  let form_factor = coverageSupportFuntions.getFormFactor(form, type_constant, coverage_constant)

  let insurance_score = policy_fv.insurance_score;
  let insurance_score_factor = coverageSupportFuntions.getInsuranceScoreFactor(insurance_score, type_constant, coverage_constant);

  let home_type = exposure_fgv[exposure_fv.unit_construction].home_type;
  let home_type_factor = coverageSupportFuntions.getHomeTypeFactor(policy_usage, home_type, type_constant, coverage_constant);

  let occupancy_factor = coverageSupportFuntions.getOccupancyFactor(policy_usage, type_constant, coverage_constant);

  let unit_location = exposure_fgv[exposure_fv.unit_details].unit_location;
  let community_status_factor = coverageSupportFuntions.getCommunityStatusFactor(unit_location, type_constant, coverage_constant);

  let roof_condition = exposure_fgv[exposure_fv.unit_construction].roof_condition;
  let age_of_roof = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].roof_year_yyyy);
  let model_year = exposure_fgv[exposure_fv.unit_construction].model_year;

  let roof_age_factor = coverageSupportFuntions.getRoofAgeFactor(age_of_roof, roof_condition, model_year, type_constant, coverage_constant);
  let roof_condition_factor = coverageSupportFuntions.getRoofConditionFactor(roof_condition, type_constant, coverage_constant);

  let roof_material = exposure_fgv[exposure_fv.unit_construction].roof_material;
  let roof_material_factor = coverageSupportFuntions.getRoofMaterialFactor(roof_material, type_constant, coverage_constant);

  let settlement_option = peril_fv.cov_b_settlement_option;
  let settlement_option_factor = coverageSupportFuntions.getSettlementOptionFactor(settlement_option, type_constant, coverage_constant);

  let coverage_limit_factor = coverageSupportFuntions.getCoverageLimitFactor(policy_usage, coverage_limit, type_constant, coverage_constant);


  let association_discount = policy_fv.association_discount;
  let association_discount_factor = coverageSupportFuntions.getAssociationDiscountFactor(association_discount, type_constant, coverage_constant);

  let number_of_prior_claims = coverageSupportFuntions.getNumberOfClaims(policy_fv, policy_fgv);
  let number_of_claims_for_discount = number_of_prior_claims.number_of_claims_for_discount;
  let number_of_claims_for_surcharge = number_of_prior_claims.number_of_claims_for_surcharge;

  let claims_free_discount_factor = coverageSupportFuntions.getClaimsFreeDiscountFactor(number_of_claims_for_discount, type_constant, coverage_constant);

  let community_policy_discount = exposure_fgv[exposure_fv.unit_details].community_policy_discount;
  let community_policy_discount_factor = coverageSupportFuntions.getCommunityPolicyDiscountFactor(community_policy_discount, type_constant, coverage_constant);

  let multi_policy_discount = policy_fv.multi_policy_discount;
  let multi_policy_discount_factor = coverageSupportFuntions.getMultiPolicyDiscountFactor(multi_policy_discount, type_constant, coverage_constant);

  let num_of_exposures = ratingHelpers.getNumberOfExposures(exposures);
  let multi_unit_discount_factor = coverageSupportFuntions.getMultiUnitDiscountFactor(num_of_exposures, type_constant, coverage_constant);

  let payment_schedule = data.policy.paymentScheduleName;
  let paid_in_full_discount_factor = coverageSupportFuntions.getPaidInFullDiscountFactor(payment_schedule, type_constant, coverage_constant);


  let claims_surcharge_factor = coverageSupportFuntions.getClaimsSurchargeFactor(number_of_claims_for_surcharge, exposures, exposure, policy_usage, type_constant, coverage_constant);

  let short_term_rental_surcharge_factor = coverageSupportFuntions.getShortTermRentalSurchargeFactor(exposure, exposure_fgv, exposure_fv, type_constant, coverage_constant);

  let AOP_coverage_b_premium_without_discounts = AOP_coverage_b_base_rate * age_of_home_factor *
      age_of_insured_factor * distribution_channel_factor * form_factor * insurance_score_factor * home_type_factor *
      occupancy_factor * roof_condition_factor * settlement_option_factor * occasional_vacation_rental_factor *
      coverage_limit_factor * territory_factor * calendar_year_modifier_factor * roof_material_factor * community_status_factor *
      prior_lapse_surcharge_factor * short_term_rental_surcharge_factor * claims_surcharge_factor * aop_deductible_factor * roof_age_factor;

  let aop_cov_b_premium_with_association_discount = AOP_coverage_b_premium_without_discounts * association_discount_factor;
  let aop_association_discount_amount = AOP_coverage_b_premium_without_discounts - aop_cov_b_premium_with_association_discount;

  let aop_cov_b_premium_with_multi_policy_discount = aop_cov_b_premium_with_association_discount * multi_policy_discount_factor;
  let aop_multi_policy_discount_amount = aop_cov_b_premium_with_association_discount - aop_cov_b_premium_with_multi_policy_discount;

  let aop_cov_b_premium_with_multi_unit_discount = aop_cov_b_premium_with_multi_policy_discount * multi_unit_discount_factor;
  let aop_multi_unit_discount_amount = aop_cov_b_premium_with_multi_policy_discount - aop_cov_b_premium_with_multi_unit_discount;

  let aop_cov_b_premium_with_claims_free_discount = aop_cov_b_premium_with_multi_unit_discount * claims_free_discount_factor;
  let aop_claims_free_discount_amount = aop_cov_b_premium_with_multi_unit_discount - aop_cov_b_premium_with_claims_free_discount;

  let aop_cov_b_premium_with_paid_in_full_discount = aop_cov_b_premium_with_claims_free_discount * paid_in_full_discount_factor;
  let aop_paid_in_full_discount_amount = aop_cov_b_premium_with_claims_free_discount - aop_cov_b_premium_with_paid_in_full_discount;

  let aop_cov_b_premium_with_community_policy_dicount = aop_cov_b_premium_with_paid_in_full_discount * community_policy_discount_factor;
  let aop_community_policy_discount_amount = aop_cov_b_premium_with_paid_in_full_discount - aop_cov_b_premium_with_community_policy_dicount;

  let AOP_coverage_b_premium = AOP_coverage_b_premium_without_discounts -
    aop_association_discount_amount -
    aop_multi_policy_discount_amount -
    aop_multi_unit_discount_amount -
    aop_claims_free_discount_amount -
    aop_paid_in_full_discount_amount -
    aop_community_policy_discount_amount

  return {
    AOP_coverage_b_premium,
    aop_association_discount_amount,
    aop_multi_policy_discount_amount,
    aop_multi_unit_discount_amount,
    aop_claims_free_discount_amount,
    aop_paid_in_full_discount_amount,
    aop_community_policy_discount_amount
  }

}

function getWindstormOrHailCoverageBPremium(peril, data)
{

  let type_constant = ratingConstants.valueConstants.windstorm_or_hail;
  let coverage_constant = ratingConstants.coverageConstants.coverage_b;
  let exposures = data.policy.exposures;
  let exposureLocator = peril.exposureLocator;
  let perils = exposures.flatMap((ex) => ex.perils);
  let exposure = exposures.find((e) => e.locator == exposureLocator);
  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
  let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;

  let policy_usage = exposure_fgv[exposure_fv.usage].policy_usage;
  
  let territory_code = exposure_fgv[exposure_fv.territory].territory_code_windhail;
  let territory_factor = coverageSupportFuntions.getTerritoryFactor(territory_code, type_constant, coverage_constant);

  let policy_term = ratingHelpers.getPolicyTerm(data);
  let prior_lapse_surcharge_factor = coverageSupportFuntions.getPriorLapseSurchageFactor(exposure_fgv, exposure_fv, policy_fgv, policy_fv, policy_term, type_constant, coverage_constant);

  let baseRateTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.coverage_base_rates, ratingConstants.coverageConstants.coverage_b);
  let wind_hail_coverage_b_base_rate = parseFloat(baseRateTable[ratingConstants.valueConstants.windstorm_or_hail]);

  let age_of_home_factor = coverageSupportFuntions.getAgeOfHomeFactor(exposure_fgv, exposure_fv, policy_usage, type_constant, coverage_constant);

  let date_of_birth = policy_fgv[policy_fv.policy_basic_info].date_of_birth;
  let age_of_insured_factor = coverageSupportFuntions.getAgeOfInsuredFactor(date_of_birth, type_constant, coverage_constant);

  let policy_start_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;
  let calendar_year_modifier_factor = coverageSupportFuntions.getCalendarYearModifier(policy_start_timestamp, type_constant, coverage_constant);

  let coverage_limit = peril_fv.other_structures_limit;
  let aop_wind_hail_occasional_factors = coverageSupportFuntions.getAOPorWindDeductibleFactorandOccasionalRenatalFactor(policy_usage, data, perils, coverage_limit, type_constant, coverage_constant);
  let occasional_vacation_rental_factor = aop_wind_hail_occasional_factors.occasional_vacation_rental_factor;
  let wind_hail_deductible_factor = aop_wind_hail_occasional_factors.deductible_factor;

  let application_intiation = policy_fv.application_intiation;
  let distribution_channel_factor = coverageSupportFuntions.getDistributionChanelFactor(application_intiation, type_constant, coverage_constant);

  let form = exposure_fgv[exposure_fv.unit_details].form;
  let form_factor = coverageSupportFuntions.getFormFactor(form, type_constant, coverage_constant);

  let insurance_score = policy_fv.insurance_score;
  let insurance_score_factor = coverageSupportFuntions.getInsuranceScoreFactor(insurance_score, type_constant, coverage_constant);

  let home_type = exposure_fgv[exposure_fv.unit_construction].home_type;
  let home_type_factor = coverageSupportFuntions.getHomeTypeFactor(policy_usage, home_type, type_constant, coverage_constant);

  let occupancy_factor = coverageSupportFuntions.getOccupancyFactor(policy_usage, type_constant, coverage_constant);

  let unit_location = exposure_fgv[exposure_fv.unit_details].unit_location;
  let community_status_factor = coverageSupportFuntions.getCommunityStatusFactor(unit_location, type_constant, coverage_constant);

  let age_of_roof = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].roof_year_yyyy);
  let roof_condition = exposure_fgv[exposure_fv.unit_construction].roof_condition;
  let model_year = exposure_fgv[exposure_fv.unit_construction].model_year;

  let roof_age_factor = coverageSupportFuntions.getRoofAgeFactor(age_of_roof, roof_condition, model_year, type_constant, coverage_constant);
  let roof_condition_factor = coverageSupportFuntions.getRoofConditionFactor(roof_condition, type_constant, coverage_constant);

  let roof_material = exposure_fgv[exposure_fv.unit_construction].roof_material;
  let roof_material_factor = coverageSupportFuntions.getRoofMaterialFactor(roof_material, type_constant, coverage_constant);

  let settlement_option = peril_fv.cov_b_settlement_option;
  let settlement_option_factor = coverageSupportFuntions.getSettlementOptionFactor(settlement_option, type_constant, coverage_constant);

  let coverage_limit_factor = coverageSupportFuntions.getCoverageLimitFactor(policy_usage, coverage_limit, type_constant, coverage_constant);

  let association_discount = policy_fv.association_discount;
  let association_discount_factor = coverageSupportFuntions.getAssociationDiscountFactor(association_discount, type_constant, coverage_constant);

  let number_of_prior_claims = coverageSupportFuntions.getNumberOfClaims(policy_fv, policy_fgv);
  let number_of_claims_for_discount = number_of_prior_claims.number_of_claims_for_discount;
  let number_of_claims_for_surcharge = number_of_prior_claims.number_of_claims_for_surcharge;

  let claims_free_discount_factor = coverageSupportFuntions.getClaimsFreeDiscountFactor(number_of_claims_for_discount, type_constant, coverage_constant);

  let community_policy_discount = exposure_fgv[exposure_fv.unit_details].community_policy_discount;
  let community_policy_discount_factor = coverageSupportFuntions.getCommunityPolicyDiscountFactor(community_policy_discount, type_constant, coverage_constant);

  let multi_policy_discount = policy_fv.multi_policy_discount;
  let multi_policy_discount_factor = coverageSupportFuntions.getMultiPolicyDiscountFactor(multi_policy_discount, type_constant, coverage_constant);

  let num_of_exposures = ratingHelpers.getNumberOfExposures(exposures);
  let multi_unit_discount_factor = coverageSupportFuntions.getMultiUnitDiscountFactor(num_of_exposures, type_constant, coverage_constant);

  let payment_schedule = data.policy.paymentScheduleName;
  let paid_in_full_discount_factor = coverageSupportFuntions.getPaidInFullDiscountFactor(payment_schedule, type_constant, coverage_constant);


  let claims_surcharge_factor = coverageSupportFuntions.getClaimsSurchargeFactor(number_of_claims_for_surcharge, exposures, exposure, policy_usage, type_constant, coverage_constant);

  let short_term_rental_surcharge_factor = coverageSupportFuntions.getShortTermRentalSurchargeFactor(exposure, exposure_fgv, exposure_fv, type_constant, coverage_constant);

  let wind_hail_coverage_b_premium_without_discounts = wind_hail_coverage_b_base_rate * age_of_home_factor * age_of_insured_factor * distribution_channel_factor *
    form_factor * insurance_score_factor * home_type_factor * occupancy_factor * roof_condition_factor *
    settlement_option_factor * occasional_vacation_rental_factor * coverage_limit_factor * territory_factor * calendar_year_modifier_factor * roof_material_factor *
    community_status_factor * prior_lapse_surcharge_factor * short_term_rental_surcharge_factor * claims_surcharge_factor *
    wind_hail_deductible_factor * roof_age_factor;

  let wind_hail_cov_b_premium_with_association_discount = wind_hail_coverage_b_premium_without_discounts * association_discount_factor;
  let wind_hail_association_discount_amount = wind_hail_coverage_b_premium_without_discounts - wind_hail_cov_b_premium_with_association_discount;

  let wind_hail_cov_b_premium_with_multi_policy_discount = wind_hail_cov_b_premium_with_association_discount * multi_policy_discount_factor;
  let wind_hail_multi_policy_discount_amount = wind_hail_cov_b_premium_with_association_discount - wind_hail_cov_b_premium_with_multi_policy_discount;

  let wind_hail_cov_b_premium_with_multi_unit_discount = wind_hail_cov_b_premium_with_multi_policy_discount * multi_unit_discount_factor;
  let wind_hail_multi_unit_discount_amount = wind_hail_cov_b_premium_with_multi_policy_discount - wind_hail_cov_b_premium_with_multi_unit_discount;

  let wind_hail_cov_b_premium_with_claims_free_discount = wind_hail_cov_b_premium_with_multi_unit_discount * claims_free_discount_factor;
  let wind_hail_claims_free_discount_amount = wind_hail_cov_b_premium_with_multi_unit_discount - wind_hail_cov_b_premium_with_claims_free_discount;

  let wind_hail_cov_b_premium_with_paid_in_full_discount = wind_hail_cov_b_premium_with_claims_free_discount * paid_in_full_discount_factor;
  let wind_hail_paid_in_full_discount_amount = wind_hail_cov_b_premium_with_claims_free_discount - wind_hail_cov_b_premium_with_paid_in_full_discount;

  let wind_hail_cov_b_premium_with_community_policy_dicount = wind_hail_cov_b_premium_with_paid_in_full_discount * community_policy_discount_factor;
  let wind_hail_community_policy_discount_amount = wind_hail_cov_b_premium_with_paid_in_full_discount - wind_hail_cov_b_premium_with_community_policy_dicount;

  let wind_hail_coverage_b_premium = wind_hail_coverage_b_premium_without_discounts - wind_hail_association_discount_amount -
    wind_hail_multi_policy_discount_amount -
    wind_hail_multi_unit_discount_amount -
    wind_hail_claims_free_discount_amount -
    wind_hail_paid_in_full_discount_amount -
    wind_hail_community_policy_discount_amount
  return {
    wind_hail_coverage_b_premium,
    wind_hail_association_discount_amount,
    wind_hail_multi_policy_discount_amount,
    wind_hail_multi_unit_discount_amount,
    wind_hail_claims_free_discount_amount,
    wind_hail_paid_in_full_discount_amount,
    wind_hail_community_policy_discount_amount
  }

}

exports.getPremiumForCoverageB = getPremiumForCoverageB;
exports.getAOPCoverageBPremium = getAOPCoverageBPremium;
exports.getWindstormOrHailCoverageBPremium = getWindstormOrHailCoverageBPremium;