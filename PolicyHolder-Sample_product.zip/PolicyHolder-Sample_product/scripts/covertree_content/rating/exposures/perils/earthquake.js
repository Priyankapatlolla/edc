"use strict";

let ratingConstants = require("../../ratingConstants.js");
let ratingHelpers = require("../../helpersRating.js");
let coverageSupportFuntions = require("../coverageSupportingFunctions.js")

function getPremiumForEarthquake(peril, data)
{
  let type_constant = ratingConstants.valueConstants.earthquake;
  let earthquake_premium = Math.round(
  getEarthquakeCoveragePremium(peril, data, type_constant, ratingConstants.coverageConstants.coverage_a) +
  getEarthquakeCoveragePremium(peril, data, type_constant, ratingConstants.coverageConstants.coverage_b) +
  getEarthquakeCoveragePremium(peril, data, type_constant, ratingConstants.coverageConstants.coverage_c) +
  getEarthquakeCoverageDPremium(peril, data, type_constant, ratingConstants.coverageConstants.coverage_d));
  
  if (earthquake_premium < 0)
  {
    return Math.round(parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.earthquake_minimum_premium, ratingConstants.tableKeyConstants.rate)));
  }
  else
  {
    return Math.round(earthquake_premium);
  }
}

function getEarthquakeCoveragePremium(peril, data, type_constant, coverage_constant)
{
  let exposures = data.policy.exposures;
  let perils = exposures.flatMap((ex) => ex.perils);
  let exposureLocator = peril.exposureLocator;
  let exposure = exposures.find((e) => e.locator == exposureLocator);
  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
  let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;

  let policy_usage = exposure_fgv[exposure_fv.usage].policy_usage;

  let age_of_home_factor;
  let settlement_option_factor = ratingConstants.numberConstants.one;
  let coverage_limit_factor;
  let territory_factor = ratingConstants.numberConstants.one;
  let earthquake_deductible_factor;
  let age_of_home;

  let baseRateTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.coverage_base_rates, coverage_constant);
  let earthquake_coverage_base_rate = baseRateTable[type_constant];

  let application_intiation = policy_fv.application_intiation;
  let distribution_channel_factor = coverageSupportFuntions.getDistributionChanelFactor(application_intiation, type_constant, coverage_constant);

  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    let otherPeril_fv = otherPeril.characteristics[peril.characteristics.length - 1].fieldValues;
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_a && coverage_constant == ratingConstants.coverageConstants.coverage_a)
    {
      let limit = otherPeril_fv.manufactured_home_limit;
      let settlement_option = otherPeril_fv.cov_a_settlement_option;
      coverage_limit_factor = coverageSupportFuntions.getCoverageLimitFactor(policy_usage, limit, type_constant, coverage_constant);
      if (settlement_option != null)
      {
        settlement_option_factor = coverageSupportFuntions.getSettlementOptionFactor(settlement_option, type_constant, coverage_constant);
      }
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_b && coverage_constant == ratingConstants.coverageConstants.coverage_b)
    {
      let limit = otherPeril_fv.other_structures_limit;
      let settlement_option = otherPeril_fv.cov_b_settlement_option;
      coverage_limit_factor = coverageSupportFuntions.getCoverageLimitFactor(policy_usage, limit, type_constant, coverage_constant);
      if (settlement_option != null)
      {
        settlement_option_factor = coverageSupportFuntions.getSettlementOptionFactor(settlement_option, type_constant, coverage_constant);
      }
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_c && coverage_constant == ratingConstants.coverageConstants.coverage_c)
    {
      let limit = otherPeril_fv.unscheduled_personal_property_limit;
      let settlement_option = otherPeril_fv.cov_c_settlement_option;
      coverage_limit_factor = coverageSupportFuntions.getCoverageLimitFactor(policy_usage, limit, type_constant, coverage_constant);
      if (settlement_option != null)
      {
        settlement_option_factor = coverageSupportFuntions.getSettlementOptionFactor(settlement_option, type_constant, coverage_constant);
      }
    }
  }

  if (exposure.name != ratingConstants.exposureNameConstants.tenant_occupied)
  {
    age_of_home = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].model_year)
  }
  if (policy_usage == ratingConstants.usageConstants.tenant)
  {
    let age_of_home_factor_key = (policy_usage + ratingConstants.tableToObjectConstants.pipe + ratingConstants.numberConstants.zero + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.age_of_home_factor, age_of_home_factor_key);
    age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
  }
  else
  {
    let age_of_home_factor_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + age_of_home + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
    let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.age_of_home_factor, age_of_home_factor_key);
    age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
  }

  let policy_start_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;
  let calendar_year_modifier_factor = coverageSupportFuntions.getCalendarYearModifier(policy_start_timestamp, type_constant, coverage_constant);

  let earthquake_deductible_factor_key = ratingHelpers.getDecimalFromPercentage(peril_fv.earthquake_deductible) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
  earthquake_deductible_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.earthquake_deductible_factor, earthquake_deductible_factor_key));

  let territory_code_earthquake = exposure_fgv[exposure_fv.territory].territory_code_earthquake;
  if (territory_code_earthquake != null)
  {
    let territory_code_key = territory_code_earthquake + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let territoryCodeTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.territory_factor, territory_code_key);
    territory_factor = parseFloat(territoryCodeTable[type_constant]);
  }

  let EarthquakeCoveragePremium = earthquake_coverage_base_rate * age_of_home_factor * calendar_year_modifier_factor *
  earthquake_deductible_factor * distribution_channel_factor * settlement_option_factor * territory_factor * coverage_limit_factor;


  if (!isNaN(EarthquakeCoveragePremium))
  {
    return Math.round(EarthquakeCoveragePremium);
  }
  else
  {
    return ratingConstants.numberConstants.zero;
  }

}

function getEarthquakeCoverageDPremium(peril, data, type_constant, coverage_constant)
{
  let exposures = data.policy.exposures;
  let perils = exposures.flatMap((ex) => ex.perils);
  let exposureLocator = peril.exposureLocator;
  let exposure = exposures.find((e) => e.locator == exposureLocator);
  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
  let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
  let distribution_channel_factor = ratingConstants.numberConstants.one;
  let coverage_limit_factor;
  let earthquake_deductible_factor;

  let policy_usage = exposure_fgv[exposure_fv.usage].policy_usage;

  let application_intiation = policy_fv.application_intiation;
  distribution_channel_factor = coverageSupportFuntions.getDistributionChanelFactor(application_intiation, type_constant, coverage_constant);

  let baseRateTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.coverage_base_rates, coverage_constant);
  let earthquake_coverage_d_base_rate = baseRateTable[type_constant];

  let earthquake_deductible_factor_key = ratingHelpers.getDecimalFromPercentage(peril_fv.earthquake_deductible) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
  earthquake_deductible_factor = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.earthquake_deductible_factor, earthquake_deductible_factor_key));

  let cov_a_limit;
  let cov_d_limit;
  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let otherPeril = perils.find((p) => p.characteristics.some((ch) => ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    let otherPeril_fv = otherPeril.characteristics[peril.characteristics.length - 1].fieldValues;
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_d)
    {
      cov_d_limit = parseFloat(ratingHelpers.getDecimalFromPercentage(otherPeril_fv.loss_of_use_percentage));
    }
    if (otherPeril.name == ratingConstants.perilNameConstants.coverage_a)
    {
      cov_a_limit = parseFloat(otherPeril_fv.manufactured_home_limit);
    }
  }
  if(policy_usage == ratingConstants.usageConstants.tenant)
  {
    let coverage_limit_factor_key = policy_usage + ratingConstants.tableToObjectConstants.pipe + cov_d_limit + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
    let coverageLimitFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.coverage_limit_factor, coverage_limit_factor_key);
    coverage_limit_factor = parseFloat(coverageLimitFactorTable[type_constant]);
  }
  else
  {
  let limit = cov_d_limit * cov_a_limit;
  coverage_limit_factor = coverageSupportFuntions.getCoverageLimitFactor(policy_usage, limit, type_constant, coverage_constant);
  }
  let EarthquakeCoverageDPremium = earthquake_coverage_d_base_rate * earthquake_deductible_factor * distribution_channel_factor * coverage_limit_factor;
  if (!isNaN(EarthquakeCoverageDPremium))
  {
    return Math.round(EarthquakeCoverageDPremium);
  }
  else
  {
    return ratingConstants.numberConstants.zero;
  }
}

exports.getPremiumForEarthquake = getPremiumForEarthquake;