"use strict";

let ratingConstants = require("../../ratingConstants.js");
let ratingHelpers = require("../../helpersRating.js");
let coverageSupportFuntions = require("../coverageSupportingFunctions.js");

function getPremiumForCoverageC(peril, data)
{
  let coverage_c_aop_premium = getAOPCoverageCPremium(peril, data);
  let coverage_c_windhail_premium = getWindstormOrHailCoverageCPremium(peril, data);

  let coverage_c_premium = coverage_c_aop_premium.AOP_coverage_c_premium + coverage_c_windhail_premium.wind_hail_coverage_c_premium;
  let coverage_c_association_discount_amount = coverage_c_aop_premium.aop_association_discount_amount + coverage_c_windhail_premium.wind_hail_association_discount_amount;
  let coverage_c_multi_policy_discount_amount = coverage_c_aop_premium.aop_multi_policy_discount_amount + coverage_c_windhail_premium.wind_hail_multi_policy_discount_amount;
  let coverage_c_paperless_discount_amount = coverage_c_aop_premium.aop_paperless_discount_amount;
  let coverage_c_multi_unit_discount_amount = coverage_c_aop_premium.aop_multi_unit_discount_amount + coverage_c_windhail_premium.wind_hail_multi_unit_discount_amount;
  let coverage_c_claims_free_discount_amount = coverage_c_aop_premium.aop_claims_free_discount_amount + coverage_c_windhail_premium.wind_hail_claims_free_discount_amount;
  let coverage_c_paid_in_full_discount_amount = coverage_c_aop_premium.aop_paid_in_full_discount_amount + coverage_c_windhail_premium.wind_hail_paid_in_full_discount_amount;
  let coverage_c_community_discount_amount = coverage_c_aop_premium.aop_community_policy_discount_amount + coverage_c_windhail_premium.wind_hail_community_policy_discount_amount;

  return {
    coverage_c_premium,
    coverage_c_paperless_discount_amount,
    coverage_c_association_discount_amount,
    coverage_c_multi_policy_discount_amount,
    coverage_c_multi_unit_discount_amount,
    coverage_c_claims_free_discount_amount,
    coverage_c_paid_in_full_discount_amount,
    coverage_c_community_discount_amount
  };
}

function getAOPCoverageCPremium(peril, data)
{
  let type_constant = ratingConstants.valueConstants.all_other_perils;
  let coverage_constant = ratingConstants.coverageConstants.coverage_c;
  let exposures = data.policy.exposures;
  let exposureLocator = peril.exposureLocator;
  let perils = exposures.flatMap((ex) => ex.perils);
  let exposure = exposures.find((e) => e.locator == exposureLocator);

  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
  let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;

  let policy_usage = exposure_fgv[exposure_fv.usage].policy_usage;
  let territory_code = exposure_fgv[exposure_fv.territory].territory_code_aop;
  let territory_factor = coverageSupportFuntions.getTerritoryFactor(territory_code, type_constant, coverage_constant);
  let home_type;
  let roof_condition;
  let roof_material;
  let age_of_roof;
  let age_of_home;
  let age_of_home_factor = ratingConstants.numberConstants.one;
  let roof_age_factor = ratingConstants.numberConstants.one;
  let roof_material_factor = ratingConstants.numberConstants.one;

  if (exposure.name != ratingConstants.exposureNameConstants.tenant_occupied)
  {
    home_type = exposure_fgv[exposure_fv.unit_construction].home_type;
    roof_condition = exposure_fgv[exposure_fv.unit_construction].roof_condition;
    roof_material = exposure_fgv[exposure_fv.unit_construction].roof_material;
    age_of_roof = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].roof_year_yyyy);
    age_of_home = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].model_year);
  }

  let policy_term = ratingHelpers.getPolicyTerm(data);
  let prior_lapse_surcharge_factor = coverageSupportFuntions.getPriorLapseSurchageFactor(exposure_fgv, exposure_fv, policy_fgv, policy_fv, policy_term, type_constant, coverage_constant);

  let baseRateTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.coverage_base_rates, coverage_constant);
  let AOP_coverage_c_base_rate = parseFloat(baseRateTable[type_constant]);

  if (policy_usage != ratingConstants.usageConstants.tenant)
  {
    if (policy_usage == ratingConstants.usageConstants.tenant)
    {
      let age_of_home_factor_key = (ratingConstants.usageConstants.tenant + ratingConstants.tableToObjectConstants.pipe + ratingConstants.numberConstants.zero + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
      let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.age_of_home_factor, age_of_home_factor_key);
      age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
    }
    else
    {
      let age_of_home_factor_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + age_of_home + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
      let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.age_of_home_factor, age_of_home_factor_key);
      age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
    }

    if (age_of_roof != null && roof_condition != null && roof_material != undefined)
    {
      let roof_age_factor_key = roof_condition + ratingConstants.tableToObjectConstants.pipe + age_of_roof + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getAgeOfHomeForFactor(exposure_fgv[exposure_fv.unit_construction].model_year) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      let roofAgeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.roof_age_factor, roof_age_factor_key);
      roof_age_factor = parseFloat(roofAgeFactorTable[type_constant]);
    }

    if (roof_material != null && roof_material != undefined)
    {
      let roof_material_factor_key = ratingHelpers.getRoofMaterial(roof_material) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      let roofMaterialFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.roof_material_factor, roof_material_factor_key);
      roof_material_factor = parseFloat(roofMaterialFactorTable[type_constant]);
    }
  }

  let date_of_birth = policy_fgv[policy_fv.policy_basic_info].date_of_birth;
  let age_of_insured_factor = coverageSupportFuntions.getAgeOfInsuredFactor(date_of_birth, type_constant, coverage_constant);

  let policy_start_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;
  let calendar_year_modifier_factor = coverageSupportFuntions.getCalendarYearModifier(policy_start_timestamp, type_constant, coverage_constant);

  let coverage_limit = peril_fv.unscheduled_personal_property_limit;
  let aop_wind_hail_occasional_factors = coverageSupportFuntions.getAOPorWindDeductibleFactorandOccasionalRenatalFactor(policy_usage, data, perils, coverage_limit, type_constant, coverage_constant);
  let occasional_vacation_rental_factor = aop_wind_hail_occasional_factors.occasional_vacation_rental_factor;
  let aop_deductible_factor = aop_wind_hail_occasional_factors.deductible_factor;

  let application_intiation = policy_fv.application_intiation;
  let distribution_channel_factor = coverageSupportFuntions.getDistributionChanelFactor(application_intiation, type_constant, coverage_constant);

  let form = exposure_fgv[exposure_fv.unit_details].form;
  let form_factor = coverageSupportFuntions.getFormFactor(form, type_constant, coverage_constant)

  let insurance_score = policy_fv.insurance_score;
  let insurance_score_factor = coverageSupportFuntions.getInsuranceScoreFactor(insurance_score, type_constant, coverage_constant);

  let home_type_factor = coverageSupportFuntions.getHomeTypeFactor(policy_usage, home_type, type_constant, coverage_constant);

  let occupancy_factor = coverageSupportFuntions.getOccupancyFactor(policy_usage, type_constant, coverage_constant);

  let unit_location = exposure_fgv[exposure_fv.unit_details].unit_location;
  let community_status_factor = coverageSupportFuntions.getCommunityStatusFactor(unit_location, type_constant, coverage_constant);

  let roof_condition_factor = coverageSupportFuntions.getRoofConditionFactor(roof_condition, type_constant, coverage_constant);

  let settlement_option = peril_fv.cov_c_settlement_option;
  let settlement_option_factor = coverageSupportFuntions.getSettlementOptionFactor(settlement_option, type_constant, coverage_constant);

  let coverage_limit_factor = coverageSupportFuntions.getCoverageLimitFactor(policy_usage, coverage_limit, type_constant, coverage_constant);


  let association_discount = policy_fv.association_discount;
  let association_discount_factor = coverageSupportFuntions.getAssociationDiscountFactor(association_discount, type_constant, coverage_constant);

  let number_of_prior_claims = coverageSupportFuntions.getNumberOfClaims(policy_fv, policy_fgv);
  let number_of_claims_for_discount = number_of_prior_claims.number_of_claims_for_discount;
  let number_of_claims_for_surcharge = number_of_prior_claims.number_of_claims_for_surcharge;

  let claims_free_discount_factor = coverageSupportFuntions.getClaimsFreeDiscountFactor(number_of_claims_for_discount, type_constant, coverage_constant);

  let community_policy_discount = exposure_fgv[exposure_fv.unit_details].community_policy_discount;
  let community_policy_discount_factor = coverageSupportFuntions.getCommunityPolicyDiscountFactor(community_policy_discount, type_constant, coverage_constant);

  let multi_policy_discount = policy_fv.multi_policy_discount;
  let multi_policy_discount_factor = coverageSupportFuntions.getMultiPolicyDiscountFactor(multi_policy_discount, type_constant, coverage_constant);

  let num_of_exposures = ratingHelpers.getNumberOfExposures(exposures);
  let multi_unit_discount_factor = coverageSupportFuntions.getMultiUnitDiscountFactor(num_of_exposures, type_constant, coverage_constant);

  let payment_schedule = data.policy.paymentScheduleName;
  let paid_in_full_discount_factor = coverageSupportFuntions.getPaidInFullDiscountFactor(payment_schedule, type_constant, coverage_constant);

  let paperless_discount = policy_fv.paperless_discount;
  let paperless_discount_factor = coverageSupportFuntions.getPaperlessDiscountFactor(paperless_discount, policy_usage, coverage_constant);


  let claims_surcharge_factor = coverageSupportFuntions.getClaimsSurchargeFactor(number_of_claims_for_surcharge, exposures, exposure, policy_usage, type_constant, coverage_constant);

  let short_term_rental_surcharge_factor = coverageSupportFuntions.getShortTermRentalSurchargeFactor(exposure, exposure_fgv, exposure_fv, type_constant, coverage_constant);

  let AOP_coverage_c_premium_without_discounts = AOP_coverage_c_base_rate * age_of_insured_factor * distribution_channel_factor *
    form_factor * insurance_score_factor * home_type_factor * occupancy_factor * roof_condition_factor *
    settlement_option_factor * occasional_vacation_rental_factor * coverage_limit_factor * territory_factor *
    calendar_year_modifier_factor * roof_material_factor * community_status_factor * prior_lapse_surcharge_factor *
    short_term_rental_surcharge_factor * claims_surcharge_factor * aop_deductible_factor * roof_age_factor * age_of_home_factor;

  let aop_cov_c_premium_with_association_discount = AOP_coverage_c_premium_without_discounts * association_discount_factor;
  let aop_association_discount_amount = AOP_coverage_c_premium_without_discounts - aop_cov_c_premium_with_association_discount;

  let aop_cov_c_premium_with_multi_policy_discount = aop_cov_c_premium_with_association_discount * multi_policy_discount_factor;
  let aop_multi_policy_discount_amount = aop_cov_c_premium_with_association_discount - aop_cov_c_premium_with_multi_policy_discount;

  let aop_cov_c_premium_with_multi_unit_discount = aop_cov_c_premium_with_multi_policy_discount * multi_unit_discount_factor;
  let aop_multi_unit_discount_amount = aop_cov_c_premium_with_multi_policy_discount - aop_cov_c_premium_with_multi_unit_discount;

  let aop_cov_c_premium_with_claims_free_discount = aop_cov_c_premium_with_multi_unit_discount * claims_free_discount_factor;
  let aop_claims_free_discount_amount = aop_cov_c_premium_with_multi_unit_discount - aop_cov_c_premium_with_claims_free_discount;

  let aop_cov_c_premium_with_paid_in_full_discount = aop_cov_c_premium_with_claims_free_discount * paid_in_full_discount_factor;
  let aop_paid_in_full_discount_amount = aop_cov_c_premium_with_claims_free_discount - aop_cov_c_premium_with_paid_in_full_discount;

  let aop_cov_c_premium_with_community_policy_dicount = aop_cov_c_premium_with_paid_in_full_discount * community_policy_discount_factor;
  let aop_community_policy_discount_amount = aop_cov_c_premium_with_paid_in_full_discount - aop_cov_c_premium_with_community_policy_dicount;

  let aop_cov_c_premium_with_paperless_discount = aop_cov_c_premium_with_community_policy_dicount + paperless_discount_factor;
  let aop_paperless_discount_amount = aop_cov_c_premium_with_community_policy_dicount - aop_cov_c_premium_with_paperless_discount;

  let AOP_coverage_c_premium = Math.round(AOP_coverage_c_premium_without_discounts - aop_paperless_discount_amount -
    aop_association_discount_amount -
    aop_multi_policy_discount_amount -
    aop_multi_unit_discount_amount -
    aop_claims_free_discount_amount -
    aop_paid_in_full_discount_amount -
    aop_community_policy_discount_amount)

  return {
    AOP_coverage_c_premium,
    aop_paperless_discount_amount,
    aop_association_discount_amount,
    aop_multi_policy_discount_amount,
    aop_multi_unit_discount_amount,
    aop_claims_free_discount_amount,
    aop_paid_in_full_discount_amount,
    aop_community_policy_discount_amount
  }
}
    

function getWindstormOrHailCoverageCPremium(peril, data)
{
  let type_constant = ratingConstants.valueConstants.windstorm_or_hail;
  let coverage_constant = ratingConstants.coverageConstants.coverage_c;
  let exposures = data.policy.exposures;
  let exposureLocator = peril.exposureLocator;
  let perils = exposures.flatMap((ex) => ex.perils);
  let exposure = exposures.find((e) => e.locator == exposureLocator);
  let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
  let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;

  let home_type;
  let roof_material;
  let roof_condition;
  let age_of_roof;
  let age_of_home;
  let age_of_home_factor = ratingConstants.numberConstants.one;
  let roof_age_factor = ratingConstants.numberConstants.one;
  let roof_material_factor = ratingConstants.numberConstants.one;

  if (exposure.name != ratingConstants.exposureNameConstants.tenant_occupied)
  {
    home_type = exposure_fgv[exposure_fv.unit_construction].home_type;
    roof_material = exposure_fgv[exposure_fv.unit_construction].roof_material;
    roof_condition = exposure_fgv[exposure_fv.unit_construction].roof_condition;
    age_of_roof = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].roof_year_yyyy);
    age_of_home = ratingHelpers.getRoofOrHomeAge(exposure_fgv[exposure_fv.unit_construction].model_year)
  }

  let policy_usage = exposure_fgv[exposure_fv.usage].policy_usage;
  let territory_code = exposure_fgv[exposure_fv.territory].territory_code_windhail;
  let territory_factor = coverageSupportFuntions.getTerritoryFactor(territory_code, type_constant, coverage_constant);

  let policy_term = ratingHelpers.getPolicyTerm(data);
  let prior_lapse_surcharge_factor = coverageSupportFuntions.getPriorLapseSurchageFactor(exposure_fgv, exposure_fv, policy_fgv, policy_fv, policy_term, type_constant, coverage_constant);

  let baseRateTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.coverage_base_rates, coverage_constant);
  let wind_hail_coverage_c_base_rate = parseFloat(baseRateTable[ratingConstants.valueConstants.windstorm_or_hail]);

  if (policy_usage != ratingConstants.usageConstants.tenant)
  {
    if (policy_usage == ratingConstants.usageConstants.tenant)
    {
      let age_of_home_factor_key = (ratingConstants.usageConstants.tenant + ratingConstants.tableToObjectConstants.pipe + ratingConstants.numberConstants.zero + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
      let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.age_of_home_factor, age_of_home_factor_key);
      age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
    }
    else
    {
      let age_of_home_factor_key = (ratingConstants.usageConstants.non_tenant + ratingConstants.tableToObjectConstants.pipe + age_of_home + ratingConstants.tableToObjectConstants.pipe + coverage_constant);
      let ageOfHomeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.age_of_home_factor, age_of_home_factor_key);
      age_of_home_factor = parseFloat(ageOfHomeFactorTable[type_constant]);
    }

    if (age_of_roof != null && roof_condition != null && roof_material != undefined)
    {
      let roof_age_factor_key = roof_condition + ratingConstants.tableToObjectConstants.pipe + age_of_roof + ratingConstants.tableToObjectConstants.pipe + ratingHelpers.getAgeOfHomeForFactor(exposure_fgv[exposure_fv.unit_construction].model_year) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      let roofAgeFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.roof_age_factor, roof_age_factor_key);
      roof_age_factor = parseFloat(roofAgeFactorTable[type_constant]);
    }

    if (roof_material != null && roof_material != undefined)
    {
      let roof_material_factor_key = ratingHelpers.getRoofMaterial(roof_material) + ratingConstants.tableToObjectConstants.pipe + coverage_constant;
      let roofMaterialFactorTable = ratingHelpers.getTableObject(ratingConstants.tableNameConstants.roof_material_factor, roof_material_factor_key);
      roof_material_factor = parseFloat(roofMaterialFactorTable[type_constant]);
    }
  }
  let date_of_birth = policy_fgv[policy_fv.policy_basic_info].date_of_birth;
  let age_of_insured_factor = coverageSupportFuntions.getAgeOfInsuredFactor(date_of_birth, type_constant, coverage_constant);

  let policy_start_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;
  let calendar_year_modifier_factor = coverageSupportFuntions.getCalendarYearModifier(policy_start_timestamp, type_constant, coverage_constant);

  let coverage_limit = peril_fv.unscheduled_personal_property_limit;
  let aop_wind_hail_occasional_factors = coverageSupportFuntions.getAOPorWindDeductibleFactorandOccasionalRenatalFactor(policy_usage, data, perils, coverage_limit, type_constant, coverage_constant);
  let occasional_vacation_rental_factor = aop_wind_hail_occasional_factors.occasional_vacation_rental_factor;
  let wind_hail_deductible_factor = aop_wind_hail_occasional_factors.deductible_factor

  let application_intiation = policy_fv.application_intiation;
  let distribution_channel_factor = coverageSupportFuntions.getDistributionChanelFactor(application_intiation, type_constant, coverage_constant);

  let form = exposure_fgv[exposure_fv.unit_details].form;
  let form_factor = coverageSupportFuntions.getFormFactor(form, type_constant, coverage_constant);

  let insurance_score = policy_fv.insurance_score;
  let insurance_score_factor = coverageSupportFuntions.getInsuranceScoreFactor(insurance_score, type_constant, coverage_constant);

  let home_type_factor = coverageSupportFuntions.getHomeTypeFactor(policy_usage, home_type, type_constant, coverage_constant);

  let occupancy_factor = coverageSupportFuntions.getOccupancyFactor(policy_usage, type_constant, coverage_constant);

  let unit_location = exposure_fgv[exposure_fv.unit_details].unit_location;
  let community_status_factor = coverageSupportFuntions.getCommunityStatusFactor(unit_location, type_constant, coverage_constant);

  let roof_condition_factor = coverageSupportFuntions.getRoofConditionFactor(roof_condition, type_constant, coverage_constant);

  let settlement_option = peril_fv.cov_c_settlement_option;
  let settlement_option_factor = coverageSupportFuntions.getSettlementOptionFactor(settlement_option, type_constant, coverage_constant);

  let coverage_limit_factor = coverageSupportFuntions.getCoverageLimitFactor(policy_usage, coverage_limit, type_constant, coverage_constant);


  let association_discount = policy_fv.association_discount;
  let association_discount_factor = coverageSupportFuntions.getAssociationDiscountFactor(association_discount, type_constant, coverage_constant);

  let number_of_prior_claims = coverageSupportFuntions.getNumberOfClaims(policy_fv, policy_fgv);
  let number_of_claims_for_discount = number_of_prior_claims.number_of_claims_for_discount;
  let number_of_claims_for_surcharge = number_of_prior_claims.number_of_claims_for_surcharge;

  let claims_free_discount_factor = coverageSupportFuntions.getClaimsFreeDiscountFactor(number_of_claims_for_discount, type_constant, coverage_constant);

  let community_policy_discount = exposure_fgv[exposure_fv.unit_details].community_policy_discount;
  let community_policy_discount_factor = coverageSupportFuntions.getCommunityPolicyDiscountFactor(community_policy_discount, type_constant, coverage_constant);

  let multi_policy_discount = policy_fv.multi_policy_discount;
  let multi_policy_discount_factor = coverageSupportFuntions.getMultiPolicyDiscountFactor(multi_policy_discount, type_constant, coverage_constant);

  let num_of_exposures = ratingHelpers.getNumberOfExposures(exposures);
  let multi_unit_discount_factor = coverageSupportFuntions.getMultiUnitDiscountFactor(num_of_exposures, type_constant, coverage_constant);

  let payment_schedule = data.policy.paymentScheduleName;
  let paid_in_full_discount_factor = coverageSupportFuntions.getPaidInFullDiscountFactor(payment_schedule, type_constant, coverage_constant);


  let claims_surcharge_factor = coverageSupportFuntions.getClaimsSurchargeFactor(number_of_claims_for_surcharge, exposures, exposure, policy_usage, type_constant, coverage_constant);

  let short_term_rental_surcharge_factor = coverageSupportFuntions.getShortTermRentalSurchargeFactor(exposure, exposure_fgv, exposure_fv, type_constant, coverage_constant);

  let wind_hail_coverage_c_premium_without_discounts = (wind_hail_coverage_c_base_rate * age_of_insured_factor *
    distribution_channel_factor * form_factor * insurance_score_factor * home_type_factor * occupancy_factor * roof_condition_factor *
    settlement_option_factor * occasional_vacation_rental_factor * coverage_limit_factor * territory_factor * calendar_year_modifier_factor *
    roof_material_factor * community_status_factor * prior_lapse_surcharge_factor * short_term_rental_surcharge_factor * claims_surcharge_factor *
    wind_hail_deductible_factor * roof_age_factor * age_of_home_factor);

  let wind_hail_cov_c_premium_with_association_discount = wind_hail_coverage_c_premium_without_discounts * association_discount_factor;
  let wind_hail_association_discount_amount = wind_hail_coverage_c_premium_without_discounts - wind_hail_cov_c_premium_with_association_discount;
  
  let wind_hail_cov_c_premium_with_multi_policy_discount = wind_hail_cov_c_premium_with_association_discount * multi_policy_discount_factor;
  let wind_hail_multi_policy_discount_amount = wind_hail_cov_c_premium_with_association_discount - wind_hail_cov_c_premium_with_multi_policy_discount;
  
  let wind_hail_cov_c_premium_with_multi_unit_discount = wind_hail_cov_c_premium_with_multi_policy_discount * multi_unit_discount_factor;
  let wind_hail_multi_unit_discount_amount = wind_hail_cov_c_premium_with_multi_policy_discount - wind_hail_cov_c_premium_with_multi_unit_discount;
  
  let wind_hail_cov_c_premium_with_claims_free_discount = wind_hail_cov_c_premium_with_multi_unit_discount * claims_free_discount_factor;
  let wind_hail_claims_free_discount_amount = wind_hail_cov_c_premium_with_multi_unit_discount - wind_hail_cov_c_premium_with_claims_free_discount;

  let wind_hail_cov_c_premium_with_paid_in_full_discount = wind_hail_cov_c_premium_with_claims_free_discount * paid_in_full_discount_factor;
 let wind_hail_paid_in_full_discount_amount = wind_hail_cov_c_premium_with_claims_free_discount - wind_hail_cov_c_premium_with_paid_in_full_discount;

  let wind_hail_cov_c_premium_with_community_policy_dicount = wind_hail_cov_c_premium_with_paid_in_full_discount * community_policy_discount_factor;
  let wind_hail_community_policy_discount_amount = wind_hail_cov_c_premium_with_paid_in_full_discount - wind_hail_cov_c_premium_with_community_policy_dicount;

  let wind_hail_coverage_c_premium = wind_hail_coverage_c_premium_without_discounts - wind_hail_association_discount_amount -
  wind_hail_multi_policy_discount_amount -
  wind_hail_multi_unit_discount_amount -
  wind_hail_claims_free_discount_amount -
  wind_hail_paid_in_full_discount_amount -
  wind_hail_community_policy_discount_amount;
  wind_hail_coverage_c_premium = Math.round(wind_hail_coverage_c_premium);
  
  return {
    wind_hail_coverage_c_premium,
    wind_hail_association_discount_amount,
    wind_hail_multi_policy_discount_amount,
    wind_hail_multi_unit_discount_amount,
    wind_hail_claims_free_discount_amount,
    wind_hail_paid_in_full_discount_amount,
    wind_hail_community_policy_discount_amount
  }
}
exports.getPremiumForCoverageC = getPremiumForCoverageC;
exports.getAOPCoverageCPremium = getAOPCoverageCPremium;
exports.getWindstormOrHailCoverageCPremium = getWindstormOrHailCoverageCPremium;