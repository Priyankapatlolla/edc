"use strict";

let ratingConstants = require('./ratingConstants.js');
let policyLevelCoverages = require("./exposures/policyLevelCoverages.js");
let otherCoverages = require("./exposures/unitCoverages.js");
let coverageA = require('./exposures/perils/coverageA.js');
let coverageB = require('./exposures/perils/coverageB.js');
let coverageC = require('./exposures/perils/coverageC.js');
let earthquake = require('./exposures/perils/earthquake.js');
let waterDamage = require('./exposures/perils/waterDamage.js');
let flatPremiumComputations = require("./exposures/perils/flatPremiumComputations.js");
let lib = require("../libraries/lib.js");

let sum_of_premium = ratingConstants.numberConstants.zero;

function getPerilRates(data)
{
  lib.polyfill();

  let pricedPerilCharacteristics = {};
  let exposures = data.policy.exposures;
  let perils = exposures.flatMap((ex) => ex.perils);

  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let pcl = policy_exposure_peril.perilCharacteristicsLocator;
    let peril = perils.find((p) =>
      p.characteristics.some((ch) =>
        ch.locator == policy_exposure_peril.perilCharacteristicsLocator));

    if (peril.name == ratingConstants.perilNameConstants.coverage_a)
    {
      let coverage_a = coverageA.getPremiumForCoverageA(peril, data);
      let coverage_a_premium =  coverage_a.coverage_a_premium;
      setPerilPremium(coverage_a_premium);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(coverage_a_premium) ? coverage_a_premium : 0,
        commissions: [
        {
          yearlyAmount: !isNaN(coverage_a.coverage_a_association_discount_amount) ? coverage_a.coverage_a_association_discount_amount : 0,
          recipient: ratingConstants.discountConstants.association_discount
        },
        {
          yearlyAmount: !isNaN(coverage_a.coverage_a_multi_policy_discount_amount) ? coverage_a.coverage_a_multi_policy_discount_amount : 0,
          recipient: ratingConstants.discountConstants.multi_policy_discount
        },
        {
          yearlyAmount: !isNaN(coverage_a.coverage_a_multi_unit_discount_amount) ? coverage_a.coverage_a_multi_unit_discount_amount : 0,
          recipient: ratingConstants.discountConstants.multi_unit_discount
        },
        {
          yearlyAmount: !isNaN(coverage_a.coverage_a_paperless_discount_amount) ? coverage_a.coverage_a_paperless_discount_amount : 0,
          recipient: ratingConstants.discountConstants.paperless_discount
        },
        {
          yearlyAmount: !isNaN(coverage_a.coverage_a_claims_free_discount_amount) ? coverage_a.coverage_a_claims_free_discount_amount : 0,
          recipient: ratingConstants.discountConstants.claims_free_discount
        },
        {
          yearlyAmount: !isNaN(coverage_a.coverage_a_paid_in_full_discount_amount) ? coverage_a.coverage_a_paid_in_full_discount_amount : 0,
          recipient: ratingConstants.discountConstants.paid_in_full_discount
        },
        {
          yearlyAmount: !isNaN(coverage_a.coverage_a_community_discount_amount) ? coverage_a.coverage_a_community_discount_amount : 0,
          recipient: ratingConstants.discountConstants.community_policy_discount
        }]
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.coverage_b)
    {
      let coverage_b = coverageB.getPremiumForCoverageB(peril, data);
      let coverage_b_premium = coverage_b.coverage_b_premium;
      setPerilPremium(coverage_b_premium);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(coverage_b_premium) ? coverage_b_premium : 0,
        commissions: [
        {
          yearlyAmount: !isNaN(coverage_b.coverage_b_association_discount_amount) ? coverage_b.coverage_b_association_discount_amount : 0,
          recipient: ratingConstants.discountConstants.association_discount
        },
        {
          yearlyAmount: !isNaN(coverage_b.coverage_b_multi_policy_discount_amount) ? coverage_b.coverage_b_multi_policy_discount_amount : 0,
          recipient: ratingConstants.discountConstants.multi_policy_discount
        },
        {
          yearlyAmount: !isNaN(coverage_b.coverage_b_multi_unit_discount_amount) ? coverage_b.coverage_b_multi_unit_discount_amount : 0,
          recipient: ratingConstants.discountConstants.multi_unit_discount
        },
        {
          yearlyAmount: !isNaN(coverage_b.coverage_b_claims_free_discount_amount) ? coverage_b.coverage_b_claims_free_discount_amount : 0,
          recipient: ratingConstants.discountConstants.claims_free_discount
        },
        {
          yearlyAmount: !isNaN(coverage_b.coverage_b_paid_in_full_discount_amount) ? coverage_b.coverage_b_paid_in_full_discount_amount : 0,
          recipient: ratingConstants.discountConstants.paid_in_full_discount
        },
        {
          yearlyAmount: !isNaN(coverage_b.coverage_b_community_discount_amount) ? coverage_b.coverage_b_community_discount_amount : 0,
          recipient: ratingConstants.discountConstants.community_policy_discount
        }]
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.coverage_c)
    {
      let coverage_c = coverageC.getPremiumForCoverageC(peril, data);
      let coverage_c_premium = coverage_c.coverage_c_premium;
      setPerilPremium(coverage_c_premium);
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(coverage_c_premium) ? coverage_c_premium : 0,
        commissions: [
        {
          yearlyAmount: !isNaN(coverage_c.coverage_c_association_discount_amount) ? coverage_c.coverage_c_association_discount_amount : 0,
          recipient: ratingConstants.discountConstants.association_discount
        },
        {
          yearlyAmount: !isNaN(coverage_c.coverage_c_multi_policy_discount_amount) ? coverage_c.coverage_c_multi_policy_discount_amount : 0,
          recipient: ratingConstants.discountConstants.multi_policy_discount
        },
        {
          yearlyAmount: !isNaN(coverage_c.coverage_c_multi_unit_discount_amount) ? coverage_c.coverage_c_multi_unit_discount_amount : 0,
          recipient: ratingConstants.discountConstants.multi_unit_discount
        },
        {
          yearlyAmount: !isNaN(coverage_c.coverage_c_paperless_discount_amount) ? coverage_c.coverage_c_paperless_discount_amount : 0,
          recipient: ratingConstants.discountConstants.paperless_discount
        },
        {
          yearlyAmount: !isNaN(coverage_c.coverage_c_claims_free_discount_amount) ? coverage_c.coverage_c_claims_free_discount_amount : 0,
          recipient: ratingConstants.discountConstants.claims_free_discount
        },
        {
          yearlyAmount: !isNaN(coverage_c.coverage_c_paid_in_full_discount_amount) ? coverage_c.coverage_c_paid_in_full_discount_amount : 0,
          recipient: ratingConstants.discountConstants.paid_in_full_discount
        },
        {
          yearlyAmount: !isNaN(coverage_c.coverage_c_community_discount_amount) ? coverage_c.coverage_c_community_discount_amount : 0,
          recipient: ratingConstants.discountConstants.community_policy_discount
        }]
      }
    }
    else if (peril.name == ratingConstants.perilNameConstants.coverage_d)
    {
      let premium_for_coverage_d = otherCoverages.getPremiumForCoverageD(peril, data);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_coverage_d);
    }
    else if (peril.name == ratingConstants.perilNameConstants.coverage_e_premises_liability)
    {
      let premium_for_coverage_e_premises_liability = otherCoverages.getPremiumForCoverageEPremisesLiability(peril, data);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_coverage_e_premises_liability);
    }
    else if (peril.name == ratingConstants.perilNameConstants.coverage_e_personal_liability)
    {
      let premium_for_coverage_e_personal_liability = otherCoverages.getPremiumForCoverageEPersonalLiability(peril, data);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_coverage_e_personal_liability);
    }
    else if (peril.name == ratingConstants.perilNameConstants.coverage_f)
    {
      let premium_for_coverage_f = otherCoverages.getPremiumForCoverageF(peril, data);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_coverage_f);
    }
    else if (peril.name == ratingConstants.perilNameConstants.earthquake)
    {
      let premium_for_earthquake = earthquake.getPremiumForEarthquake(peril, data);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_earthquake);
    }
    else if (peril.name == ratingConstants.perilNameConstants.identity_fraud_coverage)
    {
      let premium_for_identity_fraud_coverage = policyLevelCoverages.getPremiumForIdentityFraudExpense();
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_identity_fraud_coverage);
    }
    else if (peril.name == ratingConstants.perilNameConstants.trip_collision)
    {
      let premium_for_trip_collision = flatPremiumComputations.getPremiumForTripCollision(peril, exposures);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_trip_collision);
    }
    else if (peril.name == ratingConstants.perilNameConstants.scheduled_personal_property)
    {
      let premium_for_scheduled_personal_property = policyLevelCoverages.getPremiumForScheduledPersonalProperty(peril);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_scheduled_personal_property);
    }
    else if (peril.name == ratingConstants.perilNameConstants.golf_cart)
    {
      let premium_for_golf_cart = flatPremiumComputations.getPremiumForGolfCart(peril);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_golf_cart);
    }
    else if (peril.name == ratingConstants.perilNameConstants.water_damage_coverage)
    {
      let premium_for_water_damage_coverage = waterDamage.getPremiumForWaterDamageCoverage(peril, data);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_water_damage_coverage);
    }
    else if (peril.name == ratingConstants.perilNameConstants.hobby_farming)
    {
      let premium_hobby_farming = flatPremiumComputations.getPremiumForHobbyFarming();
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_hobby_farming);
    }
    else if (peril.name == ratingConstants.perilNameConstants.animal_liability)
    {
      let premium_for_animal_liability = flatPremiumComputations.getPremiumForAnimalLiability(peril);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_animal_liability);
    }
    else if (peril.name == ratingConstants.perilNameConstants.debris_removal)
    {
      let premium_for_debris_removal = flatPremiumComputations.getPremiumForDebrisRemoval(peril);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_debris_removal);
    }
    else if (peril.name == ratingConstants.perilNameConstants.enhanced_coverage)
    {
      let premium_for_enhanced_coverage = flatPremiumComputations.getPremiumForEnhancedCoverage();
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_enhanced_coverage);
    }
    else if (peril.name == ratingConstants.perilNameConstants.landlord_personal_injury)
    {
      let premium_for_landlord_personal_injury = flatPremiumComputations.getPremiumForLandlordPersonalInjury(peril, data);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_landlord_personal_injury);
    }
    else if (peril.name == ratingConstants.perilNameConstants.loss_assessment)
    {
      let premium_for_loss_assessment = flatPremiumComputations.getPremiumForLossAssessment(peril);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_loss_assessment);
    }
    else if (peril.name == ratingConstants.perilNameConstants.water_backup_and_sump_overflow)
    {
      let premium_for_water_backup_and_sump_overflow = flatPremiumComputations.getPremiumForWaterBackupandSumpOverflow(peril);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_water_backup_and_sump_overflow);
    }
    else if (peril.name == ratingConstants.perilNameConstants.roof_exclusion)
    {
      let premium_for_roof_exclusion = flatPremiumComputations.getPremiumForRoofExclusion();
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_roof_exclusion);
    }
    else if (peril.name == ratingConstants.perilNameConstants.specific_structure_exclusion)
    {
      let premium_for_specific_structure_exclusion = flatPremiumComputations.getPremiumForSpecificStructureExclusion();
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_specific_structure_exclusion);
    }
    else if (peril.name == ratingConstants.perilNameConstants.theft_limitation)
    {
      let premium_for_theft_limitation = otherCoverages.getPremiumForTheftLimitation(perils, data);
      pricedPerilCharacteristics[pcl] = setPerilPremium(premium_for_theft_limitation);
    }
    else
    {
      pricedPerilCharacteristics[pcl] = {
        premium: 0,
      };
    }
  }

  for (let policy_exposure_peril of data.policyExposurePerils)
  {
    let pcl = policy_exposure_peril.perilCharacteristicsLocator;
    let peril = perils.find((p) =>
      p.characteristics.some((ch) =>
        ch.locator == policy_exposure_peril.perilCharacteristicsLocator));
    if (peril.name == ratingConstants.perilNameConstants.policy_min_coverage)
    {
      let policy_min_coverage = getPolicyMinimumPremium(sum_of_premium);
      sum_of_premium = ratingConstants.numberConstants.zero;
      pricedPerilCharacteristics[pcl] = {
        premium: !isNaN(policy_min_coverage) ? policy_min_coverage : 0
      };
    }
  }
  return {
    pricedPerilCharacteristics
  };
}

function setPerilPremium(peril_premium)
{
  if (!isNaN(peril_premium))
  {
    sum_of_premium = sum_of_premium + peril_premium;
  }
  return {
    premium: !isNaN(peril_premium) ? peril_premium : 0
  };
}

function getPolicyMinimumPremium(sum_of_premium)
{
  let policy_min_premium = parseFloat(socotraApi.tableLookup(ratingConstants.tableNameConstants.policy_minimum_premium,ratingConstants.policyMinPremiumKeys.policy_written));
  if (sum_of_premium < policy_min_premium)
  {
    let minimum_premium = policy_min_premium - sum_of_premium;
    return minimum_premium;
  }
  else
  {
    return ratingConstants.numberConstants.zero;
  }
}

exports.getPerilRates = getPerilRates;