let constantValues = require("./ruleComparisionFactors.js");
let helpers = require("./helpersUW.js");

function getPerilUWDesicion(data, policy_fv, policy_fgv) {
  getPerilDetailsDecision(data);
  getRoofExclusion(data);
  getGolfCart(data);
  getDeductibles(data);
  getBuildersRisk(data);
  getInflationGuard(data);
  getScheduledPersonalProperty(data, policy_fv, policy_fgv);
  getStateSpecificRules(data);
}

function getPerilDetailsDecision(data) {
  let allExposures = data.policy.exposures;
  let uw_manufactured_home_limit;
  let cov_c_settlement_option;
  let cov_a_settlement_option;
  let peril_fv;
  let peril_fgv;
  let uw_unit_details;
  let uw_rcv;
  let uw_acv;

  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;

    for (let peril of exposure.perils) {
      peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
      if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages &&
        exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
        uw_unit_details = exposure_fv.unit_details;
        uw_rcv = exposure_fgv[uw_unit_details].rcv;
        uw_acv = exposure_fgv[uw_unit_details].acv;
        if (peril.name == constantValues.perilNameConstants.dwelling) {
          uw_manufactured_home_limit = helpers.getManufacturedLimit(exposure);
          cov_a_settlement_option = peril_fv.cov_a_settlement_option;
          if ((uw_manufactured_home_limit > (uw_rcv * constantValues.numberConstants.uw_ones)) &&
            ((cov_a_settlement_option == constantValues.perilValueConstants.extended_replacement_cost) ||
              (cov_a_settlement_option == constantValues.perilValueConstants.replacement_cost))) {
            helpers.setUWDecision(constantValues.decisions.uw_none,
              constantValues.messageConstants.rce_high);
          }
          if ((uw_manufactured_home_limit < (uw_rcv * constantValues.numberConstants.uw_one)) &&
            (cov_a_settlement_option == constantValues.perilValueConstants.extended_replacement_cost)) {
            helpers.setUWDecision(constantValues.decisions.uw_none,
              constantValues.messageConstants.rce_acv);
          }
          if ((uw_manufactured_home_limit < (uw_rcv * constantValues.numberConstants.uw_nine)) &&
            (cov_a_settlement_option == constantValues.perilValueConstants.replacement_cost)) {
            helpers.setUWDecision(constantValues.decisions.uw_none,
              constantValues.messageConstants.rce_acv);
          }
          if ((uw_manufactured_home_limit < (uw_acv * constantValues.numberConstants.uw_seven)) &&
            (cov_a_settlement_option == constantValues.perilValueConstants.actual_cash_value)) {
            helpers.setUWDecision(constantValues.decisions.uw_none, constantValues.messageConstants.rce_acv);
          }
          if ((cov_a_settlement_option == constantValues.perilValueConstants.actual_cash_value) &&
            (uw_manufactured_home_limit > uw_rcv)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.rce + uw_rcv + constantValues.messageConstants.full_stop);
          }
        }

      }
      if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
        if (peril.name == constantValues.perilNameConstants.personal_property) {
          cov_c_settlement_option = peril_fv.cov_c_settlement_option;
          if ((helpers.getCountOfChargeableClaims(data) >= constantValues.numberConstants.two) &&
            (cov_c_settlement_option == constantValues.perilValueConstants.replacement_cost)) {
            helpers.setUWDecision(constantValues.decisions.uw_none,
              constantValues.messageConstants.replacement_cost);
          }
        }
      }
    }
  }

}

function getInflationGuard(data) {
  let allExposures = data.policy.exposures;
  let cov_a_settlement_option;
  for (let exposure of allExposures) {
    for (let peril of exposure.perils) {
      let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages &&
        exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
        if (peril.name == constantValues.perilNameConstants.dwelling) {
          cov_a_settlement_option = peril_fv.cov_a_settlement_option;
        }
        if (peril.name == constantValues.perilNameConstants.inflation_guard) {
          if ((cov_a_settlement_option == constantValues.perilValueConstants.actual_cash_value)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.inflation_guard);
          }
        }
      }
    }
  }
}

function getDeductibles(data) {
  let allExposures = data.policy.exposures;
  let all_other_perils_deductible;
  for (let exposure of allExposures) {
    for (let peril of exposure.perils) {
      peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
      if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
        if (peril.name == constantValues.perilNameConstants.deductibles) {
          all_other_perils_deductible = helpers.getAllOtherPerilsLimit(exposure);
          if (all_other_perils_deductible < constantValues.numberConstants.five_hundred) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.all_other_perils);
          }
        }
      }
    }
  }
}

function getGolfCart(data) {
  let allExposures = data.policy.exposures;
  let no_of_golf_carts;
  let perilNamesArray = [];
  for (let exposure of allExposures) {
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
      peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
      if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages &&
        exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
        if (peril.name == constantValues.perilNameConstants.golf_cart) {
          no_of_golf_carts = peril_fv.no_of_golf_carts;
        }
        if (peril.name == constantValues.perilNameConstants.personal_liability ||
          peril.name == constantValues.perilNameConstants.premises_liability) {
          uw_personal_liability_limit = helpers.getPersonalLiabilityLimit(exposure);
          uw_permises_liability_limit = helpers.getPremisesLiabilityLimit(exposure);

          if ((no_of_golf_carts >= 1 || no_of_golf_carts <= 5) &&
            (!((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
              (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)))) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.golf_cart_damage);
          }
        }
      }
    }
  }
}

function getRoofExclusion(data) {
  let allExposures = data.policy.exposures;
  let perilNamesArray = [];
  for (let exposure of allExposures) {
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
    }
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages &&
      exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.roof_exclusion) > -1)) {
        helpers.setUWDecision(constantValues.decisions.uw_none,
          constantValues.messageConstants.roof_exclusion);
      }
    }
  }
}

function getBuildersRisk(data) {
  let allExposures = data.policy.exposures;
  let perilNamesArray = [];
  for (let exposure of allExposures) {
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
    }
    if (exposure.name == constantValues.exposureNameConstants.vacant) {
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.builders_risk) > -1)) {
        helpers.setUWDecision(constantValues.decisions.uw_none, constantValues.messageConstants.builders_risk);
      }
    }
  }
}

function getScheduledPersonalProperty(data, policy_fv, policy_fgv) {
  let spp_type;
  let theft_burglary_count = constantValues.numberConstants.zero;
  let uw_prior_claims = policy_fv.prior_claims;
  if(uw_prior_claims != undefined)
  {
    for (let prior_claims of uw_prior_claims) {
      let uw_category = policy_fgv[prior_claims].category;
      if (uw_category == constantValues.policyValueConstants.theft_burglary) {
        theft_burglary_count++;
      }
    }
  }
  let perilNamesArray = [];
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
      let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      let peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
      if (exposure.name == constantValues.exposureNameConstants.policy_level_coverages) {
        if (peril.name == constantValues.perilNameConstants.schedule_personal_property) {
          let scheduled_personals = peril_fv.scheduled_personals;
          for (let each_schedule_personal of scheduled_personals) {
            spp_type = peril_fgv[each_schedule_personal].spp_type;
            let spp_value = peril_fgv[each_schedule_personal].spp_value;
            if ((helpers.getSumOfScheduleProperty(data) > constantValues.numberConstants.five_thousand) && (spp_type == constantValues.perilValueConstants.stamps_books || spp_type == constantValues.perilValueConstants.rare_and_current_coins)) {
              helpers.setUWDecision(constantValues.decisions.uw_none,
                constantValues.messageConstants.scheduled_personal_property + spp_type + constantValues.messageConstants.spp_type);
            }
            if (helpers.getSumOfScheduleProperty(data) > constantValues.numberConstants.five_thousand && spp_type == constantValues.perilValueConstants.guns_and_amminition) {
              helpers.setUWDecision(constantValues.decisions.uw_none,
                constantValues.messageConstants.scheduled_personal_property + spp_type + constantValues.messageConstants.spp_type);
            }
            if (spp_value > constantValues.numberConstants.twenty_five_hundred) {
              helpers.setUWDecision(constantValues.decisions.uw_none,
                constantValues.messageConstants.scheduled_personal_property + spp_type + constantValues.messageConstants.spp_type);
            }

          }
        }
      }
    }
  }
  if (helpers.getSumOfScheduleProperty(data) > constantValues.numberConstants.ten_thousand) {
    helpers.setUWDecision(constantValues.decisions.uw_none,
      constantValues.messageConstants.total_schedule_personal);

  }
  if ((perilNamesArray.indexOf(constantValues.perilNameConstants.schedule_personal_property) > -1) && (theft_burglary_count > constantValues.numberConstants.zero)) {
    helpers.setUWDecision(constantValues.decisions.uw_none,
      constantValues.messageConstants.category + spp_type + constantValues.messageConstants.spp_type);
  }
}

function getStateSpecificRules(data) {
  let allExposures = data.policy.exposures;
  let other_structures_limit;
  let unscheduled_personal_property_limit;
  let manufactured_home_limit;
  let uw_home_type;
  let uw_unit_construction_group;
  let uw_state;
  let uw_unit_address_group;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;

    for (let peril of exposure.perils) {
      if ((exposure.name != constantValues.exposureNameConstants.policy_level_coverages) && (exposure.name != constantValues.exposureNameConstants.tenant_occupied)) {
        uw_unit_address_group = exposure_fv.unit_address;
        uw_state = exposure_fgv[uw_unit_address_group].state;
        uw_unit_construction_group = exposure_fv.unit_construction;
        uw_home_type = exposure_fgv[uw_unit_construction_group].home_type;
        if (uw_state == constantValues.stateConstants.michigan) {
          if (peril.name == constantValues.perilNameConstants.dwelling) {
            manufactured_home_limit = helpers.getManufacturedLimit(exposure);
            if (manufactured_home_limit < constantValues.numberConstants.five_thousand) {
              helpers.setUWDecision(constantValues.decisions.uw_reject,
                constantValues.messageConstants.home_coverage);
            }
            if ((uw_home_type == constantValues.policyValueConstants.modular) && (manufactured_home_limit > constantValues.numberConstants.five_lakh)) {
              helpers.setUWDecision(constantValues.decisions.uw_none,
                constantValues.messageConstants.modular);
            }
            if ((uw_home_type != constantValues.policyValueConstants.modular) && (manufactured_home_limit > constantValues.numberConstants.three_lakh)) {
              helpers.setUWDecision(constantValues.decisions.uw_none,
                constantValues.messageConstants.modular);
            }
          }
          if (peril.name == constantValues.perilNameConstants.other_structures) {
            other_structures_limit = helpers.getOtherStructuresLimit(exposure);
            if (other_structures_limit < constantValues.numberConstants.zero) {
              helpers.setUWDecision(constantValues.decisions.uw_reject,
                constantValues.messageConstants.coverage_b);
            }
            if (other_structures_limit > manufactured_home_limit) {
              helpers.setUWDecision(constantValues.decisions.uw_none,
                constantValues.messageConstants.MI_other_none);
            }
          }
        }
      }
      if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
        uw_unit_address_group = exposure_fv.unit_address;
        uw_state = exposure_fgv[uw_unit_address_group].state;
        if (uw_state == constantValues.stateConstants.michigan) {
          if (peril.name == constantValues.perilNameConstants.personal_property) {
            unscheduled_personal_property_limit = helpers.getUnscheduledPropertyLimit(exposure);
            if (unscheduled_personal_property_limit < constantValues.numberConstants.zero) {
              helpers.setUWDecision(constantValues.decisions.uw_reject,
                constantValues.messageConstants.coverage_c);
            }
            if(exposure.name != constantValues.exposureNameConstants.policy_level_coverages && exposure.name != constantValues.exposureNameConstants.tenant_occupied)
            {
              if (unscheduled_personal_property_limit > Math.max(manufactured_home_limit, constantValues.numberConstants.twenty_thousand)) {
                helpers.setUWDecision(constantValues.decisions.uw_none,
                  constantValues.messageConstants.unscheduled_personal_property);
              }
            }
            if (exposure.name == constantValues.exposureNameConstants.tenant_occupied) {
              if (unscheduled_personal_property_limit > Math.max(constantValues.numberConstants.zero, constantValues.numberConstants.twenty_thousand)) {
                helpers.setUWDecision(constantValues.decisions.uw_none,
                  constantValues.messageConstants.unscheduled_personal_property);
              }
            }
          }
        }
      }
    }
  }
}




exports.getPerilUWDesicion = getPerilUWDesicion;