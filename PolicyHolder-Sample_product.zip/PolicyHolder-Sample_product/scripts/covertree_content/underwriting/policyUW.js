let constantValues = require("./ruleComparisionFactors.js");
let helpers = require("./helpersUW.js");
let moment = require("../libraries/moment-with-locales.js")

function getPolicyUWDecision(data) {
  let allExposures = data.policy.exposures;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let policy_start_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyStartTimestamp;
  let policy_end_timestamp = data.policy.characteristics[data.policy.characteristics.length - 1].policyEndTimestamp;
  getPolicyTerm(policy_start_timestamp, policy_end_timestamp);
  getPolicyBasicInfo(policy_fv, policy_fgv);
  getAdditionalInsured(policy_fv, policy_fgv);
  getPriorPolicy(data);
  getPriorClaimsDetails(data);
  getPolicyLevelUnderwriting(allExposures, policy_fv, policy_fgv);
}

function getPolicyTerm(policy_start_timestamp, policy_end_timestamp) {
  let uw_today = new Date();
  let start_date = new Date(+policy_start_timestamp);
  let policy_start_date = start_date.getDate();
  let today_date = uw_today.getDate();
  let thirty_days_from_today = helpers.addDays(uw_today, constantValues.numberConstants.thirty);
  let term = helpers.getPolicyTerm(policy_start_timestamp, policy_end_timestamp);
  if (policy_start_date < today_date) {
    helpers.setUWDecision(constantValues.decisions.uw_none,
      constantValues.messageConstants.Backdated_transactions);
  }
  if (term < constantValues.numberConstants.twelve) {
    helpers.setUWDecision(constantValues.decisions.uw_reject,
      constantValues.messageConstants.annual_term);
  }
  if (start_date > thirty_days_from_today) {
    helpers.setUWDecision(constantValues.decisions.uw_none,
      constantValues.messageConstants.rate_for_thirty_days);
  }

}

function getPolicyBasicInfo(policy_fv, policy_fgv) {
  let uw_policy_basic_info = policy_fv.policy_basic_info;
  let uw_date_of_birth = policy_fgv[uw_policy_basic_info].date_of_birth;
  let uw_today = new Date();
  uw_date_of_birth = new Date(+uw_date_of_birth);
  let age = moment(new Date(uw_today)).diff(new Date(uw_date_of_birth), 'year', true);
  if (age < constantValues.numberConstants.eighteen) {
    helpers.setUWDecision(constantValues.decisions.uw_reject,
      constantValues.messageConstants.date_of_birth_message);
  }
}

function getAdditionalInsured(policy_fv, policy_fgv) {
  let uw_ad_insured = policy_fv.ad_insured;
  let relationship_to_policyholder;
  if (uw_ad_insured != undefined) {
    for (let each_ad_insured of uw_ad_insured) {
      relationship_to_policyholder = policy_fgv[each_ad_insured].relationship_to_policyholder;
      if (relationship_to_policyholder == constantValues.policyValueConstants.other) {
        helpers.setUWDecision(constantValues.decisions.uw_none,
          constantValues.messageConstants.relationship_to_policyholder);
      }
    }
    let count_of_additional_insured = helpers.getNumberOfAdditionalInsuredGroup(uw_ad_insured);
    if (count_of_additional_insured > constantValues.numberConstants.three) {
      helpers.setUWDecision(constantValues.decisions.uw_none,
        constantValues.messageConstants.additional_insurance);
    }
  }

}

function getPolicyLevelUnderwriting(allExposures, policy_fv, policy_fgv) {
  let policy_level_suppl_uw = policy_fv.policy_level_suppl_uw;
  let uw_conviction = policy_fgv[policy_level_suppl_uw].conviction;
  let uw_cancellation_renew = policy_fgv[policy_level_suppl_uw].cancellation_renew;
  let uw_animal_bite = policy_fgv[policy_level_suppl_uw].animal_bite;
  let perilNamesArray = [];
  if (uw_cancellation_renew == constantValues.binaryConstants.uw_yes) {
    helpers.setUWDecision(constantValues.decisions.uw_none,
      constantValues.messageConstants.cancellation_renew);
  }
  if (uw_conviction == constantValues.binaryConstants.uw_yes) {
    helpers.setUWDecision(constantValues.decisions.uw_reject,
      constantValues.messageConstants.conviction_message);
  }
  for (let exposure of allExposures) {
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
      if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
        if (peril.name == constantValues.perilNameConstants.personal_liability || peril.name == constantValues.perilNameConstants.premises_liability) {
          if ((uw_animal_bite == constantValues.binaryConstants.uw_yes) &&
            (((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
              (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)))) {
            helpers.setUWDecision(constantValues.decisions.uw_none, constantValues.messageConstants.animal_bite);
          }
        }
      }
    }

  }
}

function getPriorPolicy(data) {
  let allExposures = data.policy.exposures;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let prior_insurance_details_group = policy_fv.prior_insurance_details;
  let uw_state;
  let uw_unit_address_group;
  let uw_unit_details;
  let uw_purchase_date;
  let prior_insurance;
  let number_of_day_uninsured;
  for (let each_prior_insurance_group of prior_insurance_details_group) {
    prior_insurance=policy_fgv[each_prior_insurance_group].prior_insurance;;
    prior_policy_expiration_date = policy_fgv[each_prior_insurance_group].prior_policy_expiration_date;
    for (let exposure of allExposures) {
      let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
      let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
      if ((exposure.name != constantValues.exposureNameConstants.policy_level_coverages) && (exposure.name != constantValues.exposureNameConstants.tenant_occupied)) {
        uw_unit_address_group = exposure_fv.unit_address;
        uw_state = exposure_fgv[uw_unit_address_group].state;
        uw_unit_construction_group = exposure_fv.unit_construction;
        uw_home_type = exposure_fgv[uw_unit_construction_group].home_type;
        uw_unit_details = exposure_fv.unit_details;
        uw_purchase_date = exposure_fgv[uw_unit_details].purchase_date;
        if (helpers.getNumberOfDaysUninsured(uw_purchase_date,prior_insurance,prior_policy_expiration_date) == constantValues.numberConstants.thirty_one) {
          helpers.setUWDecision(constantValues.decisions.uw_none,
            constantValues.messageConstants.days_lapsed);
        }

        if ((uw_state != constantValues.stateConstants.california) && (uw_state != constantValues.stateConstants.washington)) {
          if (helpers.getNumberOfDaysUninsured(uw_purchase_date,prior_insurance,prior_policy_expiration_date) == constantValues.numberConstants.ninty_one) {
            helpers.setUWDecision(constantValues.decisions.uw_none,
              constantValues.messageConstants.days_lapsed);
          }
        }
      }

    }
  }
}

function getPriorClaimsDetails(data) {
  let uw_form;
  let category;
  let claim_number;
  let claim_status;
  let fire_smoke_chargeable_claim = constantValues.numberConstants.zero;
  let interior_water_chargeable_claim = constantValues.numberConstants.zero;
  let theft_burglary_chargeable_claim = constantValues.numberConstants.zero;
  let liability_count = constantValues.numberConstants.zero;
  let allExposures = data.policy.exposures;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let prior_claims_group = policy_fv.prior_claims;
  if(prior_claims_group != undefined)
  {
    for (let each_prior_claim of prior_claims_group) {
      category = policy_fgv[each_prior_claim].category;
      claim_status = policy_fgv[each_prior_claim].claim_status;
      claim_number = policy_fgv[each_prior_claim].claim_number
      uw_claim_amount = parseInt(policy_fgv[each_prior_claim].claim_amount);
      let date_of_loss = policy_fgv[each_prior_claim].claim_date;
      let today_date = new Date();
      today_date = moment(today_date).format(constantValues.dateFormat.year_month_date);
      let years_differnce = moment(new Date(today_date)).diff(new Date(date_of_loss), 'year', true);
      let loss_chargeable_matrix = constantValues.tableNameConstants.loss_chargeable_matrix;
      let chargeable = socotraApi.tableLookup(loss_chargeable_matrix, category);
      if (claim_status == constantValues.binaryConstants.uw_open) {
        helpers.setUWDecision(constantValues.decisions.uw_none,
          constantValues.messageConstants.status_open);
      }
      if ((chargeable == constantValues.binaryConstants.uw_yes) && (years_differnce <= constantValues.numberConstants.five) && (uw_claim_amount > constantValues.numberConstants.five_hundred)) {
        if (category == constantValues.policyValueConstants.fire_smoke) {
          fire_smoke_chargeable_claim = fire_smoke_chargeable_claim + uw_claim_amount;
        }
        if (category == constantValues.policyValueConstants.interior_water) {
          interior_water_chargeable_claim = interior_water_chargeable_claim + uw_claim_amount;
        }
        if (category == constantValues.policyValueConstants.theft_burglary) {
          theft_burglary_chargeable_claim = theft_burglary_chargeable_claim + uw_claim_amount;
        }
        if (category == constantValues.policyValueConstants.liability) {
          liability_count++;
        }
        if ((category == constantValues.policyValueConstants.fire_smoke) && (fire_smoke_chargeable_claim > constantValues.numberConstants.five_thousand)) {
          helpers.setUWDecision(constantValues.decisions.uw_none,
            constantValues.messageConstants.fire_smoke + claim_number + constantValues.messageConstants.prior_claims_part_two);
        }
        if ((category == constantValues.policyValueConstants.liability) && (liability_count > constantValues.numberConstants.zero)) {
          helpers.setUWDecision(constantValues.decisions.uw_none,
            constantValues.messageConstants.liability + claim_number + constantValues.messageConstants.prior_claims_part_two);
        }
        for (let exposure of allExposures) {
          let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
          let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
          if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
            let uw_unit_details = exposure_fv.unit_details;
            uw_form = exposure_fgv[uw_unit_details].form;
            if ((category == constantValues.policyValueConstants.interior_water) && (interior_water_chargeable_claim > constantValues.numberConstants.five_thousand) && (uw_form != constantValues.policyValueConstants.basic)) {
              helpers.setUWDecision(constantValues.decisions.uw_none,
                constantValues.messageConstants.interior_water_message + claim_number + constantValues.messageConstants.prior_claims_part_two);
            }
            if ((category == constantValues.policyValueConstants.theft_burglary) && (theft_burglary_chargeable_claim > constantValues.numberConstants.twenty_five_hundred) && ((uw_form == constantValues.policyValueConstants.special) || (uw_form == constantValues.policyValueConstants.comprehensive))) {
              helpers.setUWDecision(constantValues.decisions.uw_none,
                constantValues.messageConstants.theft_burglary + claim_number + constantValues.messageConstants.prior_claims_part_two);
            }
          }
        }
      }
  
    }
  }
  if ((helpers.getCountOfChargeableClaims(data) >= constantValues.numberConstants.three) && (helpers.getNumberOfExposures(allExposures) < constantValues.numberConstants.six)) {
    helpers.setUWDecision(constantValues.decisions.uw_reject,
      constantValues.messageConstants.chargeable_claims);
  }
  if ((helpers.getCountOfChargeableClaims(data) >= constantValues.numberConstants.three) && (helpers.getNumberOfExposures(allExposures) >= constantValues.numberConstants.six)) {
    helpers.setUWDecision(constantValues.decisions.uw_none,
      constantValues.messageConstants.number_of_claims);
  }
}
exports.getPolicyUWDecision = getPolicyUWDecision;