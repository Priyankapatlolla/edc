let constantValues = require("./ruleComparisionFactors.js");
let helpers = require("./helpersUW.js");

function getProcessingRulesUWDecision(data, policy_fv) {
  getProcessingRules(data);
  getUnitConstructionGroup(data);
  getTrampolineLiability(data)
  getUnitDetails(data);
  getFungiWet(data);
  getWaterDamage(data);
  getCoverageA(data);
  getAdditionalInterest(data);
  getUnitAddress(data, policy_fv);
  getScheduleItems(data);
  getUnitLevelUnderwriting(data);
  getCoverageB(data);
  getPriorInsurance(data);
}
function getPriorInsurance(data){
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let uw_prior_insurance_details = policy_fv.prior_insurance_details;
  let uw_prior_insurance = policy_fgv[uw_prior_insurance_details].prior_insurance;
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name !=  constantValues.exposureNameConstants.policy_level_coverages) {
      let unit_details_group = exposure_fv.unit_details;
      let uw_purchase_date = exposure_fgv[unit_details_group].purchase_date;
      if( uw_prior_insurance == constantValues.policyValueConstants.buying_new_home && uw_purchase_date == undefined){
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.home_owenership);
      }
  }
  }

}
function getCoverageA(data) {
  let allExposures = data.policy.exposures;
  let perilNamesArray = [];
  for (let exposure of allExposures) {
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
    }
    if (exposure.name != constantValues.exposureNameConstants.vacant && exposure.name != constantValues.exposureNameConstants.policy_level_coverages && exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      if ((!(perilNamesArray.indexOf(constantValues.perilNameConstants.dwelling) > -1)) && exposure.name != constantValues.exposureNameConstants.vacant) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.coverage_a);
      }
    }
  }
}



function getFungiWet(data) {
  let allExposures = data.policy.exposures;
  let perilNamesArray = [];
  for (let exposure of allExposures) {
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
    }
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages &&
      exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.fungi_wet) > -1) && (!(perilNamesArray.indexOf(constantValues.perilNameConstants.water_damage) > -1))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.fungi);
      }
    }
  }
}

function getWaterDamage(data) {
  let allExposures = data.policy.exposures;
  let unit_details_group;
  let uw_form;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages &&
      exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      unit_details_group = exposure_fv.unit_details;
      uw_form = exposure_fgv[unit_details_group].form;
      for (let peril of exposure.perils) {
        if (peril.name == constantValues.perilNameConstants.water_damage) {
          if (uw_form == constantValues.policyValueConstants.basic) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.water);
          }
        }
      }
    }
  }
}

function getProcessingRules(data) {
  let allExposures = data.policy.exposures;
  let policyholder = data.policyholder.entity.values;
  let perilNamesArray = [];
  let exposureNamesArray = [];
  let policyholder = data.policyholder.entity.values;
  let third_party_consumer = policyholder.third_party_notification_non_consumer;
  if (third_party_consumer == constantValues.binaryConstants.uw_no) {
    helpers.setUWDecision(constantValues.decisions.uw_reject,
      constantValues.messageConstants.third_party_consumer);
  }
  for (let exposure of allExposures) {
    exposureNamesArray.push(exposure.name);
    if ((helpers.getNumberOfExposures(allExposures) > constantValues.numberConstants.one) && ((exposureNamesArray.indexOf(constantValues.exposureNameConstants.owner_occupied) > -1) || (exposureNamesArray.indexOf(constantValues.exposureNameConstants.seasonal_occupied) > -1) || (exposureNamesArray.indexOf(constantValues.exposureNameConstants.tenant_occupied) > -1))) {
      helpers.setUWDecision(constantValues.decisions.uw_reject, exposure.name + constantValues.messageConstants.processing_rule_isolation);
    }
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
    }
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.medical_payments) > -1) &&
        (!((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
          (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_medical_payments);
      }
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.damage_to_property_others) > -1) &&
        (!((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
          (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_without_personal);
      }
    }
    if (exposure.name == constantValues.exposureNameConstants.landlord_occupied || exposure.name == constantValues.exposureNameConstants.vacant) {
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.landlord_personal_injury) > -1) && (!(perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_landlord);
      }
    }
    if (exposure.name == constantValues.exposureNameConstants.tenant_occupied || exposure.name == constantValues.exposureNameConstants.owner_occupied) {
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.animal_liability) > -1) && (!(perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_animal_liability);
      }
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) && (!(perilNamesArray.indexOf(constantValues.perilNameConstants.damage_to_property_others) > -1))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_with_personal);
      }
    }
    if (exposure.name == constantValues.exposureNameConstants.owner_occupied || exposure.name == constantValues.exposureNameConstants.seasonal_occupied || exposure.name == constantValues.exposureNameConstants.tenant_occupied) {
      if ((perilNamesArray.indexOf(constantValues.perilNameConstants.golf_cart) > -1) && (!((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) || (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)))) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_golf_cart);
      }

    }
    if (exposure.name == constantValues.exposureNameConstants.policy_level_coverages) {
      if (!(perilNamesArray.indexOf(constantValues.perilNameConstants.minimum_premium_coverage) > -1)) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_minimum_premium);
      }
    }
  }
  if ((perilNamesArray.indexOf(constantValues.perilNameConstants.schedule_personal_property) > -1) && ((exposureNamesArray.indexOf(constantValues.exposureNameConstants.seasonal_occupied) > -1) || (exposureNamesArray.indexOf(constantValues.exposureNameConstants.landlord_occupied) > -1))) {
    helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.processing_rule_schedule_personal);
  }
}

function getUnitConstructionGroup(data) {
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages &&
      exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      let uw_unit_construction_group = exposure_fv.unit_construction;
      let uw_model_year = exposure_fgv[uw_unit_construction_group].model_year;
      let roof_year = exposure_fgv[uw_unit_construction_group].roof_year_yyyy;
      let current_year = new Date();
      current_year = current_year.getFullYear();
      if (uw_model_year > roof_year) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.processing_rule_model_year);
      }
      if (uw_model_year > current_year) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.processing_rule_current_year);
      }
      if (roof_year > current_year) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.processing_rule_roof_year);
      }
    }
  }
}

function getTrampolineLiability(data) {
  let allExposures = data.policy.exposures;
  let perilNamesArray = [];
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages &&
      exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      let unit_level_suppl_uw = exposure_fv.unit_level_suppl_uw;
      let uw_trampoline_safety_net = exposure_fgv[unit_level_suppl_uw].trampoline_safety_net;
      for (let peril of exposure.perils) {
        perilNamesArray.push(peril.name);
        if (peril.name == constantValues.perilNameConstants.trampoline_liability_extension) {
          if ((uw_trampoline_safety_net == constantValues.binaryConstants.uw_no) && ((perilNamesArray.indexOf(constantValues.perilNameConstants.trampoline_liability_extension) > -1))) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.trampoline_safety_net);
          }
        }
        if (peril.name == constantValues.perilNameConstants.diving_board) {
          if ((uw_trampoline_safety_net == constantValues.binaryConstants.uw_no) && ((perilNamesArray.indexOf(constantValues.perilNameConstants.diving_board) > -1))) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.diving);
          }
        }
      }
    }
  }
}

function getUnitDetails(data) {
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      let unit_details_group = exposure_fv.unit_details;
      let community_policy_discount = exposure_fgv[unit_details_group].community_policy_discount;
      if (community_policy_discount == undefined) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.community_policy_Discount);
      }
    }
  }
}

function getAdditionalInterest(data) {
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      let additional_interest_group = exposure_fv.additional_interest;
      if (additional_interest_group != undefined) {
        for (let each_ad_interest of additional_interest_group) {
          let name_of_interested_party = exposure_fgv[each_ad_interest].name;
          let type_of_interest = exposure_fgv[each_ad_interest].type;
          if ((name_of_interested_party != undefined) && (type_of_interest == undefined)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.additional_interest);
          }
        }
      }
    }
  }
}

function getUnitAddress(data, policy_fv) {
  let allExposures = data.policy.exposures;
  let insurance_score = policy_fv.insurance_score;
  let adverse_action_group = policy_fv.adverse_action;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      let uw_unit_address_group = exposure_fv.unit_address;
      let uw_state = exposure_fgv[uw_unit_address_group].state;
      if (uw_state == constantValues.stateConstants.michigan) {
        if ((insurance_score < constantValues.numberConstants.six_twenty_one) && (adverse_action_group == undefined)) {
          helpers.setUWDecision(constantValues.decisions.uw_reject,
            constantValues.messageConstants.insurance_score);
        }
      }
    }
  }
}

function getScheduleItems(data) {
  let type;
  let allExposures = data.policy.exposures;
  for (let exposure of allExposures) {
    for (let peril of exposure.perils) {
      let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      let peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
      if (exposure.name == constantValues.exposureNameConstants.policy_level_coverages) {
        if (peril.name == constantValues.perilNameConstants.schedule_personal_property) {
          let scheduled_personals = peril_fv.scheduled_personals;
          if (scheduled_personals != undefined) {
            let jewelry_count = 0;
            let guns_and_amminition_count = 0;
            let fine_arts_count = 0;
            let stamps_books_count = 0;
            let camera_recorder_media_count = 0;
            let rare_and_current_coins_count = 0;
            let computer_equipment_count = 0;
            let furs_count = 0;
            let golf_equipment_count = 0;
            let musical_instruments_count = 0;
            let silverware_count = 0;
            let tools_count = 0;
            let bikes_count = 0;
            let all_other_count = 0;
            for (let each_scheduled_personals of scheduled_personals) {
              type = peril_fgv[each_scheduled_personals].spp_type;
              if (type == constantValues.perilValueConstants.jewelry) {
                jewelry_count++;
              }
              if (type == constantValues.perilValueConstants.guns_and_amminition) {
                guns_and_amminition_count++;
              }
              if (type == constantValues.perilValueConstants.fine_arts) {
                fine_arts_count++;
              }
              if (type == constantValues.perilValueConstants.stamps_books) {
                stamps_books_count++;
              }
              if (type == constantValues.perilValueConstants.camera_recorder_media) {
                camera_recorder_media_count++;
              }
              if (type == constantValues.perilValueConstants.rare_and_current_coins) {
                rare_and_current_coins_count++;
              }
              if (type == constantValues.perilValueConstants.computer_equipment) {
                computer_equipment_count++;
              }
              if (type == constantValues.perilValueConstants.furs) {
                furs_count++;
              }
              if (type == constantValues.perilValueConstants.golf_equipment) {
                golf_equipment_count++;
              }
              if (type == constantValues.perilValueConstants.musical_instruments) {
                musical_instruments_count++;
              }
              if (type == constantValues.perilValueConstants.silverware) {
                silverware_count++;
              }
              if (type == constantValues.perilValueConstants.tools) {
                tools_count++;
              }
              if (type == constantValues.perilValueConstants.bikes) {
                bikes_count++;
              }
              if (type == constantValues.perilValueConstants.all_other) {
                all_other_count++;
              }
              if (type == constantValues.perilValueConstants.jewelry &&
                jewelry_count > constantValues.numberConstants.one) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_jewelery);
              }
              if ((type == constantValues.perilValueConstants.guns_and_amminition) &&
                (guns_and_amminition_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_guns);
              }
              if ((type == constantValues.perilValueConstants.furs) &&
                (furs_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_furs);
              }
              if ((type == constantValues.perilValueConstants.fine_arts) &&
                (fine_arts_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_finearts);
              }
              if ((type == constantValues.perilValueConstants.stamps_books) &&
                (stamps_books_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_stamps);
              }
              if ((type == constantValues.perilValueConstants.camera_recorder_media) &&
                (camera_recorder_media_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_camera);
              }
              if ((type == constantValues.perilValueConstants.rare_and_current_coins) &&
                (rare_and_current_coins_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_coins);
              }
              if ((type == constantValues.perilValueConstants.computer_equipment) &&
                (computer_equipment_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_computer);
              }
              if ((type == constantValues.perilValueConstants.golf_equipment) &&
                (golf_equipment_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_golfer);
              }
              if ((type == constantValues.perilValueConstants.musical_instruments) &&
                (musical_instruments_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_musical);
              }
              if ((type == constantValues.perilValueConstants.silverware) &&
                (silverware_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_silverware);
              }
              if ((type == constantValues.perilValueConstants.tools) &&
                (tools_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_tools);
              }
              if ((type == constantValues.perilValueConstants.bikes) &&
                (bikes_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_bikes);
              }
              if ((type == constantValues.perilValueConstants.all_other) &&
                (all_other_count > constantValues.numberConstants.one)) {
                helpers.setUWDecision(constantValues.decisions.uw_reject,
                  constantValues.messageConstants.schedule_other);
              }
            }
          }
        }
      }
    }
  }
}

function getUnitLevelUnderwriting(data) {
  let allExposures = data.policy.exposures;
  let perilNamesArray = [];
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
    }
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      let unit_level_suppl_uw_group = exposure_fv.unit_level_suppl_uw;
      let uw_daycare_on_premises = exposure_fgv[unit_level_suppl_uw_group].daycare_on_premises;
      let uw_business_on_premises = exposure_fgv[unit_level_suppl_uw_group].business_on_premises;
      let business_employees_on_premises = exposure_fgv[unit_level_suppl_uw_group].business_employees_on_premises;
      let visitors_in_a_month = exposure_fgv[unit_level_suppl_uw_group].visitors_in_a_month;
      if ((uw_business_on_premises == constantValues.binaryConstants.uw_yes) && ((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
          (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)) && (uw_daycare_on_premises == undefined)) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.daycare_on_premises);
      }
      if ((uw_business_on_premises == constantValues.binaryConstants.uw_yes) && ((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
          (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)) && (business_employees_on_premises == undefined)) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.business_empolyess);
      }
      if ((uw_business_on_premises == constantValues.binaryConstants.uw_yes) && ((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
          (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1)) && (visitors_in_a_month == undefined)) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.number_of_visitors);
      }
    }
  }
}

function getCoverageB(data) {
  let allExposures = data.policy.exposures;
  let cov_b_settlement_option;
  let cov_a_settlement_option;
  for (let exposure of allExposures) {
    for (let peril of exposure.perils) {
      let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      if ((exposure.name != constantValues.exposureNameConstants.policy_level_coverages) && (exposure.name != constantValues.exposureNameConstants.tenant_occupied)) {
        if (peril.name == constantValues.perilNameConstants.dwelling) {
          cov_a_settlement_option = JSON.stringify(peril_fv.cov_a_settlement_option);
        }
        if (peril.name == constantValues.perilNameConstants.other_structures) {
          cov_b_settlement_option = JSON.stringify(peril_fv.cov_b_settlement_option);
        }
      }
    }
    if (cov_a_settlement_option != undefined && cov_b_settlement_option != undefined) {
      if (cov_a_settlement_option != cov_b_settlement_option) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.cov_b_cov_a);
      }
    }
  }
}
exports.getProcessingRulesUWDecision = getProcessingRulesUWDecision;
