let helpers = require("./helpersUW.js");
let constantValues = require("./ruleComparisionFactors.js");

function getPolicyHolderDecision(data) {
  getHomeowners(data)
}

function getHomeowners(data) {
  let allExposures = data.policy.exposures;
  let policyholder = data.policyholder.entity.values;
  let uw_relationship_organization;
  uw_relationship_organization = policyholder.relationship_organization;
  for (let exposure of allExposures) {
    if (exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      if (uw_relationship_organization == constantValues.policyValueConstants.other) {
        helpers.setUWDecision(constantValues.decisions.uw_none,
          constantValues.messageConstants.relationship_organization);
      }
    }
  }
}

exports.getPolicyHolderDecision = getPolicyHolderDecision;