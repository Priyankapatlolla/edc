let constantValues = require("./ruleComparisionFactors.js");
let moment = require("../libraries/moment-with-locales.js");

function getSumOfScheduleProperty(data) {
  let allExposures = data.policy.exposures;
  let total_schedule_personal_property = constantValues.numberConstants.zero;
  for (let exposure of allExposures) {
    for (let peril of exposure.perils) {
      let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
      let peril_fgv = peril.characteristics[peril.characteristics.length - 1].fieldGroupsByLocator;
      let scheduled_personals;
      let spp_type;
      let spp_value;
      if (exposure.name == constantValues.exposureNameConstants.policy_level_coverages) {
        if (peril.name == constantValues.perilNameConstants.schedule_personal_property) {
          scheduled_personals = peril_fv.scheduled_personals;
          for (let each_schedule_personal of scheduled_personals) {
            spp_type = peril_fgv[each_schedule_personal].spp_type;
            spp_value = parseInt(peril_fgv[each_schedule_personal].spp_value);
            if (spp_type == constantValues.perilValueConstants.stamps_books) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.camera_recorder_media) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.rare_and_current_coins) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.fine_arts) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.furs) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.golf_equipment) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.guns_and_amminition) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.jewelry) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.musical_instruments) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.silverware) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.all_other) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.computer_equipment) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.tools) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
            if (spp_type == constantValues.perilValueConstants.bikes) {
              total_schedule_personal_property = total_schedule_personal_property + spp_value;
            }
          }
        }
      }
    }
  }
  return total_schedule_personal_property;
}

function getCountOfChargeableClaims(data) {
  let chargeable_claims = constantValues.numberConstants.zero;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let uw_prior_claims = policy_fv.prior_claims;
  if (uw_prior_claims != undefined) {
    for (let prior_claims of uw_prior_claims) {
      let uw_category = policy_fgv[prior_claims].category;
      let date_of_loss = policy_fgv[prior_claims].claim_date;
      let today_date = new Date();
      today_date = moment(today_date).format(constantValues.dateFormat.year_month_date);
      let years_differnce = moment(new Date(today_date)).diff(new Date(date_of_loss), 'year', true);
      let amount_of_loss = policy_fgv[prior_claims].claim_amount;
      let loss_chargeable_matrix = constantValues.tableNameConstants.loss_chargeable_matrix;
      let chargeable = socotraApi.tableLookup(loss_chargeable_matrix, uw_category);
      if ((chargeable == constantValues.binaryConstants.uw_yes) && (years_differnce <= constantValues.numberConstants.five) && (amount_of_loss > constantValues.numberConstants.five_hundred)) {
        chargeable_claims = chargeable_claims + constantValues.numberConstants.one;
      } else {
        chargeable_claims = chargeable_claims + constantValues.numberConstants.zero;
      }
    }
  }
  return chargeable_claims;
}

function getNumberOfDaysUninsured(purchase_date, prior_insurance, prior_policy_expiration_date) {

  if (prior_insurance == constantValues.policyValueConstants.buying_new_home && purchase_date == constantValues.exposureValueConstants.purchase_date)
  {
    return constantValues.numberConstants.zero;
  }
  if (prior_insurance == constantValues.policyValueConstants.buying_new_home && purchase_date == constantValues.exposureValueConstants.one_to_seven_days_ago)
  {
    return constantValues.numberConstants.one;
  }
  if (prior_insurance == constantValues.policyValueConstants.buying_new_home && purchase_date == constantValues.exposureValueConstants.eight_to_thirty_days_ago)
  {
    return constantValues.numberConstants.eight;
  }
  if (prior_insurance == constantValues.policyValueConstants.buying_new_home && purchase_date == constantValues.exposureValueConstants.thirtyone_to_ninty_days_ago)
  {
    return constantValues.numberConstants.thirty_one;
  }
  if (prior_insurance == constantValues.policyValueConstants.buying_new_home && purchase_date == constantValues.exposureValueConstants.more_than_ninty_day )
  {
    return constantValues.numberConstants.ninty_one;
  }
  if (prior_insurance == constantValues.policyValueConstants.no_insurance  && prior_policy_expiration_date == constantValues.exposureValueConstants.one_to_seven_days_ago)
  {
    return constantValues.numberConstants.zero;
  }
  if (prior_insurance == constantValues.policyValueConstants.no_insurance && prior_policy_expiration_date == constantValues.exposureValueConstants.eight_to_thirty_days_ago)
  {
    return constantValues.numberConstants.eight;
  }
  if (prior_insurance == constantValues.policyValueConstants.no_insurance && prior_policy_expiration_date == constantValues.exposureValueConstants.thirtyone_to_ninty_days_ago)
  {
    return constantValues.numberConstants.thirty_one;
  }
  if (prior_insurance == constantValues.policyValueConstants.no_insurance && prior_policy_expiration_date == constantValues.exposureValueConstants.more_than_ninty_day || prior_policy_expiration_date == constantValues.exposureValueConstants.never_insured)
  {
    return constantValues.numberConstants.ninty_one;
  }
  if (prior_insurance == constantValues.policyValueConstants.switching_carriers)
  {
    return constantValues.numberConstants.zero;
  }
}

function getSumOfChargeableClaims(data) {
  let sum_of_chargeable_claims = constantValues.numberConstants.zero;
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let uw_prior_claims = policy_fv.prior_claims;
  if (uw_prior_claims != undefined) {
    for (let prior_claims of uw_prior_claims) {
      let uw_category = policy_fgv[prior_claims].category;
      let loss_chargeable_matrix = constantValues.tableNameConstants.loss_chargeable_matrix;
      chargeable = socotraApi.tableLookup(loss_chargeable_matrix, uw_category);

      if (chargeable == constantValues.binaryConstants.uw_yes) {
        if (uw_category == constantValues.policyValueConstants.fire_smoke) {
          sum_of_chargeable_claims = sum_of_chargeable_claims + uw_claim_amount;
          return sum_of_chargeable_claims;
        }
        if (uw_category == constantValues.policyValueConstants.liability) {
          sum_of_chargeable_claims = sum_of_chargeable_claims + uw_claim_amount;
          return sum_of_chargeable_claims;
        }
        if (uw_category == constantValues.policyValueConstants.theft_burglary) {
          sum_of_chargeable_claims = sum_of_chargeable_claims + uw_claim_amount;
          return sum_of_chargeable_claims;
        }
        if (uw_category == constantValues.policyValueConstants.interior_water) {
          sum_of_chargeable_claims = sum_of_chargeable_claims + uw_claim_amount;
          return sum_of_chargeable_claims;
        }
      } else {
        sum_of_chargeable_claims = sum_of_chargeable_claims + constantValues.numberConstants.zero;
      }
    }
  }

  return sum_of_chargeable_claims;

}

function getPolicyTerm(policy_start_timestamp, policy_end_timestamp) {
  var start_time = new Date(+policy_start_timestamp);
  var end_time = new Date(+policy_end_timestamp);
  let months_difference = moment(new Date(end_time)).diff(new Date(start_time), 'months', true);
  return months_difference;
}

function getNumberOfExposures(allExposures) {
  let count_of_units = constantValues.numberConstants.zero;
  for (let exposure of allExposures) {
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      count_of_units++;
    }
  }
  return count_of_units;
}

function getNumberOfAdditionalInterestGroup(exposure) {
  if (exposure.characteristics[exposure.characteristics.length - 1].fieldValues.additional_interest != undefined) {
    return exposure.characteristics[exposure.characteristics.length - 1].fieldValues.additional_interest.length;
  } else {
    return constantValues.numberConstants.zero;
  }
}

function getNumberOfPriorClaimsGroup(data) {
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  let prior_claims_group = policy_fv.prior_claims;
  for (let prior_claims of prior_claims_group) {
    if (data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues.prior_claims != undefined) {
      return data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues.prior_claims.length;
    } else {
      return constantValues.numberConstants.zero;
    }

  }

}

function getNumberOfAdditionalInsuredGroup(uw_ad_insured) {
  if (uw_ad_insured != undefined) {
    return uw_ad_insured.length;
  } else {
    return constantValues.numberConstants.zero;
  }

}

function getManufacturedLimit(exposure) {
  for (let peril of exposure.perils) {
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    if (exposure.name == constantValues.exposureNameConstants.owner_occupied || exposure.name == constantValues.exposureNameConstants.seasonal_occupied || exposure.name == constantValues.exposureNameConstants.landlord_occupied || exposure.name == constantValues.exposureNameConstants.vacant) {
      if (peril.name == constantValues.perilNameConstants.dwelling) {
        let uw_manufactured_home_limit = JSON.stringify(peril_fv.manufactured_home_limit);
        if (uw_manufactured_home_limit != undefined) {
          uw_manufactured_home_limit = parseInt(JSON.parse(uw_manufactured_home_limit.replace(/[$,]/g, "")));
        }
        return uw_manufactured_home_limit;
      }
    }
  }
}

function getOtherStructuresLimit(exposure) {

  for (let peril of exposure.perils) {
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    if (exposure.name == constantValues.exposureNameConstants.owner_occupied || exposure.name == constantValues.exposureNameConstants.seasonal_occupied || exposure.name == constantValues.exposureNameConstants.landlord_occupied || exposure.name == constantValues.exposureNameConstants.vacant) {
      if (peril.name == constantValues.perilNameConstants.other_structures) {
        let other_structures_limit = JSON.stringify(peril_fv.other_structures_limit);
        if (other_structures_limit != undefined) {
          other_structures_limit = parseInt(JSON.parse(other_structures_limit.replace(/[$,]/g, "")));
        }
        return other_structures_limit;
      }
    }
  }

}

function getUnscheduledPropertyLimit(exposure) {

  for (let peril of exposure.perils) {
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      if (peril.name == constantValues.perilNameConstants.personal_property) {
        let unscheduled_personal_property_limit = JSON.stringify(peril_fv.unscheduled_personal_property_limit);
        if (unscheduled_personal_property_limit != undefined) {
          unscheduled_personal_property_limit = parseInt(JSON.parse(unscheduled_personal_property_limit.replace(/[$,]/g, "")));
        }
        return unscheduled_personal_property_limit;
      }
    }
  }

}

function getPremisesLiabilityLimit(exposure) {
  for (let peril of exposure.perils) {
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages && exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      if (peril.name == constantValues.perilNameConstants.premises_liability) {
        let premises_liability_limit = JSON.stringify(peril_fv.premises_liability_limit);
        if (premises_liability_limit != undefined) {
          premises_liability_limit = parseInt(JSON.parse(premises_liability_limit.replace(/[$,]/g, "")));

        }
        return premises_liability_limit;
      }
    }
  }
}

function getWindHailLimit(exposure) {
  let wind_hail_deductible;
  let peril_fv;

  for (let peril of exposure.perils) {
    peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    if (exposure.name == constantValues.exposureNameConstants.owner_occupied || exposure.name == constantValues.exposureNameConstants.seasonal_occupied || exposure.name == constantValues.exposureNameConstants.landlord_occupied || exposure.name == constantValues.exposureNameConstants.vacant) {
      if (peril.name == constantValues.perilNameConstants.deductibles) {
        wind_hail_deductible = JSON.stringify(peril_fv.wind_hail_deductible);
        wind_hail_deductible = wind_hail_deductible.replace(/[$,]/g, "");
        return wind_hail_deductible;
      }
    }
  }


}

function getAllOtherPerilsLimit(exposure) {
  let all_other_perils_deductible;
  for (let peril of exposure.perils) {
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    if (exposure.name == constantValues.exposureNameConstants.owner_occupied || exposure.name == constantValues.exposureNameConstants.seasonal_occupied || exposure.name == constantValues.exposureNameConstants.landlord_occupied || exposure.name == constantValues.exposureNameConstants.vacant || exposure.name == constantValues.exposureNameConstants.tenant_occupied) {
      if (peril.name == constantValues.perilNameConstants.deductibles) {
        all_other_perils_deductible = JSON.stringify(peril_fv.all_other_perils_deductible);
        all_other_perils_deductible = all_other_perils_deductible.replace(/[$,]/g, "");
        return all_other_perils_deductible;
      }
    }

  }
}

function getPersonalLiabilityLimit(exposure) {
  for (let peril of exposure.perils) {
    let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      if (peril.name == constantValues.perilNameConstants.personal_liability) {
        let personal_liability = JSON.stringify(peril_fv.personal_liability);
        if (personal_liability != undefined) {
          personal_liability = parseInt(JSON.parse(personal_liability.replace(/[$,]/g, "")));

        }
        return personal_liability;
      }
    }
  }
}

function addDays(date, days) {
  var result = new Date(date);
  result.setDate(result.getDate() + days);
  return result;
}

let uw_result = {
  uw_notes: [] = [],
  uw_decisions: ""
}

function setUWDecision(decisions, notes) {
  if (uw_result.uw_decisions != constantValues.decisions.uw_reject) {
    if (decisions == constantValues.decisions.uw_reject) {
      uw_result.uw_decisions = constantValues.decisions.uw_reject;
    } else if (decisions == constantValues.decisions.uw_none) {
      uw_result.uw_decisions = constantValues.decisions.uw_none;
    } else if (decisions == constantValues.decisions.uw_accept) {
      if (uw_result.uw_decisions != constantValues.decisions.uw_none) {
        uw_result.uw_decisions = constantValues.decisions.uw_accept;
      }
    }
  }
  if (decisions != constantValues.decisions.uw_accept) {
    uw_result.uw_notes.push(notes);
  }
  return uw_result;

}

function removeDuplicateUWResults(arr) {
  var i,
    len = arr.length,
    output = [],
    obj = {};
  for (i = constantValues.numberConstants.zero; i < len; i++) {
    obj[arr[i]] = constantValues.numberConstants.zero;
  }
  for (i in obj) {
    output.push(i);
  }
  return output;
}

function containsAny(str, ArraySubstrings) {
  for (var i = constantValues.numberConstants.zero; i != ArraySubstrings.length; i++) {
    var substring = ArraySubstrings[i].toLowerCase();
    if (str.toLowerCase().indexOf(substring) != -1) {
      return true;
    }
  }
  return false;
}

exports.getNumberOfDaysUninsured = getNumberOfDaysUninsured;
exports.getSumOfScheduleProperty = getSumOfScheduleProperty;
exports.setUWDecision = setUWDecision;
exports.uw_result = uw_result;
exports.getWindHailLimit = getWindHailLimit;
exports.getAllOtherPerilsLimit = getAllOtherPerilsLimit;
exports.getPersonalLiabilityLimit = getPersonalLiabilityLimit;
exports.getPremisesLiabilityLimit = getPremisesLiabilityLimit;
exports.getManufacturedLimit = getManufacturedLimit;
exports.getOtherStructuresLimit = getOtherStructuresLimit;
exports.getUnscheduledPropertyLimit = getUnscheduledPropertyLimit;
exports.containsAny = containsAny;
exports.getNumberOfPriorClaimsGroup = getNumberOfPriorClaimsGroup;
exports.getNumberOfAdditionalInsuredGroup = getNumberOfAdditionalInsuredGroup;
exports.getNumberOfAdditionalInterestGroup = getNumberOfAdditionalInterestGroup
exports.getSumOfChargeableClaims = getSumOfChargeableClaims;
exports.getCountOfChargeableClaims = getCountOfChargeableClaims;
exports.getPolicyTerm = getPolicyTerm;
exports.getNumberOfExposures = getNumberOfExposures;
exports.removeDuplicateUWResults = removeDuplicateUWResults;
exports.addDays = addDays;