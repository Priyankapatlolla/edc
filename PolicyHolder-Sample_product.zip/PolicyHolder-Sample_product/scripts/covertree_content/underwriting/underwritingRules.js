let exposureUW = require("./exposureUW.js");
let perilUW = require("./perilUW.js");
let manualUW = require("./manualUW.js");
let helpers = require("./helpersUW.js");
let policyUW = require("./policyUW.js");
let processingRules = require("./processingRules.js");
let constantValues = require("./ruleComparisionFactors.js");
let policyholderUW = require("./policyholderUW.js");

function getUWDecision(data) {
  let policy_fv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldValues;
  let policy_fgv = data.policy.characteristics[data.policy.characteristics.length - 1].fieldGroupsByLocator;
  if (policy_fv.uw_details == undefined || policy_fgv[policy_fv.uw_details].manual_decision == undefined) {
    helpers.uw_result.uw_notes = [];
    helpers.uw_result.uw_decisions = "";
    processingRules.getProcessingRulesUWDecision(data, policy_fv);
    policyholderUW.getPolicyHolderDecision(data);
    policyUW.getPolicyUWDecision(data);
    exposureUW.getExposureUWDecision(data);
    perilUW.getPerilUWDesicion(data, policy_fv, policy_fgv);
    let result = helpers.setUWDecision(constantValues.decisions.uw_accept, constantValues.messageConstants.accept_notes);
    console.log("🚀 ~ file: underwritingRules.js ~ line 27 ~ getUWDecision ~ result", JSON.stringify(result))
    if (result.uw_decisions == constantValues.decisions.uw_accept) {
      helpers.uw_result.uw_notes.push(constantValues.messageConstants.accept_notes);
    }
    return result;
  } else {
    let result = manualUW.getManualUWDecision(data);
    return result;
  }
}
exports.getUWDecision = getUWDecision;