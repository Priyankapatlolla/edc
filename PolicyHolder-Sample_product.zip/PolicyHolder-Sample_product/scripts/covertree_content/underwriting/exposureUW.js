let constantValues = require("./ruleComparisionFactors.js");
let helpers = require("./helpersUW.js");

function getExposureUWDecision(data) {
  getExposures(data);
  getUnitDetails(data);
  getUnitConstructionDetails(data);
  getUnitAddress(data);
  getUnitLevelUnderwriting(data);
  getAdditionalInterestDetails(data);
  getUsage(data);
  getterritory(data);
}

function getExposures(data) {
  let allExposures = data.policy.exposures;
  let exposureNamesArray = [];
  let count_of_exposures = helpers.getNumberOfExposures(allExposures);
  for (let exposure of allExposures) {
    exposureNamesArray.push(exposure.name);
  }
  exposureNamesArray = helpers.removeDuplicateUWResults(exposureNamesArray);
  if ((count_of_exposures > constantValues.numberConstants.one) &&
    ((exposureNamesArray.indexOf(constantValues.exposureNameConstants.owner_occupied) > -1) ||
      (exposureNamesArray.indexOf(constantValues.exposureNameConstants.seasonal_occupied) > -1) ||
      (exposureNamesArray.indexOf(constantValues.exposureNameConstants.tenant_occupied) > -1))) {
    helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.occupancy);
  }

}

function getAdditionalInterestDetails(data) {
  let allExposures = data.policy.exposures;
  let exposureNamesArray = [];
  let type;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    exposureNamesArray.push(exposure.name);
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      let uw_additional_interest = exposure_fv.additional_interest;
      if (uw_additional_interest != undefined) {
        let property_manager_count = constantValues.numberConstants.zero;
        let lienholder_count = constantValues.numberConstants.zero;
        let homeowners_association_count = constantValues.numberConstants.zero;
        let unit_id;
        for (let each_ad_interest of uw_additional_interest) {
          type = exposure_fgv[each_ad_interest].type;
          unit_id = exposure_fgv[each_ad_interest].additional_interest_id;
          if (type == constantValues.exposureValueConstants.property_manager_park_owner) {
            property_manager_count++;
          }
          if (type == constantValues.exposureValueConstants.lienholder) {
            lienholder_count++;
          }
          if (type == constantValues.exposureValueConstants.homeowners_association) {
            homeowners_association_count++;
          }
          
        }
        if ((type == constantValues.exposureValueConstants.homeowners_association) && (homeowners_association_count >= constantValues.numberConstants.two)) {
          helpers.setUWDecision(constantValues.decisions.uw_none,
            constantValues.messageConstants.homeowners_association_message + exposure.name + constantValues.messageConstants.unit_id + unit_id + constantValues.messageConstants.additional_interest_part_two);
        }
        if ((type == constantValues.exposureValueConstants.lienholder) && (lienholder_count >= constantValues.numberConstants.three)) {
          helpers.setUWDecision(constantValues.decisions.uw_none,
            constantValues.messageConstants.lienholder_message + exposure.name + constantValues.messageConstants.unit_id + unit_id + constantValues.messageConstants.additional_interest_part_two);
        }
        if ((type == constantValues.exposureValueConstants.property_manager_park_owner) &&
        (property_manager_count >= constantValues.numberConstants.three)) {
        helpers.setUWDecision(constantValues.decisions.uw_none,
          constantValues.messageConstants.property_manager + exposure.name + constantValues.messageConstants.unit_id + unit_id + constantValues.messageConstants.additional_interest_part_two);
      }
      }
    }
  }
}

function getUnitAddress(data) {
  let allExposures = data.policy.exposures;
  let uw_street_address;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      let uw_unit_address = exposure_fv.unit_address;
      uw_street_address = JSON.stringify(exposure_fgv[uw_unit_address].street_address);
      if (helpers.containsAny(uw_street_address, constantValues.descriptionConstantsreject.property_address)) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.property_address_message);
      }
    }
  }
}

function getUnitDetails(data) {
  let allExposures = data.policy.exposures;
  let unit_level_suppl_uw_group;
  let uw_form;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if ((exposure.name != constantValues.exposureNameConstants.policy_level_coverages) && (exposure.name != constantValues.exposureNameConstants.tenant_occupied)) {
      let uw_unit_details = exposure_fv.unit_details;
      uw_form = exposure_fgv[uw_unit_details].form;
      unit_level_suppl_uw_group = exposure_fv.unit_level_suppl_uw;
      let uw_unit_construction_group = exposure_fv.unit_construction;
      let uw_skirting_type = exposure_fgv[uw_unit_construction_group].skirting_type;
      if ((uw_skirting_type == constantValues.exposureValueConstants.uw_notfully) &&
        (uw_form != constantValues.exposureValueConstants.uw_basic)) {
        helpers.setUWDecision(constantValues.decisions.uw_none,
          constantValues.messageConstants.skirting_type);
      }
    }
    if (exposure.name == constantValues.exposureNameConstants.seasonal_occupied ||
      exposure.name == constantValues.exposureNameConstants.vacant) {
      uw_utility_services = exposure_fgv[unit_level_suppl_uw_group].utility_services;
      if ((uw_utility_services == constantValues.binaryConstants.uw_no) &&
        (uw_form != constantValues.exposureValueConstants.uw_basic)) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.utility_services);
      }
    }
    if (exposure.name == constantValues.exposureNameConstants.owner_occupied ||
      exposure.name == constantValues.exposureNameConstants.landlord_occupied) {
      uw_utility_services = exposure_fgv[unit_level_suppl_uw_group].utility_services;
      if ((uw_utility_services == constantValues.binaryConstants.uw_no)) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.utility_services);
      }
    }
  }
}

function getUnitLevelUnderwriting(data) {
  let allExposures = data.policy.exposures;
  let uw_four_feet_fence;
  let uw_unit_is_tied;
  let uw_secure_rails;
  let uw_unrepaired_damages;
  let uw_thermo_static_control;
  let unit_level_suppl_uw_group;
  let perilNamesArray = [];
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages &&
      exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      unit_level_suppl_uw_group = exposure_fv.unit_level_suppl_uw;
      uw_four_feet_fence = exposure_fgv[unit_level_suppl_uw_group].four_feet_fence;
      uw_unit_is_tied = exposure_fgv[unit_level_suppl_uw_group].unit_is_tied;
      uw_secure_rails = exposure_fgv[unit_level_suppl_uw_group].secure_rails;
      uw_unrepaired_damages = exposure_fgv[unit_level_suppl_uw_group].unrepaired_damages;
      uw_thermo_static_control = exposure_fgv[unit_level_suppl_uw_group].thermo_static_control;
      let uw_source_of_heat_installation = exposure_fgv[unit_level_suppl_uw_group].source_of_heat_installation;
      let type_of_fuel = exposure_fgv[unit_level_suppl_uw_group].type_of_fuel;
      let uw_mortgage = exposure_fgv[unit_level_suppl_uw_group].mortgage;
      if (uw_mortgage == constantValues.binaryConstants.uw_yes) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.mortgage);
      }
      if (uw_unit_is_tied == constantValues.binaryConstants.uw_no) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.unit_is_tied);
      }
      if (uw_unrepaired_damages != undefined) {
        if (uw_unrepaired_damages == constantValues.binaryConstants.uw_yes) {
          helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.unrepaired_damages);
        }
      }

      if (uw_source_of_heat_installation == constantValues.binaryConstants.uw_no) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.source_of_heat_installation);
      }
      if (type_of_fuel == constantValues.exposureValueConstants.uw_notlisted) {
        helpers.setUWDecision(constantValues.decisions.uw_none,
          constantValues.messageConstants.type_of_fuel);
      }
    }
    if (exposure.name == constantValues.exposureNameConstants.seasonal_occupied ||
      exposure.name == constantValues.exposureNameConstants.vacant) {
      if (uw_thermo_static_control == constantValues.binaryConstants.uw_no) {
        helpers.setUWDecision(constantValues.decisions.uw_none,
          constantValues.messageConstants.thermo_static_control);
      }
    }
    if (exposure.name == constantValues.exposureNameConstants.owner_occupied ||
      exposure.name == constantValues.exposureNameConstants.landlord_occupied) {
      if (uw_thermo_static_control == constantValues.binaryConstants.uw_no) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.thermo_static_control_reject);
      }
    }
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      unit_level_suppl_uw_group = exposure_fv.unit_level_suppl_uw;
      let uw_property_without_fire_protection = exposure_fgv[unit_level_suppl_uw_group].property_without_fire_protection;
      let uw_business_on_premises = exposure_fgv[unit_level_suppl_uw_group].business_on_premises;
      let uw_daycare_on_premises = exposure_fgv[unit_level_suppl_uw_group].daycare_on_premises;
      if (uw_daycare_on_premises == constantValues.binaryConstants.uw_yes) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.business_day_care);
      }
      if (uw_business_on_premises == constantValues.binaryConstants.uw_yes) {
        helpers.setUWDecision(constantValues.decisions.uw_none,
          constantValues.messageConstants.business_on_premises);
      }

      if (uw_property_without_fire_protection == constantValues.binaryConstants.uw_no) {
        helpers.setUWDecision(constantValues.decisions.uw_reject, constantValues.messageConstants.property_without_fire_protection);
      }
    }
    for (let peril of exposure.perils) {
      perilNamesArray.push(peril.name);
      if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages && exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
        if (peril.name == constantValues.perilNameConstants.personal_liability || peril.name == constantValues.perilNameConstants.premises_liability) {

          if ((uw_four_feet_fence == constantValues.binaryConstants.uw_no) &&
            ((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
              (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1))) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.four_feet_fence);
          }

          if ((uw_secure_rails == constantValues.binaryConstants.uw_no) &&
            ((perilNamesArray.indexOf(constantValues.perilNameConstants.personal_liability) > -1) ||
              (perilNamesArray.indexOf(constantValues.perilNameConstants.premises_liability) > -1))) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.secure_rails);
          }
        }
      }
    }

  }
}

function getUnitConstructionDetails(data) {
  let allExposures = data.policy.exposures;
  let uw_manufactured_home_limit;
  let cov_a_settlement_option;
  let uw_model_year;
  let uw_total_square_footage;
  let uw_home_type;
  let uw_roof_condition;
  let perilNamesArray = [];
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages &&
      exposure.name != constantValues.exposureNameConstants.tenant_occupied) {
      let uw_unit_construction_group = exposure_fv.unit_construction;
      uw_model_year = exposure_fgv[uw_unit_construction_group].model_year;
      uw_total_square_footage = exposure_fgv[uw_unit_construction_group].total_square_footage;
      uw_home_type = exposure_fgv[uw_unit_construction_group].home_type;
      uw_roof_condition = exposure_fgv[uw_unit_construction_group].roof_condition;
      let uw_today = new Date();
      let uw_this_yyyy = uw_today.getFullYear();
      uw_model_year = uw_this_yyyy - uw_model_year;
      // if (uw_home_type == constantValues.exposureValueConstants.shipping_container_home) {
      //   helpers.setUWDecision(constantValues.decisions.uw_reject,
      //     constantValues.messageConstants.shipping_containers);
      // }
      if (uw_total_square_footage < constantValues.numberConstants.hundred || uw_total_square_footage > constantValues.numberConstants.nine_nine_nine_nine) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.total_square_footage);
      }
      for (let peril of exposure.perils) {
        perilNamesArray.push(peril.name);
        let peril_fv = peril.characteristics[peril.characteristics.length - 1].fieldValues;
        if (peril.name == constantValues.perilNameConstants.dwelling) {
          cov_a_settlement_option = peril_fv.cov_a_settlement_option;
          uw_manufactured_home_limit = helpers.getManufacturedLimit(exposure);
          if ((uw_manufactured_home_limit < constantValues.numberConstants.twenty_five_thousand) && (uw_total_square_footage < constantValues.numberConstants.one_thousand)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.dwelling_settlement_option);
          }
          if ((uw_manufactured_home_limit < constantValues.numberConstants.thirty_five_thousand) && (uw_total_square_footage >= constantValues.numberConstants.one_thousand)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.dwelling_settlement_option);
          }
          if ((uw_home_type == constantValues.exposureValueConstants.stationary_travel_trailer) &&
            ((cov_a_settlement_option == constantValues.perilValueConstants.replacement_cost ||
              cov_a_settlement_option == constantValues.perilValueConstants.extended_replacement_cost))) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.home_type_stationary);
          }
          if ((uw_model_year > constantValues.numberConstants.thirty) && (cov_a_settlement_option == constantValues.perilValueConstants.replacement_cost || cov_a_settlement_option == constantValues.perilValueConstants.extended_replacement_cost)) {
            helpers.setUWDecision(constantValues.decisions.uw_reject,
              constantValues.messageConstants.model_year);
          }
        }
      }
    }
    if ((uw_roof_condition == constantValues.exposureValueConstants.severe) && (!(perilNamesArray.indexOf(constantValues.perilNameConstants.roof_exclusion) > -1))) {
      helpers.setUWDecision(constantValues.decisions.uw_none,
        constantValues.messageConstants.reported_condition);
    }
  }
}

function getUsage(data) {
  let allExposures = data.policy.exposures;
  let uw_vacancy_reason;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name == constantValues.exposureNameConstants.vacant) {
      let uw_usage = exposure_fv.usage;
      uw_vacancy_reason = exposure_fgv[uw_usage].vacancy_reason;
      if (uw_vacancy_reason == constantValues.exposureValueConstants.condemned) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.vacancy_condemned);
      }
      if (uw_vacancy_reason == constantValues.exposureValueConstants.other) {
        helpers.setUWDecision(constantValues.decisions.uw_none,
          constantValues.messageConstants.vacancy_reason);
      }
    }

  }

}

function getterritory(data) {
  let allExposures = data.policy.exposures;
  let uw_admitted;
  let uw_territory;
  for (let exposure of allExposures) {
    let exposure_fv = exposure.characteristics[exposure.characteristics.length - 1].fieldValues;
    let exposure_fgv = exposure.characteristics[exposure.characteristics.length - 1].fieldGroupsByLocator;
    if (exposure.name != constantValues.exposureNameConstants.policy_level_coverages) {
      uw_territory = exposure_fv.territory;
      uw_admitted = exposure_fgv[uw_territory].uw_admitted;
      if (uw_admitted == constantValues.uwDetails.uw_refer) {
        helpers.setUWDecision(constantValues.decisions.uw_none,
          constantValues.messageConstants.uw_ref);
      }
      if (uw_admitted == constantValues.uwDetails.uw_reject) {
        helpers.setUWDecision(constantValues.decisions.uw_reject,
          constantValues.messageConstants.uw_rjct);
      }
    }

  }
}

exports.getExposureUWDecision = getExposureUWDecision;