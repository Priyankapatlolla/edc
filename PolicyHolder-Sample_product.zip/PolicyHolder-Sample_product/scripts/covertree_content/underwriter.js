let underwritingRules = require("./underwriting/underwritingRules.js");

function getUnderwritingResult(data)
{
   let result = underwritingRules.getUWDecision(data);
   return {
      decision: result.uw_decisions,
      notes: result.uw_notes
   };
}
exports.getUnderwritingResult = getUnderwritingResult;