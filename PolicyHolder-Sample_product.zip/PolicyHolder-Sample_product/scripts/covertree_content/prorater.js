let dates = require('./libraries/dates.js');
let moment = require('./libraries/moment-with-locales.js');
let prorationConstants = require("./constants/constants.js");

function getProrationResult(data)
{
  return {
    items: data.items.map(item => prorateItem(data, item))
  };
}

function prorateItem(data, item)
{
  let fraction = getLinearFraction(data, item);
  console.log("🚀 ~ file: prorater.js ~ line 15 ~ fraction", fraction)

  let amount = round2(fraction * parseFloat(item.amount));
  console.log("🚀 ~ file: prorater.js ~ line 17 ~ amount", amount)

  return {
    id: item.id,
    proratedAmount: amount,
    holdbackAmount: prorationConstants.numberConstants.zero
  };

}

function getDaysBetweenTimestamp(end_timestamp, start_timestamp)
{
  var start_time = new Date(+start_timestamp);
  var end_time = new Date(+end_timestamp);
  let days_diff = moment(new Date(end_time)).diff(new Date(start_time), 'days', true);
  return Math.round(days_diff);
}

function getLinearFraction(data, item)
{
  return Math.max(0,
    Math.min(1.0,
      (getDaysBetweenTimestamp(parseInt(data.segmentSplitTimestamp), parseInt(item.segmentStartTimestamp))) /
      (getDaysBetweenTimestamp(parseInt(item.segmentEndTimestamp), parseInt(item.segmentStartTimestamp)))));
}

function round2(num)
{
  return Math.round(num * 100) / 100.0;
}

exports.getProrationResult = getProrationResult;