const lib = require("./moment-timezone-with-data.js");

const defaults = Object.freeze({
  //format: lib.defaultFormat, // ISO-8601 w/o milliseconds
  format: "YYYY-MM-DDTHH:mm:ss.SSSZ", // vs. + milliseconds
});

const settings = Object.assign({}, defaults);

function parseDate(string, format) {
  //return lib.parseZone(string, format).toDate();
  return lib(string, format);
}

function formatDate(ts, tz = "UTC") {
  return lib.tz(ts, tz).format(settings.format);
}

function fromTimestamp(ts, tz = "UTC") {
  return lib.tz(lib(new Date(parseInt(ts))), tz);
}

function getTimestamp(date) {
  return date.valueOf();
}

function span(start, end, increment) {
  let cursor = start.clone();
  let baseDay = start.date();

  let ret = [];

  while (cursor < end) {
    ret.push(cursor);
    switch (increment) {
      case 'month':
        cursor = incrementMonth(cursor, baseDay);
        break;
      case 'quarter':
        cursor = incrementMonth(cursor, baseDay, 3);
        break;
      case 'semiannually':
        cursor = incrementMonth(cursor, baseDay, 6);
        break;
      case 'elevenpay':
        cursor = incrementMonth(cursor, baseDay, 11);
        break;
      case 'week':
        cursor = incrementWeek(cursor);
        break;
      case 'days':
        cursor = incrementDays(cursor);
        break;
      case '2week':
        cursor = incrementWeek(cursor, 2);
        break;
      default:
        throw increment + "not supported!";
    }
  }
  return ret;
}

function incrementWeek(date, numWeeks = 1) {
  let ret = date.clone();
  ret.add(numWeeks * 7, 'days');
  return ret;
}

function incrementDays(date, numDays = 1) {
  let ret = date.clone();
  ret.add(numDays, 'days');
  return ret;
}

function incrementMonth(date, baseDayOfMonth = null, numMonths = 1) {
  baseDayOfMonth |= date.date();

  let nextMonth = date.clone();
  nextMonth.set('month', date.month() + numMonths);

  if (nextMonth.date() < baseDayOfMonth) {
    lastDayOfMonth = nextMonth.clone();
    lastDayOfMonth.endOf('month');
    if (lastDayOfMonth.date() < baseDayOfMonth)
      nextMonth.set('date', lastDayOfMonth.date());
    else
      nextMonth.set('date', baseDayOfMonth);
  } else if (nextMonth.date() > baseDayOfMonth) {
    nextMonth.set('date', baseDayOfMonth);
  }
  return nextMonth;
}

function monthCount(start, end) {
  let startDayOfMonth = start.date();

  var count = 0.0;
  while (start < end) {
    var next = incrementMonth(start, startDayOfMonth);
    if (next > end)
      count += end.diff(start, "millisecond", true) / next.diff(start, "millisecond", true);
    else
      count++;
    start = next;
  }
  return count;
}

function test() {
  let x = lib(new Date(2021, 0, 31));
  let y = incrementMonth(x, 31);

  if (y.isSame(lib(new Date(2021, 1, 28))))
    console.log('incrementMonth 2021-01-31 => 2021-02-28 OK');
  else
    console.log('incrementMonth 2021-01-31 => 2021-02-28 FAIL');

  x = lib(new Date(2021, 0, 30));
  y = incrementMonth(x, 24);

  if (y.isSame(lib(new Date(2021, 1, 24))))
    console.log('incrementMonth 2021-01-31 => 2021-02-24 OK');
  else
    console.log('incrementMonth 2021-01-31 => 2021-02-24 FAIL');

  x = lib(new Date(2021, 4, 5));
  y = incrementMonth(x, 31);

  if (y.isSame(lib(new Date(2021, 5, 30))))
    console.log('incrementMonth 2021-05-05 => 2021-06-30 OK');
  else
    console.log('incrementMonth 2021-05-05 => 2021-06-30 FAIL');
}

function copy(d) {
  return lib(d);
}

module.exports = {
  formatDate,
  parseDate,
  fromTimestamp,
  getTimestamp,
  incrementMonth,
  monthCount,
  span,
  copy,
  test,
  settings,
};