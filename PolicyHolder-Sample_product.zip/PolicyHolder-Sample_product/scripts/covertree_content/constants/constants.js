let operationConstants = {
   new_business : "newBusiness",
   endorsement : "endorsement",
   fee_assessment : "feeAssessment"
}

let paymentScheduleConstants = {
   full_pay : "Full Pay",
   two_pay : "2-Pay",
   eleven_pay : "11-Pay"
}

let termConstants = {
   semiannually : "semiannually",
   month : "month",
   exception : "Payment schedule is not implemented!"
}

let numberConstants = {
   thousand : 1000,
   two: 2,
   eleven: 11,
   zero: 0
}

let feeConstants = {
   fee: "fee",
   tax: "tax",
   two_pay_fee : "two_pay_fee",
   eleven_pay_fee: "eleven_pay_fee"
}

let perilNameConstants = {
   trip_collision: "Trip Collision"
}

exports.perilNameConstants = perilNameConstants;
exports.numberConstants = numberConstants;
exports.feeConstants = feeConstants;
exports.operationConstants = operationConstants;
exports.paymentScheduleConstants = paymentScheduleConstants;
exports.termConstants = termConstants;