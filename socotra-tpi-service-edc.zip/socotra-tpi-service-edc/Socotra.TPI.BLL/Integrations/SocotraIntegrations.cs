﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using Socotra.TPI.BLL.Models;

namespace Socotra.TPI.BLL.Integrations
{
    public class SocotraIntegrations
    {
        public string Authenticate()
        {
            string response = string.Empty;
            string url = "https://api.sandbox.socotra.com/account/authenticate";
            var client = new RestClient(url);
            var request = new RestRequest(Method.POST);
            // Update hostname and credentials below
            var reqBody = new SocotraAuthenticate() { 
                hostName = "ekrishna-may21dev-configeditor.co.sandbox.socotra.com", 
                username = "alice.lee", 
                password = "socotra" 
            };
            var serializer = JsonConvert.SerializeObject(reqBody, Formatting.None);
            request.AddParameter("application/json", serializer, ParameterType.RequestBody);
            var restResponse = client.Execute(request);
            var responseToken = JObject.Parse(restResponse.Content);
            response = responseToken["authorizationToken"].ToString();
            return response;
        }

        public string FetchPolicy(string authToken, string policyLocator, ILogger _logger)
        {
            string fetchPolicy = "https://api.sandbox.socotra.com/policy/" + policyLocator;
            var getClient = new RestClient(fetchPolicy);
            var getRequest = new RestRequest(Method.GET);
            getRequest.AddHeader("Authorization", authToken);
            var restGetResponse = getClient.Execute(getRequest);
            var response = restGetResponse.Content.ToString();
            return response;
        }
        public string UpdatePolicy(string authToken, string policyLocator, ILogger _logger)
        {
            var fetchPolicyResponseBefore = FetchPolicy(authToken, policyLocator, _logger);
            _logger.LogInformation("Fetch Policy Before Update Policy : " + fetchPolicyResponseBefore);
            string updatePolicy = "https://api.sandbox.socotra.com/policy/" + policyLocator + "/update";
            var client = new RestClient(updatePolicy);
            var updateRequest = new RestRequest(Method.POST);
            updateRequest.AddHeader("Authorization", authToken);
            var reqBody = new SocotraUpdatePolicy()
            {
                fieldValues = new VeriskAttributes()
                {
                    value_360 = "Value updated using Update Policy API"
                }
            };
            var serializer = JsonConvert.SerializeObject(reqBody, Formatting.None);
            _logger.LogInformation("Update Policy Request: " + serializer);
            updateRequest.AddParameter("application/json", serializer, ParameterType.RequestBody);
            var restUpdateResponse = client.Execute(updateRequest);
            _logger.LogInformation("PolicyLocator: " + policyLocator + " Update Policy Response: " + restUpdateResponse.Content);
            string updatePolicyResponse = restUpdateResponse.Content.ToString();
            var fetchPolicyResponseAfter = FetchPolicy(authToken, policyLocator, _logger);
            _logger.LogInformation("Fetch Policy After Update Policy : " + fetchPolicyResponseAfter);
            return updatePolicyResponse;
        }
    }
}
