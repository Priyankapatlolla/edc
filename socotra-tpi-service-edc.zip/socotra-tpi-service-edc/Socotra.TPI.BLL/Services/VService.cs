﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Socotra.TPI.BLL.Integrations;
using Socotra.TPI.BLL.Models;

namespace Socotra.TPI.BLL.Services
{
    public class VService
    {
        public dynamic Get360V(dynamic policyData, ILogger _logger)
        {
            var policyRequest = JObject.Parse(policyData.ToString());

            string policyLocator = policyRequest.policy.locator.ToString();

            if (policyRequest["policy"]["characteristics"][0]["fieldValues"]["response_360v"] == null)
            {
                SocotraIntegrations socotraIntegrations = new SocotraIntegrations();

                var authToken = socotraIntegrations.Authenticate();
                string updatePolicy = socotraIntegrations.UpdatePolicy(authToken, policyLocator, _logger);            

                var resBody = new SocotraResponse()
                {
                    fieldValues = new FieldValues
                    {
                        response_360v = new[] { "Updated values from Third Party using Socotra Update Policy API" }
                    }
                };

                var res = JsonConvert.SerializeObject(resBody, Newtonsoft.Json.Formatting.Indented);
                return res;
            }
            else
            {
                var resBody = new SocotraResponse()
                {
                    fieldValues = new FieldValues
                    {
                        response_360v = new[] { "Third Party and Socotra Update Policy API Not Triggered." }
                    }
                };
                string responseStr = JsonConvert.SerializeObject(resBody, Formatting.Indented);
                return responseStr;
            }
        }
    }
}

