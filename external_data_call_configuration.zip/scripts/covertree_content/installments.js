let arrays = require("./arrays.js");
let dates = require('./dates.js');

function createInstallments(data)
{
  arrays.polyfill();

  let installments;

  switch (data.paymentScheduleName)
  {
    case 'full_pay':
      installments = getUpfront(data);
      break;
    case '2pay':
      installments = gettwoInstallments(data, 'semiannually', 2);
      break;
    case '11pay':
      installments = getInstallments(data, 'month', 11);
      break;
    default:
      throw `${data.paymentScheduleName} not implemented!`;
  }
  return { installments: installments };
}


function getUpfront(data)
{
  let invoiceItems = data.charges.map(ch => ({
    amount: ch.amount,
    chargeId: ch.chargeId
    
  }));


  return [{
    dueTimestamp: data.coverageStartTimestamp,
    issueTimestamp: data.coverageStartTimestamp,
    startTimestamp: data.coverageStartTimestamp,
    endTimestamp: data.coverageEndTimestamp,
    invoiceItems: invoiceItems,
    writeOff: false
  }];
}

function gettwoInstallments(data, increment, maxInstallments = 1000)
{
  let nowTimestamp = new Date().getTime();

  let startTimestamp = data.charges.min(c => parseInt(data.policy.originalContractStartTimestamp));
  let endTimestamp = data.charges.max(c => parseInt(data.policy.effectiveContractEndTimestamp));

  let startMoment = dates.fromTimestamp(startTimestamp, data.tenantTimeZone);
  let endMoment = dates.fromTimestamp(endTimestamp, data.tenantTimeZone);

  let installmentTimestamps = dates.span(startMoment, endMoment, increment)
                                   .map(m => dates.getTimestamp(m));

  if (installmentTimestamps.length == 0)
    installmentTimestamps = [nowTimestamp];
  else if (installmentTimestamps.length > maxInstallments)
    installmentTimestamps = installmentTimestamps.slice(0, maxInstallments);

  let installments = [];

  for (let i = 0; i < installmentTimestamps.length; i++)
  {
    let it = installmentTimestamps[i];
    installments.push({
      invoiceItems: [],
      dueTimestamp: it,
      startTimestamp: it,
      issueTimestamp: it,
      endTimestamp: i < installmentTimestamps.length - 1 ? installmentTimestamps[i + 1] : endTimestamp,
      writeOff: i == 0
    });
  }

  for (charge of data.charges)
  {
    let newItems = [];
    for (let i = 0; i < installments.length; i++)
    {
      if (charge.coverageStartTimestamp <= installments[i].dueTimestamp &&
          charge.coverageEndTimestamp >= installments[i].dueTimestamp)
      {
        let newItem = { chargeId: charge.chargeId };
        newItems.push(newItem);
        installments[i].invoiceItems.push(newItem);
      }
    }

    if (newItems.length == 0)
    {
       // No installments fell within the charge coverage time, so find one
       let item = { chargeId: charge.chargeId, amount: parseFloat(charge.amount) };
       console.log("item is",JSON.stringify(item))
       let inst;
       for (let i = 0; i < installments.length; i++)
         if (installments[i].dueTimestamp <= charge.coverageStartTimestamp)
         {
           inst = installments[i];
           break;
         }
       if (inst === undefined)
         inst = installments[0];
       inst.invoiceItems.push(item);     
    }
    else 
    {
      let amount = parseFloat(charge.amount);
      let fraction = round2(0.6*amount);
      console.log("second charge id amount",fraction)
      for (let i = 0; i < newItems.length; i++)
      {
        if (i < newItems.length - 1)
          newItems[i].amount = fraction;
        else
          newItems[i].amount = round2(amount - newItems.slice(0, newItems.length - 1).sum(ni => ni.amount));
      }
    }
  }
  return installments.filter(inst => inst.invoiceItems.length > 0);
}

function getInstallments(data, increment, maxInstallments = 1000)
{
  let nowTimestamp = new Date().getTime();

  let startTimestamp = data.charges.min(c => parseInt(data.policy.originalContractStartTimestamp));
  let endTimestamp = data.charges.max(c => parseInt(data.policy.effectiveContractEndTimestamp));

  let startMoment = dates.fromTimestamp(startTimestamp, data.tenantTimeZone);
  let endMoment = dates.fromTimestamp(endTimestamp, data.tenantTimeZone);

  let installmentTimestamps = dates.span(startMoment, endMoment, increment)
                                   .map(m => dates.getTimestamp(m));

  if (installmentTimestamps.length == 0)
    installmentTimestamps = [nowTimestamp];
  else if (installmentTimestamps.length > maxInstallments)
    installmentTimestamps = installmentTimestamps.slice(0, maxInstallments);

  let installments = [];

  for (let i = 0; i < installmentTimestamps.length; i++)
  {
    let it = installmentTimestamps[i];
    installments.push({
      invoiceItems: [],
      dueTimestamp: it,
      startTimestamp: it,
      issueTimestamp: it,
      endTimestamp: i < installmentTimestamps.length - 1 ? installmentTimestamps[i + 1] : endTimestamp,
      writeOff: i == 0
    });
  }

  for (charge of data.charges)
  {
    let newItems = [];
    for (let i = 0; i < installments.length; i++)
    {
      if (charge.coverageStartTimestamp <= installments[i].dueTimestamp &&
          charge.coverageEndTimestamp >= installments[i].dueTimestamp)
      {
        let newItem = { chargeId: charge.chargeId };
        newItems.push(newItem);
        installments[i].invoiceItems.push(newItem);
      }
    }

    if (newItems.length == 0)
    {
       // No installments fell within the charge coverage time, so find one
       let item = { chargeId: charge.chargeId, amount: parseFloat(charge.amount) };
       let inst;
       for (let i = 0; i < installments.length; i++)
         if (installments[i].dueTimestamp <= charge.coverageStartTimestamp)
         {
           inst = installments[i];
           break;
         }
       if (inst === undefined)
         inst = installments[0];
       inst.invoiceItems.push(item);     
    }
    else 
    {
      let amount = parseFloat(charge.amount);
      let fraction = round2(0.167 * amount);
      let fraction1 = round2(0.0833 * amount);

      for (let i = 0; i < newItems.length; i++)
      {
        if (i == 0)
          newItems[i].amount = fraction;
        else if(i>0 && i < newItems.length - 1 )
          newItems[i].amount = fraction1;
        else
         newItems[i].amount = round2(amount - newItems.slice(0, newItems.length - 1).sum(ni => ni.amount));
         
      }
    }
  }
  return installments.filter(inst => inst.invoiceItems.length > 0);
}

function round2(amount)
{
  return Math.round(amount * 100.0) / 100.0;
}

exports.createInstallments = createInstallments;